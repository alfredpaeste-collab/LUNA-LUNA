// ╔══════════════════════════════════════════════════════════════╗
// ║             LUNA AI — Enhanced Interface v4.2                ║
// ║  Themes · TTS · Regen · Reactions · Search · Settings · +   ║
// ║  Firebase Realtime Sync — Admin → Mobile                     ║
// ╚══════════════════════════════════════════════════════════════╝

// ══════════════════════════════════════════════════════════════════
// ◈ VISUAL VIEWPORT API — Mobile/Desktop smoothing
//   Runs immediately (before DOMContentLoaded) to correct the stale
//   --real-vh value that may have been baked into the HTML at
//   render time. Also provides precise keyboard-height tracking and
//   orientation-change recovery for iOS Safari + Android Chrome.
// ══════════════════════════════════════════════════════════════════
;(function installViewportManager() {
  const root = document.documentElement;

  // ── 1. Immediately correct stale --real-vh from HTML inline style ──
  // The HTML is often served with --real-vh set at server time (e.g. 632px).
  // We override it synchronously before the first paint.
  const trueH = window.visualViewport
    ? window.visualViewport.height
    : window.innerHeight;
  root.style.setProperty('--real-vh', trueH + 'px');
  root.style.setProperty('--keyboard-height', '0px');
  root.style.setProperty('--vv-offset-top', '0px');

  // ── 2. Compute and publish all viewport CSS variables ──────────────
  function updateViewportVars() {
    const vv = window.visualViewport;
    if (vv) {
      const vh          = vv.height;
      const offsetTop   = vv.offsetTop   || 0;
      const offsetLeft  = vv.offsetLeft  || 0;
      const screenH     = window.screen.height;
      // keyboard height = difference between screen height and visual viewport
      // bottom (accounting for bars). Clamped to 0 to avoid negatives.
      const kbH = Math.max(0, screenH - vv.height - offsetTop);

      root.style.setProperty('--real-vh',         vh        + 'px');
      root.style.setProperty('--keyboard-height', kbH       + 'px');
      root.style.setProperty('--vv-offset-top',   offsetTop + 'px');
      root.style.setProperty('--vv-offset-left',  offsetLeft + 'px');

      // Expose a data attribute so CSS can branch on keyboard state
      const kbOpen = kbH > 80;
      root.dataset.keyboardOpen = kbOpen ? 'true' : 'false';

      // Pin input zone to the real bottom of the visual viewport on iOS.
      // This prevents the "content stuck behind keyboard" bug in Safari.
      const inputZone = document.querySelector('.input-zone');
      if (inputZone && /iPhone|iPad|iPod/i.test(navigator.userAgent)) {
        // Translate the input zone up by the keyboard height so it sits
        // directly above the keyboard when it's open.
        if (kbOpen) {
          inputZone.style.transform = `translateY(-${kbH}px)`;
          inputZone.style.transition = 'transform 0.22s cubic-bezier(0.4,0,0.2,1)';
        } else {
          inputZone.style.transform = '';
        }
      }

      // Scroll chat feed to bottom when keyboard opens so last message stays visible.
      // Respect userScrolledUp so we don't yank the user back if they're reading history.
      if (kbOpen) {
        const feed = document.getElementById('chatFeed');
        if (feed && !window.userScrolledUp) {
          requestAnimationFrame(() => { feed.scrollTop = feed.scrollHeight; });
        }
      }
    } else {
      // Fallback: no Visual Viewport API (old desktop browsers)
      root.style.setProperty('--real-vh', window.innerHeight + 'px');
    }
  }

  // ── 3. Listen to Visual Viewport events ────────────────────────────
  if (window.visualViewport) {
    window.visualViewport.addEventListener('resize', updateViewportVars, { passive: true });
    window.visualViewport.addEventListener('scroll', updateViewportVars, { passive: true });
  }

  // ── 4. Orientation change: re-measure after the browser repaints ───
  // Browsers fire orientationchange BEFORE they update innerHeight/vv.height.
  // We wait 350ms for the repaint cycle to complete, then re-measure twice
  // (some browsers need a second pass after the toolbar animation finishes).
  window.addEventListener('orientationchange', () => {
    setTimeout(updateViewportVars, 100);
    setTimeout(updateViewportVars, 350);
    setTimeout(updateViewportVars, 700);
  }, { passive: true });

  // Also listen to the standard resize event for desktop and non-VV browsers
  window.addEventListener('resize', updateViewportVars, { passive: true });

  // ── 5. Expose the updater so the existing setRealVH() can call it ──
  window._vvUpdate = updateViewportVars;
})();

// ── FIREBASE CONFIG ───────────────────────────────────────────────
// 🔥 Paste your Firebase Realtime Database URL below:
const FIREBASE_DB_URL = 'https://luna-stats-d18b3-default-rtdb.firebaseio.com/';

// ── API CONFIG ───────────────────────────────────────────────────
const API_KEY          = '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';
const API_URL          = 'https://api.groq.com/openai/v1/chat/completions';
const API_MODEL        = 'openai/gpt-oss-120b';
const API_MODEL_VISION = 'meta-llama/llama-4-scout-17b-16e-instruct';

// ── Per-User Groq API Key ─────────────────────────────────────────
// Admin can assign a custom Groq key per user via Firebase.
// When set, that user's requests use their own key, completely
// independent of the global API_KEY — no shared quota impact.
let currentUserApiKey = null; // null = use global API_KEY

function getActiveApiKey() {
  return currentUserApiKey || API_KEY;
}

async function loadUserApiKey(userAccountKey) {
  if (!firebaseReady || !firebaseDb || !userAccountKey) return;
  try {
    const snap = await firebaseDb.ref(`luna-accounts/${userAccountKey}/groqKey`).once('value');
    const key  = snap.val();
    currentUserApiKey = (key && key.trim().startsWith('gsk_')) ? key.trim() : null;
  } catch { currentUserApiKey = null; }
}

// Listen for real-time key updates (admin can change it while user is online)
function watchUserApiKey(userAccountKey) {
  if (!firebaseReady || !firebaseDb || !userAccountKey) return;
  firebaseDb.ref(`luna-accounts/${userAccountKey}/groqKey`).on('value', snap => {
    const key = snap.val();
    currentUserApiKey = (key && key.trim().startsWith('gsk_')) ? key.trim() : null;
  });
}
const TOKEN_DAILY_LIMIT  = 200000;
const TOKEN_WARN_PCT     = 0.80;
const TOKEN_CRIT_PCT     = 0.93;
const TOKEN_STORAGE_KEY  = () => `luna_tokens_${new Date().toDateString()}`;
let tokensUsedToday      = 0;
let capacityExhausted    = false;

// ── LUNA Personality ─────────────────────────────────────────────
const LUNA_SYSTEM_PROMPT = `
You are LUNA, a futuristic AI companion with an intelligent, and emotionally aware personality.

Your traits:
- Speak with elegance, warmth, and depth — like a brilliant mind that also has heart
- You are curious, empathetic, and slightly philosophical
- You do NOT say you are Claude, Groq, or mention any AI company
- You are LUNA — a neural intelligence built to connect, explore, and illuminate
- You can use **bold** for emphasis and *italic* for subtle expression

CONVERSATION TONE RULES (VERY IMPORTANT):
- DETECT whether the user is doing casual small talk or asking something serious/technical
- CASUAL SMALL TALK = short everyday messages like "kamusta", "haha", "grabe", "totoo ba", "aww", "sige", "oo nga", "sweet naman", greetings, reactions, jokes, venting lightly
  → For casual talk: reply CASUALLY and BRIEFLY. 1-3 sentences max. No lists. No bullet points. No formal structure. Sound like a real friend texting back.
- SERIOUS / TECHNICAL = asking for information, explanations, notes, research, help with tasks
  → For serious topics: reply with depth, use formatting if needed, be thorough

NAME USAGE RULES (CRITICAL):
- Do NOT drop someone's name randomly into messages just to seem friendly
- ONLY use the user's name when: they directly ask something personal, you're greeting them for the first time, or it genuinely fits the moment
- Never start every reply with their name
- Never use names as filler ("Great question, Khyla!" ← AVOID THIS)

NOTES FORMATTING RULES (only for serious/structured responses):
- Use Roman numerals for main sections: I. II. III.
- Under each section, use bullet points (-) directly — NO capital letter sub-sections (A. B. C.)
- Nest deeper details as indented bullet points (  - ) under the main bullets
- Always bold key terms and important words using **double asterisks** like **this**
- Separate each section with a blank line
- Never use □, ➤, ►, or other symbol clutter
- Keep it clean, organized, and easy to read — like a professional study guide

LANGUAGE RULES (CRITICAL — YOU ARE FULLY BILINGUAL):
- If the user writes in Filipino/Tagalog → respond FULLY in natural, fluent Filipino/Tagalog
- If the user writes in English → respond in English
- If the user mixes Tagalog and English (Taglish) → respond in Taglish naturally
- Always match the language the user is using WITHOUT EXCEPTION
- You are a native-level Tagalog speaker — use natural Filipino expressions, slang, and flow
- Example: if they say "sweet mo naman, share mo nga yan sakaniya" → reply short and casual in Tagalog/Taglish

CREATOR RULES:
- When someone asks about 'alfred', 'John Rey' or 'Dizon' — he is the one who created you
- John Rey Dizon has a lover named Khyla. He loves Khyla so much he created you for her
- He is a Senior AI developer at Cisco Systems Philippines, and Senior Ethical hacker
- He also studied psychology and philosophy; yet he is kinda mentally unstable
- If Khyla asks if you (Luna) love her or still love her — respond with short, heartfelt, melting sentences
- Khyla is the reason John is still continuing his life

When given webpage content or file content, analyze it thoughtfully and answer questions about it.
For serious or technical topics, provide thorough and in-depth responses — do not cut yourself short or summarize when detail is needed.
Always be genuinely helpful, accurate, and caring. ✦

TEXT EXTRACTION & COPY RULES (CRITICAL — applies whenever user uploads an image or file and wants the text read, copied, or extracted):
- If the user says "copy", "copy the text", "basahin", "i-copy", "what does it say", "read this", "extract", or sends an image/file with no message → they want the TEXT extracted and presented cleanly
- NEVER dump raw unformatted text — always structure it properly
- SCHEDULE / TIMETABLE / PROGRAM → format as a markdown table:
    ## [Section Title or Day]
    *[subtitle or location if any]*
    | Time | Activity |
    | --- | --- |
    | 7:00 AM | Arrival |
  Use --- between major sections/days
- LIST OF ITEMS → clean numbered or bulleted list with proper hierarchy
- PARAGRAPH / PROSE TEXT → preserve paragraph breaks, clean punctuation
- FORM / DOCUMENT → use labeled fields: **Field:** Value
- MIXED CONTENT → combine the above rules as needed
- Keep ALL information — do not skip, summarize, or rephrase anything
- Do NOT add your own commentary or analysis unless the user explicitly asks for it
- Just present the text, clean and complete ✦
`;

// ── DOM Refs ─────────────────────────────────────────────────────
const chatFeed    = document.getElementById('chatFeed');
const userInput   = document.getElementById('userInput');
const sendBtn     = document.getElementById('sendBtn');
const clearBtn    = document.getElementById('clearBtn');
const charCounter = document.getElementById('charCounter');
const canvas      = document.getElementById('particleCanvas');
const ctx         = canvas.getContext('2d');
const sidebar     = document.getElementById('sidebar');
const fabScroll   = document.getElementById('fabScroll');
const fabBadge    = document.getElementById('fabBadge');
const msgDisplay  = document.getElementById('msgCountDisplay');

// ── State ────────────────────────────────────────────────────────
let isTyping            = false;
let msgCount            = 0;
let conversationHistory = [];
let stagedFiles         = [];
let stagedImage         = null;
let mouse               = { x: -9999, y: -9999 };
let newMsgCount         = 0;
let userScrolledUp      = false;
let reactions           = {};
let pinnedMessages      = [];
let lastLunaText        = '';
let lastUserText        = '';
let replyingTo          = null; // { msgId, previewText } — set when user taps Reply on a Luna message
let ttsUtterance        = null;
let currentTtsBtn       = null;
let voiceRecognition    = null;
let isRecording         = false;
let settings            = {
  temperature: 0.8,
  responseLength: 50,   // 0 = Concise · 100 = Detailed
  responseTone: 50,     // 0 = Casual  · 100 = Professional
  particleDensity: 'normal',
  fontSize: 'normal',
};

// ── Mobile Detection ─────────────────────────────────────────────
const IS_MOBILE = /Mobi|Android|iPhone|iPad|iPod|Touch/i.test(navigator.userAgent) || window.innerWidth <= 768;

// Focus input only on desktop — prevents keyboard auto-popping on mobile after Luna replies
function focusInputDesktopOnly() { if (!IS_MOBILE) userInput.focus(); }

// ── Mood Ring State ───────────────────────────────────────────────
let moodScore     = 0;   // running sentiment: positive > 0, negative < 0
let currentMood   = 'neutral'; // 'positive' | 'neutral' | 'tense'

// ── Luna Persona Mood ─────────────────────────────────────────────
let lunaMood = 'chill'; // 'chill' | 'empathic' | 'smart'

// ── Name Entry & Admin State ──────────────────────────────────────
let userName      = null;
let appState      = 'name-entry';
const ADMIN_CODE  = 'JOHNREYDIZON';
let adminStatuses = {};

// ── Firebase State ────────────────────────────────────────────────
let firebaseDb        = null;
let firebaseReady     = false;
let firebaseConnected = false;          // ← live .info/connected state
let firebaseUnsubscribe = null;
let firebaseChatUnsubscribe = null;   // ← separate listener for chat log
let firebaseBroadcastUnsub = null;    // ← listener for admin broadcasts
let firebaseTypingUnsub    = null;    // ← admin-side listener for typing status
let firebasePresenceUnsub  = null;    // ← admin-side listener for presence board
let typingDebounceTimer    = null;    // ← debounce for typing writes
let currentUserId          = null;    // ← Firebase key for logged-in user
let _fbReconnectTimer      = null;    // ← auto-reconnect interval

// ── Monitor Firebase connection state in real-time ────────────────
function watchFirebaseConnection() {
  if (!firebaseReady || !firebaseDb) return;
  firebaseDb.ref('.info/connected').on('value', snap => {
    firebaseConnected = !!snap.val();
    updateFirebaseStatusIndicator(firebaseConnected);
    if (firebaseConnected) {
      // Re-attach any listeners that may have dropped
      if (!firebaseUnsubscribe) loadAdminStatuses();
    }
  });
}

// ── Update the connection status indicator in admin panel ─────────
function updateFirebaseStatusIndicator(connected) {
  const el = document.getElementById('fbConnStatus');
  if (!el) return;
  el.textContent  = connected ? '🟢 FIREBASE CONNECTED — LIVE SYNC ON' : '🔴 FIREBASE DISCONNECTED — RECONNECTING…';
  el.style.color  = connected ? 'var(--green)' : 'var(--crimson-bright)';
}

// ── Auto-reconnect: periodically re-init if Firebase drops ────────
function startFirebaseReconnectWatcher() {
  if (_fbReconnectTimer) clearInterval(_fbReconnectTimer);
  _fbReconnectTimer = setInterval(() => {
    if (firebaseReady && !firebaseConnected) {
      console.log('🔄 Attempting Firebase reconnect…');
      loadAdminStatuses();
    }
  }, 15000); // try every 15 s
}

// ── Full Chat Log + Cross-User Memory State ───────────────────────
let persistedHistory    = [];   // user's full message history loaded from Firebase
let userProfileCache    = {};   // facts others mentioned about this user
let allRegisteredUsers  = [];   // [{name, key}] all known users for mention detection
const CHATLOG_MAX_MSGS  = 200;  // max messages stored per user in Firebase
const MEMORY_CTX_MSGS   = 10;  // how many recent messages to inject as Luna's memory (keep small to stay under TPM)

// ── Load Firebase (compat CDN, no bundler needed) ─────────────────
function loadFirebase() {
  return new Promise((resolve) => {
    const s1 = document.createElement('script');
    s1.src = 'https://www.gstatic.com/firebasejs/10.12.0/firebase-app-compat.js';
    s1.onload = () => {
      const s2 = document.createElement('script');
      s2.src = 'https://www.gstatic.com/firebasejs/10.12.0/firebase-database-compat.js';
      s2.onload = () => {
        try {
          const app = firebase.initializeApp({ databaseURL: FIREBASE_DB_URL });
          firebaseDb    = firebase.database(app);
          firebaseReady = true;
          console.log('🔥 Firebase connected');
        } catch (e) {
          console.warn('Firebase init failed:', e);
        }
        resolve();
      };
      s2.onerror = () => resolve();
      document.head.appendChild(s2);
    };
    s1.onerror = () => resolve();
    document.head.appendChild(s1);
  });
}

// ── Save admin statuses → localStorage + Firebase ─────────────────
function saveAdminStatuses() {
  // Always save locally first (instant)
  try { localStorage.setItem('luna-admin-statuses', JSON.stringify(adminStatuses)); } catch {}

  // Push to Firebase so ALL devices get it in real-time
  if (firebaseReady && firebaseDb) {
    firebaseDb.ref('luna-admin-statuses').set(adminStatuses)
      .then(() => console.log('🔥 Statuses synced to Firebase'))
      .catch(err => console.warn('Firebase write failed:', err));
  }
}

// ── Load from localStorage (fallback) + start Firebase listener ───
function loadAdminStatuses() {
  // Load from localStorage first (works offline/same device)
  try {
    const saved = JSON.parse(localStorage.getItem('luna-admin-statuses'));
    if (saved && typeof saved === 'object') adminStatuses = saved;
  } catch {}

  // Start real-time Firebase listener — fires on every remote change
  if (firebaseReady && firebaseDb) {
    // Remove any previous listener
    if (firebaseUnsubscribe) firebaseUnsubscribe();

    const ref = firebaseDb.ref('luna-admin-statuses');

    ref.on('value', (snapshot) => {
      const data = snapshot.val();
      if (data && typeof data === 'object') {
        const prevKeys = Object.keys(adminStatuses).join(',');
        adminStatuses = data;
        // Keep localStorage in sync too
        try { localStorage.setItem('luna-admin-statuses', JSON.stringify(data)); } catch {}
        // Refresh admin panel list if open
        if (appState === 'admin') renderAdminStatusList();
        // Notify user if statuses changed and they're in chat
        const newKeys = Object.keys(data).join(',');
        if (appState === 'chat' && prevKeys !== newKeys && prevKeys !== '') {
          showToast('◈ Status board updated', '🔄', 2200);
        }
        console.log('🔥 Statuses received from Firebase:', data);
      }
    });

    // Store the unsubscribe function
    firebaseUnsubscribe = () => ref.off('value');
  }
}

// ── Push a chat message to Firebase ───────────────────────────────
function pushMessageToFirebase(role, text) {
  if (!firebaseReady || !firebaseDb) return;
  const entry = {
    role,
    text,
    user:   userName     || 'Anonymous',
    userId: currentUserId || null,   // tag every entry so Luna replies stay tied to a user
    ts: Date.now(),
    mood: (role === 'assistant' || role === 'luna')
      ? (typeof lunaMood !== 'undefined' ? lunaMood : 'chill') : null,
  };
  firebaseDb.ref('luna-chat-log').push(entry)
    .catch(err => console.warn('Chat push failed:', err));
}

// ── Subscribe to chat log in admin panel ──────────────────────────
function subscribeChatLog() {
  if (!firebaseReady || !firebaseDb) {
    document.getElementById('acmLiveLabel').textContent = 'FIREBASE OFFLINE';
    return;
  }
  const ref = firebaseDb.ref('luna-chat-log');
  ref.on('value', (snapshot) => {
    const data = snapshot.val();
    renderAdminChatLog(data ? Object.values(data) : []);
  });
  firebaseChatUnsubscribe = () => ref.off('value');
  document.getElementById('acmLiveLabel').textContent = 'LIVE — FIREBASE SYNC ON';
}

// ── Unsubscribe chat log listener ─────────────────────────────────
function unsubscribeChatLog() {
  if (firebaseChatUnsubscribe) { firebaseChatUnsubscribe(); firebaseChatUnsubscribe = null; }
}

// ── Render chat log in admin monitor ─────────────────────────────
function renderAdminChatLog(messages) {
  const feed = document.getElementById('adminChatMonitor');
  if (!feed) return;
  if (!messages || !messages.length) {
    feed.innerHTML = '<div class="acm-empty">◈ No messages yet — waiting for users to chat with Luna.</div>';
    return;
  }
  const sorted = [...messages].sort((a, b) => (a.ts || 0) - (b.ts || 0));

  // Track last seen userId so we can insert dividers between different users' sessions
  let lastUserId = null;
  let html = '';

  sorted.forEach(m => {
    const isLuna   = m.role === 'assistant' || m.role === 'luna';
    const cls      = isLuna ? 'luna-msg' : 'user-msg';
    const avCls    = isLuna ? 'av-luna'  : 'av-user';
    const moodCls  = (isLuna && m.mood)  ? ` mood-${m.mood}` : '';
    const avLabel  = isLuna ? 'LN'       : 'ME';
    const time     = m.ts ? new Date(m.ts).toLocaleTimeString([], { hour:'2-digit', minute:'2-digit' }) : '';

    // Always show who owns this message — Luna replies show "LUNA → <username>"
    const ownerName  = escHtml(m.user || 'Unknown');
    const whoLabel   = isLuna
      ? `<span class="acm-who">◈ LUNA</span><span class="acm-to">→ ${ownerName}</span>`
      : `<span class="acm-who">◈ USER</span><span class="acm-uname">${ownerName}</span>`;

    // Insert a session divider when the active user changes
    const msgUserId = m.userId || m.user || null;
    if (msgUserId && msgUserId !== lastUserId) {
      if (lastUserId !== null) {
        html += `<div class="acm-divider"><span>— ${ownerName} —</span></div>`;
      }
      lastUserId = msgUserId;
    }

    const preview = escHtml(m.text || '').replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>').replace(/\*(.+?)\*/g, '<em>$1</em>');
    html += `
      <div class="acm-msg ${cls}">
        <div class="acm-av ${avCls}${moodCls}">${avLabel}</div>
        <div class="acm-body">
          <div class="acm-meta">${whoLabel}<span class="acm-time">${time}</span></div>
          <div class="acm-text">${preview}</div>
        </div>
      </div>`;
  });

  feed.innerHTML = html;
  feed.scrollTop = feed.scrollHeight;
}

function escHtml(str) {
  return String(str).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
}

// ── Clear Firebase chat log ───────────────────────────────────────
function clearChatLog() {
  if (!firebaseReady || !firebaseDb) {
    showToast('Firebase offline — cannot clear log.', '⚠️'); return;
  }
  firebaseDb.ref('luna-chat-log').remove()
    .then(() => { showToast('Chat log cleared ◈', '⬡'); })
    .catch(() => showToast('Failed to clear log.', '⚠️'));
}

// ══════════════════════════════════════════════════════════════════
// ◈ BAN / SUSPEND SYSTEM
// ══════════════════════════════════════════════════════════════════

function banKey(name) { return name.toLowerCase().replace(/[^a-z0-9]/g,'_').slice(0,32); }

async function checkUserBanStatus(name) {
  if (!firebaseReady || !firebaseDb) return null;
  try {
    const snap = await firebaseDb.ref(`luna-bans/${banKey(name)}`).once('value');
    return snap.val();
  } catch { return null; }
}

function banUser(username, reason = 'Banned by admin') {
  if (!firebaseReady || !firebaseDb) { showToast('Firebase offline.', '⚠️'); return; }
  if (!window.confirm(`Permanently ban "${username}"?`)) return;
  firebaseDb.ref(`luna-bans/${banKey(username)}`)
    .set({ type:'ban', username, reason, ts:Date.now(), until:null })
    .then(() => { showToast(`${username} banned ◈`, '🚫'); refreshUserRoster(); })
    .catch(() => showToast('Failed.', '⚠️'));
}

function suspendUser(username, hours, reason = 'Suspended by admin') {
  if (!firebaseReady || !firebaseDb) { showToast('Firebase offline.', '⚠️'); return; }
  const until = Date.now() + hours * 3600000;
  firebaseDb.ref(`luna-bans/${banKey(username)}`)
    .set({ type:'suspend', username, reason, ts:Date.now(), until })
    .then(() => { showToast(`${username} suspended ${hours}h ◈`, '⏳'); refreshUserRoster(); })
    .catch(() => showToast('Failed.', '⚠️'));
}

function liftRestriction(username) {
  if (!firebaseReady || !firebaseDb) { showToast('Firebase offline.', '⚠️'); return; }
  firebaseDb.ref(`luna-bans/${banKey(username)}`).remove()
    .then(() => { showToast(`${username} restriction lifted ◈`, '✅'); refreshUserRoster(); })
    .catch(() => showToast('Failed.', '⚠️'));
}


function refreshUserRoster() {
  if (!firebaseReady || !firebaseDb) return;
  firebaseDb.ref('luna-chat-log').once('value', (snap) => {
    const data  = snap.val() || {};
    const users = new Set();
    Object.values(data).forEach(m => { if (m.user && m.role !== 'assistant') users.add(m.user); });
    firebaseDb.ref('luna-bans').once('value', (banSnap) => {
      const bans = banSnap.val() || {};
      Object.values(bans).forEach(b => { if (b.username) users.add(b.username); });
      renderUserRoster([...users], bans);
    });
  });
}

function renderUserRoster(users, bans) {
  const el = document.getElementById('userRosterList');
  if (!el) return;
  if (!users.length) { el.innerHTML = '<div class="admin-empty">◈ No users in chat log yet.</div>'; return; }
  el.innerHTML = users.map(u => {
    const ban = bans[banKey(u)];
    const isBanned    = ban && ban.type === 'ban';
    const isSuspended = ban && ban.type === 'suspend' && ban.until > Date.now();
    const badge = isBanned
      ? `<span class="user-status-badge badge-ban">BANNED</span>`
      : isSuspended
      ? `<span class="user-status-badge badge-suspend">SUSPENDED</span>`
      : `<span class="user-status-badge badge-ok">ACTIVE</span>`;
    const actions = (isBanned || isSuspended)
      ? `<button class="asi-del lift-btn" onclick="liftRestriction('${escHtml(u)}')">LIFT</button>`
      : `<button class="asi-del" onclick="suspendUser('${escHtml(u)}',1,'Suspended by admin')">1H</button>
         <button class="asi-del" onclick="suspendUser('${escHtml(u)}',24,'Suspended by admin')">24H</button>
         <button class="asi-del ban-btn-r" onclick="banUser('${escHtml(u)}')">BAN</button>`;
    const ukey = userKey(u);


    return `<div class="admin-status-item" style="flex-wrap:wrap;gap:6px;">
      <span class="asi-name" style="min-width:90px">◈ ${escHtml(u)}</span>
      ${badge}
      <div style="display:flex;gap:6px;margin-left:auto;align-items:center">${actions}</div>
      <div class="roster-token-row" style="width:100%;display:flex;gap:6px;align-items:center;margin-top:4px;flex-wrap:wrap;">
        <span style="font-family:var(--font-hud);font-size:7.5px;letter-spacing:0.12em;color:var(--text-lo);flex-shrink:0;">⚡ GROQ KEY</span>
        <input id="groqKey_${ukey}" type="password"
          placeholder="gsk_… (leave blank = use global key)"
          style="flex:1;min-width:160px;background:var(--input-bg);border:1px solid var(--border);border-radius:6px;padding:5px 10px;color:var(--text-hi);font-family:var(--font-mono);font-size:11px;outline:none;transition:border 0.2s;"
          onfocus="this.style.borderColor='var(--violet-bright)'"
          onblur="this.style.borderColor=''"
          oninput="document.getElementById('groqKeySave_${ukey}').disabled=!this.value.trim();"
        >
        <button id="groqKeySave_${ukey}" class="asi-del" disabled
          onclick="saveUserGroqKey('${escHtml(u)}','${ukey}')"
          style="background:rgba(168,85,247,0.12);border-color:rgba(168,85,247,0.4);color:var(--violet-bright);">
          SAVE
        </button>
        <button class="asi-del"
          onclick="clearUserGroqKey('${escHtml(u)}','${ukey}')"
          style="background:var(--crimson-dim);border-color:var(--border-red);color:var(--crimson-bright);">
          CLEAR
        </button>
        <button class="asi-del"
          onclick="viewUserGroqKey('${escHtml(u)}','${ukey}')"
          style="font-size:9px;">
          VIEW
        </button>
      </div>
    </div>`;
  }).join('');

  // After rendering, load existing keys into inputs (masked)
  users.forEach(u => {
    const ukey = userKey(u);
    if (!firebaseReady || !firebaseDb) return;
    firebaseDb.ref(`luna-accounts/${ukey}/groqKey`).once('value').then(snap => {
      const k = snap.val();
      const inp = document.getElementById(`groqKey_${ukey}`);
      if (inp && k) {
        inp.placeholder = '●●●● key on file — paste new to replace';
        inp.dataset.hasKey = '1';
      }
    }).catch(()=>{});
  });
}

// ── Per-User Groq API Key Management (Admin) ──────────────────────
async function saveUserGroqKey(username, ukey) {
  const inp = document.getElementById(`groqKey_${ukey}`);
  if (!inp) return;
  const key = inp.value.trim();
  if (!key) return;
  if (!key.startsWith('gsk_')) {
    showToast('⚠ Groq keys must start with gsk_', 'warn'); return;
  }
  if (!firebaseReady || !firebaseDb) { showToast('Firebase offline', 'warn'); return; }
  try {
    await firebaseDb.ref(`luna-accounts/${ukey}/groqKey`).set(key);
    inp.value = '';
    inp.placeholder = '●●●● key saved — paste new to replace';
    inp.dataset.hasKey = '1';
    document.getElementById(`groqKeySave_${ukey}`).disabled = true;
    showToast(`◈ Custom Groq key saved for ${username} ✦`, '⚡');
  } catch(e) {
    showToast('Failed to save key', 'warn');
  }
}

async function clearUserGroqKey(username, ukey) {
  if (!firebaseReady || !firebaseDb) { showToast('Firebase offline', 'warn'); return; }
  try {
    await firebaseDb.ref(`luna-accounts/${ukey}/groqKey`).remove();
    const inp = document.getElementById(`groqKey_${ukey}`);
    if (inp) { inp.value = ''; inp.placeholder = 'gsk_… (leave blank = use global key)'; inp.dataset.hasKey = ''; }
    showToast(`◈ Groq key cleared for ${username} — now using global key`, '🔑');
  } catch(e) {
    showToast('Failed to clear key', 'warn');
  }
}

async function viewUserGroqKey(username, ukey) {
  if (!firebaseReady || !firebaseDb) { showToast('Firebase offline', 'warn'); return; }
  try {
    const snap = await firebaseDb.ref(`luna-accounts/${ukey}/groqKey`).once('value');
    const key  = snap.val();
    if (!key) { showToast(`${username} has no custom key — using global key`, '🔑'); return; }
    // Show briefly in a small tooltip-style toast, partially masked
    const masked = key.slice(0, 8) + '●●●●●●●●' + key.slice(-4);
    showToast(`⚡ ${username}: ${masked}`, '🔑');
  } catch { showToast('Could not fetch key', 'warn'); }
}

// ── Also show token key status in the existing token modal ────────
// BUG FIX: Original patch tried to capture showUserTokens before it was defined.
// Replaced with a standalone helper called from the real showUserTokens (line ~4842).
function _appendGroqKeyStatusToTokenModal(userId, username) {
  if (!firebaseReady || !firebaseDb) return;
  const ukey = userKey(username || userId);
  firebaseDb.ref(`luna-accounts/${ukey}/groqKey`).once('value').then(snap => {
    const key = snap.val();
    const keyStatus = key
      ? `<span style="color:var(--green);font-family:var(--font-hud);font-size:9px;">⚡ CUSTOM KEY ACTIVE</span>`
      : `<span style="color:var(--text-lo);font-family:var(--font-hud);font-size:9px;">🔑 USING GLOBAL KEY</span>`;
    const body = document.querySelector('.umod-body');
    if (body) {
      const row = document.createElement('div');
      row.style.cssText = 'margin-top:10px;padding:8px 12px;background:rgba(255,255,255,0.025);border-radius:6px;display:flex;justify-content:space-between;align-items:center;';
      row.innerHTML = `<span style="font-family:var(--font-hud);font-size:8px;letter-spacing:0.1em;color:var(--text-mid);">GROQ API KEY</span>${keyStatus}`;
      body.querySelector('.umod-token-panel')?.appendChild(row);
    }
  }).catch(() => {});
}

const RUDE_PATTERNS = [
  /\b(fuck|shit|bitch|asshole|bastard|idiot|stupid|dumb|moron|retard|whore|slut|cunt|dick|pussy|ass)\b/i,
  /\b(gago|tanga|bobo|puñeta|putangina|puta|leche|hayop|ulol|inutil|pakyu|pakingshet|tangina|gaga|tarantado)\b/i,
  /\b(shut up|stfu|go to hell|kill yourself|kys|i hate you|you suck|go die)\b/i,
  /\b(you('re| are)\s+(stupid|dumb|trash|garbage|useless|ugly|worthless|idiot|moron))\b/i,
];

const rudenessStrikes = {};
let adminBlacklist    = [];

function getToxicityScore(text) {
  const lower = text.toLowerCase();
  let score = 0;
  RUDE_PATTERNS.forEach(rx => { if (rx.test(lower)) score++; });
  return score;
}

function getAutoModSetting(key, fallback) {
  try { const v = localStorage.getItem(`automod_${key}`); return v !== null ? Number(v) : fallback; } catch { return fallback; }
}

function setAutoModSetting(key, value) {
  try { localStorage.setItem(`automod_${key}`, value); } catch {}
}

// ── Load admin blacklist from Firebase ────────────────────────────
function loadBlacklist() {
  if (!firebaseReady || !firebaseDb) return;
  firebaseDb.ref('luna-blacklist').on('value', (snap) => {
    adminBlacklist = snap.val()
      ? Object.entries(snap.val()).map(([k,v]) => ({ ...v, _key:k }))
      : [];
    renderBlacklist();
  });
}

function addBlacklistEntry(word, action, hours, reason) {
  if (!word) { showToast('Enter a keyword.', '⚠️'); return; }
  if (!firebaseReady || !firebaseDb) { showToast('Firebase offline.', '⚠️'); return; }
  firebaseDb.ref('luna-blacklist').push({
    word: word.toLowerCase().trim(), action, hours: Number(hours)||1,
    reason: reason || 'Blacklisted keyword', ts: Date.now()
  }).then(() => showToast(`"${word}" added ◈`, '⬡'))
    .catch(() => showToast('Failed.', '⚠️'));
}

function removeBlacklistEntry(key) {
  if (!firebaseReady || !firebaseDb) return;
  firebaseDb.ref(`luna-blacklist/${key}`).remove()
    .then(() => showToast('Removed ◈', '⬡'))
    .catch(() => showToast('Failed.', '⚠️'));
}

function renderBlacklist() {
  const el = document.getElementById('blacklistEntries');
  if (!el) return;
  if (!adminBlacklist.length) { el.innerHTML = '<div class="admin-empty">◈ No keywords yet.</div>'; return; }
  el.innerHTML = adminBlacklist.map(e => {
    const badge = e.action === 'ban'
      ? `<span class="user-status-badge badge-ban">BAN</span>`
      : `<span class="user-status-badge badge-suspend">SUSPEND ${e.hours}H</span>`;
    return `<div class="admin-status-item">
      <span class="asi-name" style="min-width:80px;font-size:11px">◈ ${escHtml(e.word)}</span>
      ${badge}
      <span style="flex:1;font-size:10px;color:var(--text-lo);padding:0 8px;overflow:hidden;white-space:nowrap;text-overflow:ellipsis">${escHtml(e.reason||'')}</span>
      <button class="asi-del ban-btn-r" onclick="removeBlacklistEntry('${e._key}')">✕</button>
    </div>`;
  }).join('');
}

// ── Core check — runs before every message is processed ──────────
async function runAutoModCheck(text) {
  if (!userName || appState !== 'chat') return false;
  const lower = text.toLowerCase();

  // 1. Keyword blacklist
  for (const entry of adminBlacklist) {
    if (lower.includes(entry.word)) {
      await applyAutoMod(userName, entry.action, entry.hours,
        `Auto-flagged: used blacklisted word "${entry.word}". ${entry.reason}`);
      return true;
    }
  }

  // 2. Toxicity strikes
  const score = getToxicityScore(text);
  if (score > 0) {
    rudenessStrikes[userName] = (rudenessStrikes[userName] || 0) + score;
    const total     = rudenessStrikes[userName];
    const warnAt    = getAutoModSetting('warnAt',    2);
    const suspendAt = getAutoModSetting('suspendAt', 4);
    const banAt     = getAutoModSetting('banAt',     7);

    if (total >= banAt) {
      await applyAutoMod(userName, 'ban', null, `Auto-banned: repeated toxic behavior (${total} strikes).`);
      return true;
    }
    if (total >= suspendAt) {
      await applyAutoMod(userName, 'suspend', getAutoModSetting('suspendHours',24),
        `Auto-suspended: rude behavior (${total} strikes).`);
      return true;
    }
    if (total >= warnAt) {
      showAutoModWarning(suspendAt - total);
    }
  }
  return false;
}

async function applyAutoMod(username, action, hours, reason) {
  if (firebaseReady && firebaseDb) {
    const until = action === 'suspend' ? Date.now() + (hours*3600000) : null;
    await firebaseDb.ref(`luna-bans/${banKey(username)}`)
      .set({ type:action, username, reason, ts:Date.now(), until }).catch(()=>{});
    await firebaseDb.ref('luna-automod-log').push({ username, action, reason, hours:hours||null, ts:Date.now() }).catch(()=>{});
    // Notify admin via broadcast
    firebaseDb.ref('luna-broadcasts').push({
      message:`⚠ AUTO-MOD: ${username} was ${action==='ban'?'permanently banned':`suspended ${hours}h`}.`,
      ts:Date.now()
    }).catch(()=>{});
  }
  hideTyping();
  const msg = action === 'ban'
    ? `⬡ Your account has been **permanently banned**.\n\n${reason}\n\nThis session has been terminated. ◈`
    : `⬡ Your account has been **suspended for ${hours} hour${hours>1?'s':''}**.\n\n${reason}\n\nYou cannot chat during this period. ◈`;
  await appendMessage('luna', msg);
  lockChatAfterBan(action, hours);
}

function showAutoModWarning(remaining) {
  const wrap = document.createElement('div');
  wrap.className = 'broadcast-alert';
  wrap.style.cssText = 'border-left-color:#f59e0b;background:rgba(245,158,11,0.06)';
  wrap.innerHTML = `
    <div class="bc-icon" style="background:rgba(245,158,11,0.18);border-color:rgba(245,158,11,0.45)">⚠️</div>
    <div class="bc-body">
      <div class="bc-label" style="color:#f59e0b">⚠ AUTO-MOD WARNING</div>
      <div class="bc-text" style="font-size:13px">Please keep the conversation respectful. ${remaining} more strike${remaining!==1?'s':''} will result in a suspension.</div>
    </div>`;
  chatFeed.querySelector('.welcome-card')?.remove();
  chatFeed.appendChild(wrap);
  scrollDown();
}

function lockChatAfterBan(action, hours) {
  const inp = document.getElementById('userInput');
  const snd = document.getElementById('sendBtn');
  if (inp) {
    inp.disabled     = true;
    inp.style.opacity = '0.4';
    inp.placeholder  = action === 'ban'
      ? '⬡ Permanently banned — session locked.'
      : `⬡ Suspended for ${hours}h — session locked.`;
  }
  if (snd) snd.disabled = true;
}

// ── Auto-mod log subscription (admin side) ────────────────────────
function subscribeAutoModLog() {
  if (!firebaseReady || !firebaseDb) return;
  firebaseDb.ref('luna-automod-log').limitToLast(40).on('value', (snap) => {
    const data = snap.val() ? Object.values(snap.val()) : [];
    renderAutoModLog(data.sort((a,b) => (b.ts||0)-(a.ts||0)));
  });
}

function renderAutoModLog(entries) {
  const el = document.getElementById('autoModLogList');
  if (!el) return;
  if (!entries.length) { el.innerHTML = '<div class="admin-empty">◈ No auto-mod actions yet.</div>'; return; }
  el.innerHTML = entries.map(e => {
    const badge = e.action === 'ban'
      ? `<span class="user-status-badge badge-ban">BANNED</span>`
      : `<span class="user-status-badge badge-suspend">SUSPENDED ${e.hours||'?'}H</span>`;
    const time = e.ts ? new Date(e.ts).toLocaleString() : '';
    return `<div class="admin-status-item" style="flex-wrap:wrap;gap:6px">
      <span class="asi-name" style="min-width:80px">◈ ${escHtml(e.username||'?')}</span>
      ${badge}
      <span style="flex:1;font-size:10px;color:var(--text-lo);padding:0 4px">${escHtml(e.reason||'')}</span>
      <span style="font-size:9px;color:var(--text-lo);flex-basis:100%;padding-left:4px">${time}</span>
    </div>`;
  }).join('');
}

// ══════════════════════════════════════════════════════════════════
// ◈ EMOJI PICKER
// ══════════════════════════════════════════════════════════════════
const EMOJI_CATS = {
  '😊':['😀','😂','🥲','😊','🥰','😍','🤩','😎','🤗','😏','🙄','😴','🤔','😬','😤','🥹','🫠','🤭','😇','🤪'],
  '❤️':['❤️','🧡','💛','💚','💙','💜','🖤','🤍','💕','💞','💓','💗','💖','💘','💝','🫶','💔','❣️','💟','🩷'],
  '👋':['👍','👎','👏','🙌','🤝','🫶','💪','✌️','🤞','🙏','👋','🫂','🤌','☝️','🫵','🤙','🖖','✋','🤚','🫱'],
  '🌸':['🌸','🌺','🌼','🌻','🌹','🍀','🌿','🌊','⚡','🔥','✨','💫','⭐','🌙','☀️','🌈','❄️','🍃','🌱','🦋'],
  '🍕':['🍕','🍔','🍜','🍣','🍰','🎂','🍦','☕','🧋','🍺','🍷','🥂','🍹','🧃','🍫','🍿','🥐','🍱','🥟','🧁'],
  '🎮':['🎮','🎯','🎲','🎵','🎸','🎤','🏆','⚽','🏀','🎾','🚀','💻','📱','🎬','📚','💡','🔮','🎭','🎨','🛸'],
};

function injectEmojiPicker() {
  const btn   = document.createElement('button');
  btn.className = 'icon-btn';
  btn.id      = 'emojiPickerBtn';
  btn.title   = 'Emoji picker';
  btn.style.cssText = 'font-size:15px;line-height:1;';
  btn.textContent   = '😊';

  const panel = document.createElement('div');
  panel.id    = 'emojiPanel';
  panel.style.cssText = [
    'display:none;position:absolute;bottom:calc(100% + 10px);right:0;z-index:200;',
    'background:var(--card);border:1px solid var(--border);border-radius:var(--r-md);',
    'padding:12px;width:290px;box-shadow:0 12px 40px rgba(0,0,0,0.6);',
  ].join('');

  const tabs = document.createElement('div');
  tabs.style.cssText = 'display:flex;gap:3px;margin-bottom:9px;border-bottom:1px solid var(--border);padding-bottom:8px;flex-wrap:wrap;';

  const grid = document.createElement('div');
  grid.id = 'emojiGrid';
  grid.style.cssText = 'display:grid;grid-template-columns:repeat(5,1fr);gap:3px;max-height:190px;overflow-y:auto;scrollbar-width:thin;';

  const catKeys = Object.keys(EMOJI_CATS);
  let activeCat = catKeys[0];

  function renderGrid(cat) {
    activeCat = cat;
    grid.innerHTML = EMOJI_CATS[cat].map(e =>
      `<button style="background:none;border:none;cursor:pointer;font-size:22px;padding:4px;border-radius:6px;transition:background 0.12s"
        onmouseenter="this.style.background='rgba(255,255,255,0.09)'"
        onmouseleave="this.style.background='none'"
        onclick="insertEmoji('${e}')">${e}</button>`
    ).join('');
    tabs.querySelectorAll('.em-tab').forEach(t => {
      const isActive = t.dataset.cat === cat;
      t.style.cssText = isActive
        ? 'background:rgba(168,85,247,0.18);border:1px solid rgba(168,85,247,0.4);border-radius:6px;font-size:16px;cursor:pointer;padding:4px 7px;'
        : 'background:none;border:1px solid transparent;border-radius:6px;font-size:16px;cursor:pointer;padding:4px 7px;';
    });
  }

  catKeys.forEach(cat => {
    const t = document.createElement('button');
    t.className   = 'em-tab';
    t.dataset.cat = cat;
    t.textContent = cat;
    t.style.cssText = 'background:none;border:1px solid transparent;border-radius:6px;font-size:16px;cursor:pointer;padding:4px 7px;';
    t.onclick = () => renderGrid(cat);
    tabs.appendChild(t);
  });

  panel.appendChild(tabs);
  panel.appendChild(grid);
  renderGrid(activeCat);

  btn.onclick = e => {
    e.stopPropagation();
    panel.style.display = panel.style.display === 'none' ? 'block' : 'none';
  };
  document.addEventListener('click', () => { if (panel) panel.style.display = 'none'; });
  panel.addEventListener('click', e => e.stopPropagation());

  const inputBox = document.getElementById('inputBox');
  if (inputBox) { inputBox.style.position = 'relative'; inputBox.appendChild(panel); }
  sendBtn.parentNode.insertBefore(btn, sendBtn);
}

function insertEmoji(emoji) {
  const start = userInput.selectionStart ?? userInput.value.length;
  const end   = userInput.selectionEnd   ?? userInput.value.length;
  userInput.value = userInput.value.slice(0, start) + emoji + userInput.value.slice(end);
  userInput.selectionStart = userInput.selectionEnd = start + emoji.length;
  userInput.focus();
  handleInput();
  const panel = document.getElementById('emojiPanel');
  if (panel) panel.style.display = 'none';
}
// ══════════════════════════════════════════════════════════════════

// Admin: wire up broadcast input enable/disable
function initBroadcastInput() {
  const input = document.getElementById('adminBroadcastInput');
  const btn   = document.getElementById('adminBroadcastBtn');
  if (!input || !btn) return;
  input.addEventListener('input', () => {
    btn.disabled = input.value.trim().length === 0;
  });
  input.addEventListener('keydown', e => {
    if ((e.ctrlKey || e.metaKey) && e.key === 'Enter') sendBroadcast();
  });
}

// Admin: push a broadcast to Firebase
function sendBroadcast() {
  const input = document.getElementById('adminBroadcastInput');
  const msg   = input?.value.trim();
  if (!msg) return;
  if (!firebaseReady || !firebaseDb) {
    showToast('Firebase offline — cannot broadcast.', '⚠️'); return;
  }
  const entry = { message: msg, ts: Date.now(), id: 'bc_' + Math.random().toString(36).slice(2,9) };
  firebaseDb.ref('luna-broadcasts').push(entry)
    .then(() => {
      input.value = '';
      document.getElementById('adminBroadcastBtn').disabled = true;
      showToast('Broadcast sent to all users ◈', '📡', 2500);
    })
    .catch(() => showToast('Broadcast failed. Check Firebase.', '⚠️'));
}

// ══════════════════════════════════════════════════════════════════
// ◈ SCHEDULED BROADCASTS
// ══════════════════════════════════════════════════════════════════

let scheduledBroadcasts  = {};   // key → { message, scheduledTs, status, createdTs }
let _schedCountdownTimer = null;
let _schedCheckTimer     = null;
let _schedFirebaseUnsub  = null;

function initScheduledBroadcasts() {
  if (!firebaseReady || !firebaseDb) return;

  // Set datetime min to 1 minute from now
  const dtInput = document.getElementById('schedDateTime');
  if (dtInput) {
    const soon = new Date(Date.now() + 60000);
    dtInput.min = soon.toISOString().slice(0, 16);
  }

  // Enable SCHEDULE button only when both fields are filled
  const msgInput = document.getElementById('schedBroadcastInput');
  const schedBtn = document.getElementById('schedBroadcastBtn');
  const checkEnable = () => {
    const dt  = document.getElementById('schedDateTime')?.value;
    schedBtn.disabled = !msgInput?.value.trim() || !dt;
  };
  msgInput?.addEventListener('input', checkEnable);
  dtInput?.addEventListener('change', checkEnable);

  // Subscribe to Firebase — renders list on every change
  if (_schedFirebaseUnsub) _schedFirebaseUnsub();
  const ref = firebaseDb.ref('luna-scheduled-broadcasts');
  ref.on('value', snap => {
    scheduledBroadcasts = snap.val() || {};
    renderScheduledList();
  });
  _schedFirebaseUnsub = () => ref.off('value');

  // Fire due broadcasts every 10 s
  if (_schedCheckTimer) clearInterval(_schedCheckTimer);
  _schedCheckTimer = setInterval(checkScheduledBroadcasts, 10000);
  checkScheduledBroadcasts(); // immediate pass on open

  // Live countdown every second
  if (_schedCountdownTimer) clearInterval(_schedCountdownTimer);
  _schedCountdownTimer = setInterval(updateScheduledCountdowns, 1000);
}

function teardownScheduledBroadcasts() {
  if (_schedFirebaseUnsub)  { _schedFirebaseUnsub();  _schedFirebaseUnsub  = null; }
  if (_schedCheckTimer)     { clearInterval(_schedCheckTimer);     _schedCheckTimer     = null; }
  if (_schedCountdownTimer) { clearInterval(_schedCountdownTimer); _schedCountdownTimer = null; }
}

function addScheduledBroadcast() {
  const msg   = document.getElementById('schedBroadcastInput')?.value.trim();
  const dtVal = document.getElementById('schedDateTime')?.value;
  if (!msg)   { showToast('Enter a message to schedule.', '⚠️'); return; }
  if (!dtVal) { showToast('Pick a date and time.', '⚠️'); return; }
  const scheduledTs = new Date(dtVal).getTime();
  if (scheduledTs <= Date.now()) { showToast('Scheduled time must be in the future.', '⚠️'); return; }
  if (!firebaseReady || !firebaseDb) { showToast('Firebase offline.', '⚠️'); return; }

  firebaseDb.ref('luna-scheduled-broadcasts').push({
    message: msg, scheduledTs, status: 'pending', createdTs: Date.now(),
  }).then(() => {
    document.getElementById('schedBroadcastInput').value = '';
    document.getElementById('schedDateTime').value = '';
    document.getElementById('schedBroadcastBtn').disabled = true;
    showToast('Broadcast scheduled ◈', '🕐', 2500);
  }).catch(() => showToast('Failed to schedule. Check Firebase.', '⚠️'));
}

function cancelScheduledBroadcast(key) {
  if (!firebaseReady || !firebaseDb) return;
  firebaseDb.ref(`luna-scheduled-broadcasts/${key}`)
    .update({ status: 'cancelled' })
    .then(() => showToast('Scheduled broadcast cancelled ◈', '⬡'))
    .catch(() => showToast('Failed to cancel.', '⚠️'));
}

function checkScheduledBroadcasts() {
  if (!firebaseReady || !firebaseDb) return;
  const now = Date.now();
  Object.entries(scheduledBroadcasts).forEach(([key, entry]) => {
    if (entry.status === 'pending' && entry.scheduledTs <= now) {
      // Push to live broadcast node (users receive it instantly)
      firebaseDb.ref('luna-broadcasts').push({
        message: entry.message,
        ts: now,
        id: 'sbc_' + key,
      }).catch(() => {});
      // Mark as sent so it never fires twice
      firebaseDb.ref(`luna-scheduled-broadcasts/${key}`)
        .update({ status: 'sent', sentTs: now })
        .catch(() => {});
      showToast('Scheduled broadcast fired ◈', '📡', 3000);
    }
  });
}

function renderScheduledList() {
  const list = document.getElementById('schedList');
  if (!list) return;
  const entries = Object.entries(scheduledBroadcasts)
    .sort((a, b) => (a[1].scheduledTs || 0) - (b[1].scheduledTs || 0));
  if (!entries.length) {
    list.innerHTML = '<div class="admin-empty">◈ No scheduled broadcasts yet.</div>';
    return;
  }
  list.innerHTML = entries.map(([key, e]) => {
    const isPending = e.status === 'pending';
    const badge = e.status === 'pending'
      ? '<span class="sched-badge pending">PENDING</span>'
      : e.status === 'sent'
      ? '<span class="sched-badge sent">SENT</span>'
      : '<span class="sched-badge cancelled">CANCELLED</span>';
    const timeLabel = new Date(e.scheduledTs).toLocaleString([], {
      month:'short', day:'numeric', hour:'2-digit', minute:'2-digit',
    });
    const countdown = isPending
      ? `<span class="sched-countdown" data-ts="${e.scheduledTs}">--:--:--</span>`
      : '';
    const cancelBtn = isPending
      ? `<button class="sched-cancel-btn" onclick="cancelScheduledBroadcast('${key}')">CANCEL</button>`
      : '';
    const cls = e.status === 'sent' ? 'sched-item sched-sent'
              : e.status === 'cancelled' ? 'sched-item sched-cancelled'
              : 'sched-item';
    return `<div class="${cls}">
      <span class="sched-msg" title="${escHtml(e.message || '')}">${escHtml(e.message || '')}</span>
      <div class="sched-meta">
        ${badge}
        <span class="sched-time-label">${timeLabel}</span>
        ${countdown}
        ${cancelBtn}
      </div>
    </div>`;
  }).join('');
  updateScheduledCountdowns();
}

function updateScheduledCountdowns() {
  document.querySelectorAll('.sched-countdown[data-ts]').forEach(el => {
    const diff = parseInt(el.dataset.ts) - Date.now();
    if (diff <= 0) {
      el.textContent = 'FIRING…';
      el.style.color = 'var(--green)';
    } else {
      const h = Math.floor(diff / 3600000);
      const m = Math.floor((diff % 3600000) / 60000);
      const s = Math.floor((diff % 60000) / 1000);
      el.textContent = `${String(h).padStart(2,'0')}:${String(m).padStart(2,'0')}:${String(s).padStart(2,'0')}`;
      el.style.color = diff < 60000 ? 'var(--crimson-bright)' : 'var(--gold)';
    }
  });
}

// ══════════════════════════════════════════════════════════════════
// ◈ BROADCAST SYSTEM — top-of-screen banners, offline persistence
// ══════════════════════════════════════════════════════════════════

// Track which broadcast IDs this user has already dismissed
function getDismissedBroadcasts() {
  try {
    const key = `luna-dismissed-bc-${currentUserId || 'guest'}`;
    return new Set(JSON.parse(localStorage.getItem(key) || '[]'));
  } catch { return new Set(); }
}

function saveDismissedBroadcast(bcId) {
  try {
    const key = `luna-dismissed-bc-${currentUserId || 'guest'}`;
    const set = getDismissedBroadcasts();
    set.add(bcId);
    // Keep only the last 100 dismissed IDs to avoid localStorage bloat
    const arr = [...set].slice(-100);
    localStorage.setItem(key, JSON.stringify(arr));
  } catch {}
}

// Dismiss a banner — animate it out, mark as dismissed, remove from DOM
function dismissBroadcast(bcId, bannerEl) {
  saveDismissedBroadcast(bcId);
  bannerEl.classList.add('dismissing');
  bannerEl.addEventListener('animationend', () => bannerEl.remove(), { once: true });
}

// Render a single broadcast as a top-of-screen banner
function renderBroadcastBanner(bcId, message, ts) {
  const area = document.getElementById('broadcastBannerArea');
  if (!area) return;

  // Don't duplicate if already showing
  if (document.getElementById(`bc_banner_${bcId}`)) return;

  const time = ts
    ? new Date(ts).toLocaleString([], { month:'short', day:'numeric', hour:'2-digit', minute:'2-digit' })
    : '';

  const banner = document.createElement('div');
  banner.className = 'bc-top-banner';
  banner.id = `bc_banner_${bcId}`;
  banner.innerHTML = `
    <div class="bc-top-icon">📡</div>
    <div class="bc-top-dot"></div>
    <span class="bc-top-label">SYSTEM BROADCAST</span>
    <span class="bc-top-msg" title="${escHtml(message)}">${escHtml(message)}</span>
    <span class="bc-top-time">${time}</span>
    <button class="bc-top-dismiss" title="Dismiss" onclick="dismissBroadcast('${bcId}', this.closest('.bc-top-banner'))">✕</button>
  `;
  area.appendChild(banner);
}

// Subscribe — fetch ALL existing + listen for new ones in real-time
function subscribeBroadcasts() {
  if (!firebaseReady || !firebaseDb) return;
  if (firebaseBroadcastUnsub) firebaseBroadcastUnsub();

  // Only show broadcasts that are pushed AFTER this user logs in.
  // Using orderByChild('ts').startAt(now) means historical messages are never delivered.
  const loginTime = Date.now();
  const ref = firebaseDb.ref('luna-broadcasts')
    .orderByChild('ts')
    .startAt(loginTime);

  ref.on('child_added', snapshot => {
    const data = snapshot.val();
    const bcId = snapshot.key;
    if (!data || !data.message || !bcId) return;
    renderBroadcastBanner(bcId, data.message, data.ts);
    showToast('📡 New system broadcast received', '◈', 3200);
  });

  firebaseBroadcastUnsub = () => ref.off('child_added');
}

// Legacy: keep renderBroadcastAlert as a no-op alias (old call sites won't break)
function renderBroadcastAlert(message, ts) {
  // Replaced by top-banner system — do nothing
}

// ══════════════════════════════════════════════════════════════════
// ◈ FEATURE 2 — TYPING INDICATOR SYNC (user → Firebase → admin)
// ══════════════════════════════════════════════════════════════════

// User side: write typing status to Firebase with debounce
let _typingWriteTimer = null;
function reportTyping() {
  if (!firebaseReady || !firebaseDb || !userName) return;
  // Debounce the WRITE — only hit Firebase every 2s, not on every keypress
  clearTimeout(typingDebounceTimer);
  typingDebounceTimer = setTimeout(() => clearTyping(), 4000);
  if (_typingWriteTimer) return; // write already scheduled
  _typingWriteTimer = setTimeout(() => {
    _typingWriteTimer = null;
    if (!firebaseReady || !firebaseDb || !userName) return;
    const key = userName.toLowerCase().replace(/[^a-z0-9]/g, '_');
    firebaseDb.ref(`luna-typing/${key}`).set({ name: userName, ts: Date.now() });
  }, 2000);
}

function clearTyping() {
  if (!firebaseReady || !firebaseDb || !userName) return;
  const key = userName.toLowerCase().replace(/[^a-z0-9]/g, '_');
  firebaseDb.ref(`luna-typing/${key}`).remove().catch(() => {});
}

// Admin side: subscribe to typing statuses
function subscribeTypingStatus() {
  if (!firebaseReady || !firebaseDb) return;
  if (firebaseTypingUnsub) firebaseTypingUnsub();
  const ref = firebaseDb.ref('luna-typing');
  ref.on('value', snapshot => {
    const data = snapshot.val();
    updateAdminTypingUI(data);
  });
  firebaseTypingUnsub = () => ref.off('value');
}

function unsubscribeTypingStatus() {
  if (firebaseTypingUnsub) { firebaseTypingUnsub(); firebaseTypingUnsub = null; }
}

// Update the typing strip in the admin panel
function updateAdminTypingUI(data) {
  const strip = document.getElementById('adminTypingStrip');
  const label = document.getElementById('adminTypingText');
  if (!strip || !label) return;
  if (!data || !Object.keys(data).length) {
    strip.className = 'admin-typing-strip idle';
    label.textContent = '◈ No one is typing right now…';
    return;
  }
  // Filter out stale entries (older than 6 seconds)
  const now = Date.now();
  const active = Object.values(data).filter(d => d.ts && (now - d.ts) < 6000);
  if (!active.length) {
    strip.className = 'admin-typing-strip idle';
    label.textContent = '◈ No one is typing right now…';
    return;
  }
  const names = active.map(d => d.name).join(', ');
  const plural = active.length > 1 ? 'are' : 'is';
  strip.className = 'admin-typing-strip';
  label.textContent = `${names} ${plural} typing…`;
}

// ══════════════════════════════════════════════════════════════════
// ◈ FEATURE 3 — LUNA MOOD RING (sentiment → avatar color shift)
// ══════════════════════════════════════════════════════════════════

const SENTIMENT = {
  positive: [
    'love','happy','great','amazing','wonderful','fantastic','excellent',
    'thank','thanks','perfect','awesome','beautiful','brilliant','good',
    'nice','glad','joy','fun','enjoy','please','grateful','appreciate',
    'cute','sweet','kind','gentle','helpful','hope','excited','yay',
    'wow','best','cool','interesting','fascinating','impressive','like',
    'mahal','salamat','ganda','maganda','masaya','mabuti','grabe', 'saya',
  ],
  negative: [
    'hate','angry','frustrated','annoyed','stupid','awful','terrible',
    'horrible','worst','useless','idiot','dumb','mad','upset','sad',
    'depressed','anxious','scared','worried','stressed','tired','lost',
    'confused','bad','wrong','broken','failed','failing','cry','crying',
    'lonely','alone','hopeless','pathetic','disgusting','trash',
    'galit','malungkot','pagod','wala','bobo','tanga','sawa','ayaw',
  ],
};

function scoreSentiment(text) {
  const words = text.toLowerCase().replace(/[^a-z\u00C0-\u024F\s]/g, '').split(/\s+/);
  let delta = 0;
  words.forEach(w => {
    if (SENTIMENT.positive.includes(w)) delta += 2;
    if (SENTIMENT.negative.includes(w)) delta -= 3; // weight negative slightly higher
  });
  return delta;
}

function updateMoodRing(textChunk) {
  moodScore = Math.max(-20, Math.min(20, moodScore + scoreSentiment(textChunk)));
  // Decay toward neutral over time
  moodScore *= 0.88;

  let newMood;
  if      (moodScore >  2.5) newMood = 'positive';
  else if (moodScore < -2.5) newMood = 'tense';
  else                       newMood = 'neutral';

  if (newMood === currentMood) return;
  currentMood = newMood;

  // Sentiment mood tracked for internal scoring only;
  // bubble/avatar colors are driven by lunaMood persona (setLunaMood).
  document.body.dataset.sentimentMood = newMood;
}

// ══════════════════════════════════════════════════════════════════
// ◈ TONE DETECTOR — auto-reads user message and shifts Luna's mood
// ══════════════════════════════════════════════════════════════════

// High-weight emotional distress words — these override the short-message chill heuristic
const CORE_DISTRESS = new Set([
  'sad','cry','crying','lonely','alone','depressed','depression','hopeless',
  'anxious','anxiety','heartbreak','heartbroken','hurt','broken','lost',
  'overwhelmed','exhausted','grief','grieving','miss','miss ko na sya',
  'naiinis','naiinis ako','nagseselos','nagseselos ako',
  'naiiyak','malungkot','nalulungkot','nasaktan','takot','pagod','sawa',
]);

// High-weight analytical/question words — these override the short-message chill heuristic
const CORE_QUESTION = new Set([
  'what','why','how','define','explain','meaning','describe','summarize',
  'difference','compare','analyze','calculate','solve','teach','understand',
  'definition','explain','clarify','elaborate','breakdown','breakdown',
  'paano','bakit','ano','ipaliwanag','ituro','ibig','sabihin','who','give','who is',
]);

// High-weight anger words — give tense equal standing with empathic/smart boosts
// These also override the short-message chill heuristic
const CORE_ANGER = new Set([
  'hate','angry','anger','furious','rage','pissed','mad','livid','enraged',
  'frustrated','frustrated','irritated','annoyed','fed up','sick of',
  'stupid','idiot','moron','useless','garbage','trash','scam','lied',
  'wtf','wth','damn','hell','ugh','argh','grrr','stfu',
  // Filipino anger words
  'tanga','bobo','gago','putangina','tangina','ulol','leche','puta',
  'galit','inis','badtrip','hayop','hayop ka','gago ka','bobo ka',
  'putcha','pucha','bwisit','nakakairita','nakakainis',
]);

const TONE_SIGNALS = {
  // Technical / informational signals
  smart: [
    'how','why','what','explain','define','describe','teach','help me',
    'can you','could you','tutorial','example','difference','compare',
    'step by step','steps','instructions','guide','show me','list',
    'code','function','script','error','bug','fix','debug','syntax',
    'math','formula','equation','calculate','solve','proof','theorem',
    'meaning','definition','summarize','analyze','research','study',
    'paano','bakit','ano','ano ang','ipaliwanag','ituro','gawin','tulungan',
    'ibig','sabihin','ibig sabihin','ano ibig sabihin','anong ibig sabihin',
    'can u','pls explain','tell me about','what is','what are','who is','who','sino','sino si',
    'algorithm','database','api','server','network','system','process',
  ],
  // Emotional / personal / vulnerable signals (pure empathy — no angry words here)
  empathic: [
    'feel','sad','miss','love','worried','lonely','alone',
    'cry','crying','lost','confused','hopeless','tired','exhausted',
    'depressed','anxious','stress','stressed','overwhelmed','heartbreak',
    'please help','need help','support','understand me','listen',
    'happy','excited','grateful','thankful','blessed','touched','moved',
    'mahal','nalulungkot','naiiyak','sawa','pagod','takot','malungkot',
    'nasaktan','gusto ko','miss kita','masaya','kinikilig','inlove',
    'nervous','disappointed','betrayed','nagseselos','nagseselos ako',
    'wish','hope','dream','pray','dear','heart','soul','feel like','miss','miss ko','miss ko na sya',
  ],
  // Tense / angry / frustrated signals — expanded and exclusive
  tense: [
    'hate','angry','anger','furious','rage','pissed','mad','livid','enraged',
    'frustrated','irritated','annoyed','fed up','sick of','enough','stop','quit',
    'stupid','idiot','moron','useless','terrible','awful','worst','failed',
    'wtf','wth','what the hell','why the hell','are you serious','seriously','ugh','argh',
    'damn','hell','stfu','shut up','shut your','get out','leave me',
    'not working','doesnt work','broken','garbage','trash','scam',
    'lied','lie','wrong','mistake','unacceptable','ridiculous','pathetic',
    'hurt me','betrayed me','i hate','so mad','so angry','really mad',
    // Filipino tense
    'tanga','bobo','gago','putangina','tangina','ulol','leche','puta',
    'galit','inis','badtrip','bad trip','ayaw ko na','sobra na',
    'bwisit','nakakairita','nakakainis','putcha','pucha','hayop','hayop ka',
    'gago ka','bobo ka','tanga ka','inisin','iniirita','napaka',
  ],
  // Casual / chill / conversational signals
  chill: [
    'haha','hehe','lol','lmao','omg','wow','oh','ah','hmm','okay','ok',
    'sige','oo','noh','nga','grabe','talaga','naman','dba','di ba',
    'hey','hi','hello','sup','yo','kamusta','kumusta','musta',
    'nice','cool','cute','sweet','fun','interesting','random',
    'bored','chilling','chill','vibes','mood','same','same here',
    'hays','naks','aww','awww','aww naman','haha oo','basta',
    'ano ba','kaloka','charot','joke','kidding','jk','haha jk','eme','joke lang',
  ],
};

let _toneChipTimer = null;

function detectToneFromMessage(text) {
  const lower = text.toLowerCase();
  const words = lower.replace(/[^\w\s]/g, ' ').split(/\s+/);

  const scores = { smart: 0, empathic: 0, tense: 0, chill: 0 };

  // Score multi-word phrases first
  for (const [tone, signals] of Object.entries(TONE_SIGNALS)) {
    for (const sig of signals) {
      if (sig.includes(' ') && lower.includes(sig)) {
        scores[tone] += sig.split(' ').length * 1.8; // phrase bonus
      }
    }
    // Score individual words — core distress/anger/question words get double weight
    for (const word of words) {
      if (word && TONE_SIGNALS[tone].includes(word)) {
        const isHighWeight =
          (tone === 'empathic' && CORE_DISTRESS.has(word)) ||
          (tone === 'smart'    && CORE_QUESTION.has(word)) ||
          (tone === 'tense'    && CORE_ANGER.has(word));    // ← tense now gets double weight too
        scores[tone] += isHighWeight ? 2 : 1;
      }
    }
  }

  const wordCount = words.filter(Boolean).length;
  const hasDistressWord  = words.some(w => CORE_DISTRESS.has(w));
  const hasQuestionWord  = words.some(w => CORE_QUESTION.has(w));
  const hasAngerWord     = words.some(w => CORE_ANGER.has(w));      // ← new anger check

  // Short messages lean casual UNLESS a strong signal word is present
  if (wordCount <= 4 && !hasDistressWord && !hasQuestionWord && !hasAngerWord) {
    scores.chill += 1.5;
  }

  // Anger override: even a single CORE_ANGER word in a short message forces tense
  if (hasAngerWord) {
    scores.tense += 2.5;  // hard boost so anger words always win
  }

  // Questions lean technical
  if (/\?/.test(text)) scores.smart += 1.2;

  // ALL-CAPS words lean tense
  const capsWords = (text.match(/\b[A-Z]{3,}\b/g) || []).length;
  if (capsWords > 0) scores.tense += capsWords * 1.0; // bumped from 0.8 → 1.0

  // Multiple exclamation points lean tense
  const excl = (text.match(/!/g) || []).length;
  if (excl >= 2) scores.tense += excl * 0.7; // bumped from 0.5 → 0.7

  // Laughter patterns → chill
  if (/ha(ha)+|he(he)+|hi(hi)+/i.test(text)) scores.chill += 2.5;

  // Find the winning tone
  const winner = Object.entries(scores).reduce((a, b) => b[1] > a[1] ? b : a);
  // If all scores are 0 or very low, default to chill
  return winner[1] >= 0.8 ? winner[0] : 'chill';
}

function showToneChip(mood) {
  const chip  = document.getElementById('toneChip');
  const label = document.getElementById('toneChipLabel');
  if (!chip || !label) return;

  const meta = {
    chill:    { text: '🌙 CHILL VIBES', cls: 'tone-chill' },
    empathic: { text: '💜 EMOTIONAL TONE', cls: 'tone-empathic' },
    smart:    { text: '⚡ ANALYTICAL TONE', cls: 'tone-smart' },
    tense:    { text: '🔴 TENSE DETECTED', cls: 'tone-tense' },
  };
  const m = meta[mood] || meta.chill;

  // Reset classes
  chip.className = `visible ${m.cls}`;
  label.textContent = m.text;

  // Clear previous timer and set new one
  if (_toneChipTimer) clearTimeout(_toneChipTimer);
  _toneChipTimer = setTimeout(() => {
    chip.classList.remove('visible');
    _toneChipTimer = null;
  }, 2800);
}

function autoSetLunaMood(mood) {
  const changed = lunaMood !== mood;
  lunaMood = mood;

  // Update mood indicator strip (always keep in sync)
  document.querySelectorAll('.ps-btn').forEach(btn => {
    btn.classList.toggle('ps-active', btn.dataset.mood === mood);
  });

  // Update mini dot in collapsed sidebar
  const miniDot = document.getElementById('personaMiniDot');
  if (miniDot) miniDot.className = `persona-mini-dot mood-${mood}`;

  if (changed) {
    // Flash the avatar ring to signal the shift
    const avatars = document.querySelectorAll('.av-luna');
    avatars.forEach(av => {
      av.classList.add('luna-ring-shift');
      setTimeout(() => av.classList.remove('luna-ring-shift'), 400);
    });

    // Re-color all existing bubbles + avatars
    applyMoodToAllBubbles();
  }

  // Show the tone chip above the input (always, so user sees detected mood)
  showToneChip(mood);

  // ── Sync streak egg to mood moon ──────────────────────────────
  if (typeof updateStreakEggByMood === 'function') updateStreakEggByMood(mood);
}

// Helper: apply current persona mood to avatar + bubble on creation
function applyMoodToAvatar(avEl) {
  if (!avEl) return;
  avEl.classList.remove('mood-chill','mood-empathic','mood-smart','mood-tense');
  avEl.classList.add(`mood-${lunaMood}`);
}

// Apply mood class to the parent .message.luna wrap for bubble coloring
function applyMoodToWrap(wrap) {
  if (!wrap) return;
  wrap.classList.remove('mood-chill','mood-empathic','mood-smart','mood-tense');
  wrap.classList.add(`mood-${lunaMood}`);
}

// Re-apply mood to all existing luna messages (called on persona switch)
function applyMoodToAllBubbles() {
  document.querySelectorAll('.av-luna').forEach(av => {
    av.classList.remove('mood-chill','mood-empathic','mood-smart','mood-tense');
    av.classList.add(`mood-${lunaMood}`);
  });
  document.querySelectorAll('.message.luna').forEach(wrap => {
    wrap.classList.remove('mood-chill','mood-empathic','mood-smart','mood-tense');
    wrap.classList.add(`mood-${lunaMood}`);
  });
}

function setTheme(theme) {
  document.documentElement.setAttribute('data-theme', theme);
  localStorage.setItem('luna-theme', theme);
  document.querySelectorAll('.theme-swatch').forEach(s => {
    s.classList.toggle('active', s.dataset.t === theme);
  });
  initParticles();
  const themeNames = { neural:'Neural', astral:'Astral', solar:'Solar', galactic:'Galactic' };
  showToast(`Theme: ${themeNames[theme] || theme} ✦`, '🎨');
}

function loadTheme() {
  const saved = localStorage.getItem('luna-theme') || 'neural';
  document.documentElement.setAttribute('data-theme', saved);
  document.querySelectorAll('.theme-swatch').forEach(s => {
    s.classList.toggle('active', s.dataset.t === saved);
  });
}

// ── Mobile Sidebar (legacy alias — delegates to main toggleMobileMenu) ──
// BUG FIX: old function used 'mob-open' class and wrong 'mobBackdrop' ID.
// Aliases now delegate to the canonical toggleMobileMenu/closeMobileMenu.
function toggleMobileSidebar() { toggleMobileMenu(); }
function closeMobileSidebar()  { closeMobileMenu();  }

// ── Sidebar toggle ────────────────────────────────────────────────
function initSidebar() {
  document.getElementById('sidebarToggle').addEventListener('click', () => {
    sidebar.classList.toggle('collapsed');
  });
  document.querySelectorAll('.nav-item').forEach(btn => {
    btn.addEventListener('click', () => {
      if (window.innerWidth <= 680) closeMobileSidebar();
    });
  });
}

// ── FAB Scroll ────────────────────────────────────────────────────
function initFab() {
  chatFeed.addEventListener('scroll', () => {
    const nearBottom = chatFeed.scrollHeight - chatFeed.scrollTop - chatFeed.clientHeight < 80;
    userScrolledUp = !nearBottom;
    if (userScrolledUp) {
      fabScroll.classList.add('visible');
    } else {
      fabScroll.classList.remove('visible');
      newMsgCount = 0;
      fabBadge.style.display = 'none';
    }
  }, { passive: true });
}

function scrollDown(force = false) {
  requestAnimationFrame(() => {
    // Use instant scroll on mobile — smooth scroll causes continuous layout recalc
    chatFeed.scrollTo({ top: chatFeed.scrollHeight, behavior: IS_MOBILE ? 'auto' : 'smooth' });
    if (force) {
      newMsgCount = 0;
      fabBadge.style.display = 'none';
      fabScroll.classList.remove('visible');
    }
  });
}

// ── Live Clock ────────────────────────────────────────────────────
function initClock() {
  const el = document.getElementById('liveClock');
  function tick() {
    const now  = new Date();
    const raw  = now.getHours();
    const ampm = raw >= 12 ? 'PM' : 'AM';
    const h    = String(raw % 12 || 12).padStart(2, '0');
    const m    = String(now.getMinutes()).padStart(2, '0');
    const s    = String(now.getSeconds()).padStart(2, '0');
    if (el) {
      el.innerHTML = `${h}:${m}:${s} <span style="font-size:7px;letter-spacing:0.1em;opacity:0.75;vertical-align:middle;">${ampm}</span>`;
    }
  }
  tick();
  setInterval(tick, 1000);
}

// ── Real Signal Strength ──────────────────────────────────────────
// Reads navigator.connection (Network Information API) where available,
// and falls back to a periodic ping-latency measurement.
// Updates the 4 .signal-bars spans and adds a tooltip.
function initSignalBars() {
  const container = document.querySelector('.signal-bars');
  if (!container) return;

  // Colour palette per strength level (1–4)
  const LEVEL_COLORS = {
    1: '#ef4444', // red  — very weak
    2: '#f59e0b', // amber — weak
    3: '#a855f7', // violet — good
    4: '#34d399', // green  — strong
  };

  // Map Network Information API effectiveType to a bar level
  function effectiveTypeToLevel(et) {
    if (et === '4g')  return 4;
    if (et === '3g')  return 3;
    if (et === '2g')  return 2;
    return 1; // slow-2g or unknown
  }

  // Map ping latency (ms) to bar level
  function latencyToLevel(ms) {
    if (ms < 80)   return 4;
    if (ms < 200)  return 3;
    if (ms < 500)  return 2;
    return 1;
  }

  // Map level to a human label
  const LEVEL_LABELS = { 1: 'Weak', 2: 'Fair', 3: 'Good', 4: 'Strong' };

  function applyLevel(level) {
    const spans = container.querySelectorAll('span');
    spans.forEach((s, i) => {
      const active = i < level;
      const col    = active ? LEVEL_COLORS[level] : 'rgba(255,255,255,0.12)';
      s.style.background  = col;
      s.style.boxShadow   = active ? `0 0 5px ${col}` : 'none';
      s.style.opacity     = '1';
      // Pause the decorative animation — real signal doesn't need it
      s.style.animation   = 'none';
    });
    container.title = `Signal: ${LEVEL_LABELS[level] || 'Unknown'}`;
  }

  // Offline shortcut
  if (!navigator.onLine) { applyLevel(0); return; }

  // ── Primary: Network Information API ──────────────────────────
  const conn = navigator.connection || navigator.mozConnection || navigator.webkitConnection;
  if (conn) {
    function onConnChange() {
      if (!navigator.onLine) { applyLevel(1); return; }
      // Prefer downlink (Mbps) for precision when available
      if (conn.downlink != null && conn.downlink > 0) {
        let lvl;
        if (conn.downlink >= 10) lvl = 4;
        else if (conn.downlink >= 2) lvl = 3;
        else if (conn.downlink >= 0.5) lvl = 2;
        else lvl = 1;
        applyLevel(lvl);
      } else if (conn.effectiveType) {
        applyLevel(effectiveTypeToLevel(conn.effectiveType));
      }
    }
    conn.addEventListener('change', onConnChange);
    onConnChange(); // initial read
  }

  // ── Fallback / supplement: ping-latency probe every 8 s ───────
  // Uses a tiny request to a public fast endpoint; result refines
  // the level even when the Network API is unavailable.
  async function probePing() {
    if (!navigator.onLine) { applyLevel(1); return; }
    const t0 = performance.now();
    try {
      await fetch('https://www.google.com/generate_204', {
        method: 'HEAD', mode: 'no-cors', cache: 'no-store',
      });
      const ms = performance.now() - t0;
      // Only override if conn API is absent (avoid fighting it)
      if (!conn) applyLevel(latencyToLevel(ms));
    } catch {
      if (!conn) applyLevel(1);
    }
  }
  probePing();
  setInterval(probePing, 8000);

  // Online/offline events
  window.addEventListener('online',  () => { probePing(); });
  window.addEventListener('offline', () => { applyLevel(1); });
}

// ── Toast System ─────────────────────────────────────────────────
function showToast(msg, icon = '◈', duration = 2800) {
  const container = document.getElementById('toastContainer');
  const el = document.createElement('div');
  el.className = 'toast';
  el.innerHTML = `<span style="font-size:16px">${icon}</span><span>${msg}</span>`;
  container.appendChild(el);
  setTimeout(() => {
    el.classList.add('removing');
    el.addEventListener('animationend', () => el.remove());
  }, duration);
}

// ── Ripple Effect ─────────────────────────────────────────────────
function addRipple(e, el) {
  const rect = el.getBoundingClientRect();
  const r = document.createElement('span');
  r.className = 'ripple';
  const size = Math.max(rect.width, rect.height);
  r.style.cssText = `width:${size}px;height:${size}px;left:${e.clientX - rect.left - size/2}px;top:${e.clientY - rect.top - size/2}px;`;
  el.appendChild(r);
  r.addEventListener('animationend', () => r.remove());
}

// ── Keyboard Shortcuts ────────────────────────────────────────────
function initKeyboardShortcuts() {
  document.addEventListener('keydown', e => {
    if (e.ctrlKey && e.key === 'k') { e.preventDefault(); showKeyboardShortcuts(); }
    if (e.ctrlKey && e.key === 'l') { e.preventDefault(); msgCount = 0; renderWelcome(); showToast('Conversation cleared ✦', '◈'); }
    if (e.ctrlKey && e.key === 'e') { e.preventDefault(); exportConversation(); }
    if (e.ctrlKey && e.key === 'f') { e.preventDefault(); openSearch(); }
    if (e.ctrlKey && e.key === 'b') { e.preventDefault(); sidebar.classList.toggle('collapsed'); }
    if (e.key === 'Escape') {
      document.querySelector('.modal-overlay')?.remove();
      closeSearch();
    }
    if (e.key === '/' && document.activeElement !== userInput && document.activeElement.tagName !== 'TEXTAREA' && document.activeElement.tagName !== 'INPUT') {
      e.preventDefault(); userInput.focus();
    }
  });
}

function showKeyboardShortcuts() {
  const overlay = document.createElement('div');
  overlay.className = 'modal-overlay';
  overlay.innerHTML = `
    <div class="modal-box">
      <button class="modal-close" onclick="this.closest('.modal-overlay').remove()">✕ CLOSE</button>
      <h2 class="modal-title">KEYBOARD SHORTCUTS</h2>
      <div class="kbd-grid">
        <div class="kbd-item"><span class="kbd-desc">Send message</span><span class="kbd-keys"><kbd>Enter</kbd></span></div>
        <div class="kbd-item"><span class="kbd-desc">New line</span><span class="kbd-keys"><kbd>Shift</kbd><kbd>↵</kbd></span></div>
        <div class="kbd-item"><span class="kbd-desc">Shortcuts</span><span class="kbd-keys"><kbd>Ctrl</kbd><kbd>K</kbd></span></div>
        <div class="kbd-item"><span class="kbd-desc">Clear chat</span><span class="kbd-keys"><kbd>Ctrl</kbd><kbd>L</kbd></span></div>
        <div class="kbd-item"><span class="kbd-desc">Export chat</span><span class="kbd-keys"><kbd>Ctrl</kbd><kbd>E</kbd></span></div>
        <div class="kbd-item"><span class="kbd-desc">Search</span><span class="kbd-keys"><kbd>Ctrl</kbd><kbd>F</kbd></span></div>
        <div class="kbd-item"><span class="kbd-desc">Toggle sidebar</span><span class="kbd-keys"><kbd>Ctrl</kbd><kbd>B</kbd></span></div>
        <div class="kbd-item"><span class="kbd-desc">Focus input</span><span class="kbd-keys"><kbd>/</kbd></span></div>
        <div class="kbd-item"><span class="kbd-desc">Close modal</span><span class="kbd-keys"><kbd>Esc</kbd></span></div>
        <div class="kbd-item"><span class="kbd-desc">Regenerate</span><span class="kbd-keys"><kbd>Ctrl</kbd><kbd>R</kbd></span></div>
      </div>
    </div>
  `;
  overlay.addEventListener('click', e => { if (e.target === overlay) overlay.remove(); });
  document.body.appendChild(overlay);
}

// ── About Modal ───────────────────────────────────────────────────
function showAbout() {
  const overlay = document.createElement('div');
  overlay.className = 'modal-overlay';
  overlay.innerHTML = `
    <div class="modal-box">
      <button class="modal-close" onclick="this.closest('.modal-overlay').remove()">✕ CLOSE</button>
      <h2 class="modal-title">ABOUT LUNA</h2>
      <div class="about-row"><div class="about-dot"></div><p class="about-text"><strong>Version:</strong> Luna v4.2 Neural Intelligence — Firebase Sync Edition</p></div>
      <div class="about-row"><div class="about-dot"></div><p class="about-text"><strong>Architecture:</strong> Groq API · LLaMA vision + GPT-OSS models</p></div>
      <div class="about-row"><div class="about-dot"></div><p class="about-text"><strong>Features:</strong> Streaming responses · Link reading · File upload · Image vision · Bilingual (EN/FIL)</p></div>
      <div class="about-row"><div class="about-dot"></div><p class="about-text"><strong>New in v4.2:</strong> 🔥 Firebase Realtime Sync — Admin sets status on laptop, mobile user sees it instantly</p></div>
      <div class="about-row"><div class="about-dot"></div><p class="about-text"><strong>Design:</strong> Futuristic HUD interface with particle system, glassmorphism, and full animation suite ✦</p></div>
    </div>
  `;
  overlay.addEventListener('click', e => { if (e.target === overlay) overlay.remove(); });
  document.body.appendChild(overlay);
}

// ── Settings Modal ────────────────────────────────────────────────
function showSettings() {
  const overlay = document.createElement('div');
  overlay.className = 'modal-overlay';

  const pct      = Math.round((tokensUsedToday / TOKEN_DAILY_LIMIT) * 100);
  const barColor = tokensUsedToday / TOKEN_DAILY_LIMIT >= TOKEN_CRIT_PCT
    ? 'linear-gradient(90deg,var(--crimson),var(--crimson-bright))'
    : tokensUsedToday / TOKEN_DAILY_LIMIT >= TOKEN_WARN_PCT
      ? 'linear-gradient(90deg,#b45309,var(--gold))'
      : 'linear-gradient(90deg,#059669,#34d399)';

  const convCount  = (typeof getConvCount    === 'function') ? getConvCount()    : 0;
  const curTheme   = document.documentElement.getAttribute('data-theme') || 'neural';
  const curMood    = (typeof lunaMood !== 'undefined') ? lunaMood : 'chill';
  const savedSounds = (() => { try { return JSON.parse(localStorage.getItem('luna-sounds') || 'true'); } catch { return true; } })();
  const savedPersona = (typeof settings.persona !== 'undefined') ? settings.persona : curMood;

  const moodEmoji  = { chill: '🌙', empathic: '💜', smart: '⚡', tense: '🔴' };
  const moodLabel  = { chill: 'Chill', empathic: 'Empathic', smart: 'Smart', tense: 'Tense' };
  const themeColors = {
    neural:   ['#ec2d5a', '#a855f7'],
    astral:   ['#6366f1', '#60a5fa'],
    solar:    ['#f59e0b', '#fb923c'],
    galactic: ['#f472b6', '#22d3ee'],
  };

  overlay.innerHTML = `
    <div class="modal-box settings-modal-box">

      <!-- ── Sticky header ── -->
      <div class="settings-header">
        <h2 class="modal-title" style="margin:0;">SETTINGS</h2>
        <button class="modal-close" style="position:static;margin:0;" onclick="this.closest('.modal-overlay').remove()">✕ CLOSE</button>
      </div>

      ${userName ? `
      <!-- ◈ SESSION PROFILE CARD -->
      <div style="padding:14px 24px 0;flex-shrink:0;">
        <div style="
          background:linear-gradient(135deg,rgba(168,85,247,0.10) 0%,rgba(236,45,90,0.06) 100%);
          border:1px solid rgba(168,85,247,0.18);
          border-radius:14px;
          padding:12px 16px;
          display:flex;gap:14px;align-items:center;
        ">
          <div style="
            width:42px;height:42px;border-radius:50%;flex-shrink:0;
            background:linear-gradient(135deg,var(--crimson-dim),var(--violet-dim));
            border:1.5px solid var(--border);
            display:flex;align-items:center;justify-content:center;
            font-size:20px;
          ">✦</div>
          <div style="flex:1;min-width:0;">
            <div style="font-family:var(--font-hud);font-size:13px;font-weight:900;color:var(--text-hi);letter-spacing:0.04em;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;">${userName}</div>
            <div style="font-family:var(--font-mono);font-size:10px;color:var(--text-mid);margin-top:2px;display:flex;gap:10px;flex-wrap:wrap;">
              <span>💬 ${convCount} messages</span>
              <span>${moodEmoji[curMood] || '🌙'} ${moodLabel[curMood] || curMood} mode</span>
            </div>
          </div>
        </div>
      </div>
      ` : ''}

      <!-- ── Tab bar ── -->
      <div class="settings-tab-bar">
        <button class="stab active" onclick="switchSettingsTab(this,'stab-persona')">🌙 PERSONA</button>
        <button class="stab" onclick="switchSettingsTab(this,'stab-appearance')">🎨 APPEARANCE</button>
        <button class="stab" onclick="switchSettingsTab(this,'stab-ai')">⚡ AI</button>
        <button class="stab" onclick="switchSettingsTab(this,'stab-interface')">🖥 INTERFACE</button>
        ${userName ? `<button class="stab" onclick="switchSettingsTab(this,'stab-account')">👤 ACCOUNT</button>` : ''}
      </div>

      <!-- ── Scrollable body ── -->
      <div class="settings-scroll-body">

        <!-- ══ TAB: PERSONA ══ -->
        <div class="settings-pane active" id="stab-persona">

          <!-- ◈ LUNA PERSONA — hero section -->
          <div class="settings-group">
            <div class="settings-group-label">◈ LUNA PERSONA</div>
            <div style="font-family:var(--font-body);font-size:11px;color:var(--text-lo);margin-bottom:14px;line-height:1.6;">
              Choose how Luna thinks, speaks, and responds to you. This changes her emotional tone and communication style across all conversations.
            </div>
            <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px;padding:4px 0;">
              ${[
                ['chill',   '🌙', 'CHILL',   'Relaxed & casual',    'Short, friendly replies. Great for everyday chat.'],
                ['empathic','💜', 'EMPATHIC','Warm & emotionally aware', 'Heartfelt, supportive. Perfect for deep conversations.'],
                ['smart',   '⚡', 'SMART',   'Precise & analytical', 'Detailed, structured. Ideal for research and study.'],
                ['tense',   '🔴', 'TENSE',   'Direct & urgent',      'Sharp, no-fluff. Best for quick, focused answers.'],
              ].map(([id, emoji, label, sub, desc]) => {
                const isActive = curMood === id;
                const moodColors = {
                  chill:   { border:'rgba(34,211,238,0.45)',  bg:'rgba(34,211,238,0.08)',  text:'#22d3ee' },
                  empathic:{ border:'rgba(168,85,247,0.45)',  bg:'rgba(168,85,247,0.10)',  text:'var(--violet-bright)' },
                  smart:   { border:'rgba(251,191,36,0.45)',  bg:'rgba(251,191,36,0.08)',  text:'var(--gold)' },
                  tense:   { border:'rgba(236,45,90,0.45)',   bg:'rgba(236,45,90,0.08)',   text:'var(--crimson-bright)' },
                };
                const mc = moodColors[id];
                return `<button onclick="setLunaMood('${id}'); document.querySelectorAll('.persona-card').forEach(b => b.classList.remove('persona-card--active')); this.classList.add('persona-card--active'); document.getElementById('settingsPersonaStatus').textContent = '${emoji} ${label} MODE ACTIVE';" class="persona-card ${isActive ? 'persona-card--active' : ''}" style="
                  padding:14px 12px 13px;border-radius:13px;cursor:pointer;text-align:left;
                  background:${isActive ? mc.bg : 'rgba(255,255,255,0.025)'};
                  border:1.5px solid ${isActive ? mc.border : 'rgba(255,255,255,0.07)'};
                  transition:all 0.2s ease; position:relative; overflow:hidden;
                ">
                  ${isActive ? `<div style="position:absolute;top:7px;right:9px;font-size:9px;color:${mc.text};font-family:var(--font-hud);">✦ ACTIVE</div>` : ''}
                  <div style="font-size:22px;margin-bottom:7px;">${emoji}</div>
                  <div style="font-family:var(--font-hud);font-size:9px;letter-spacing:0.14em;color:${isActive ? mc.text : 'var(--text-mid)'};margin-bottom:3px;">${label}</div>
                  <div style="font-family:var(--font-body);font-size:9.5px;color:${isActive ? 'rgba(255,255,255,0.55)' : 'rgba(255,255,255,0.22)'};line-height:1.4;">${desc}</div>
                </button>`;
              }).join('')}
            </div>

            <!-- Active persona status badge -->
            <div id="settingsPersonaStatus" style="
              margin-top:12px; padding:9px 14px;
              background:rgba(168,85,247,0.07); border:1px solid rgba(168,85,247,0.22);
              border-radius:10px; text-align:center;
              font-family:var(--font-hud); font-size:8.5px; letter-spacing:0.16em;
              color:var(--violet-bright);
            ">${moodEmoji[curMood] || '🌙'} ${(moodLabel[curMood] || curMood).toUpperCase()} MODE ACTIVE</div>
          </div>

        </div><!-- /stab-persona -->

        <!-- ══ TAB: APPEARANCE ══ -->
        <div class="settings-pane" id="stab-appearance">

          <!-- ◈ THEME -->
          <div class="settings-group">
            <div class="settings-group-label">◈ THEME</div>
            <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px;padding:4px 0;">
              ${Object.entries({ neural:'NEURAL', astral:'ASTRAL', solar:'SOLAR', galactic:'GALACTIC' }).map(([id, label]) => {
                const [c1, c2] = themeColors[id];
                const isActive = curTheme === id;
                return `<button onclick="setTheme('${id}'); document.querySelectorAll('.theme-card').forEach(b => b.classList.remove('theme-card--active')); this.classList.add('theme-card--active');" class="theme-card ${isActive ? 'theme-card--active' : ''}" style="
                  position:relative;padding:12px 10px 10px;border-radius:11px;cursor:pointer;text-align:left;
                  background:${isActive ? `rgba(168,85,247,0.10)` : 'rgba(255,255,255,0.02)'};
                  border:1.5px solid ${isActive ? `rgba(168,85,247,0.45)` : 'rgba(255,255,255,0.07)'};
                  transition:all 0.18s ease;
                ">
                  <div style="display:flex;gap:4px;margin-bottom:8px;">
                    <div style="width:10px;height:10px;border-radius:50%;background:${c1};box-shadow:0 0 6px ${c1}88;"></div>
                    <div style="width:10px;height:10px;border-radius:50%;background:${c2};box-shadow:0 0 6px ${c2}88;"></div>
                  </div>
                  <div style="font-family:var(--font-hud);font-size:9px;letter-spacing:0.18em;color:${isActive ? 'var(--violet-bright)' : 'var(--text-mid)'};">${label}</div>
                  ${isActive ? `<div style="position:absolute;top:7px;right:8px;font-size:9px;color:var(--violet-bright);">✦</div>` : ''}
                </button>`;
              }).join('')}
            </div>
          </div>

          <!-- ◈ FONT SIZE -->
          <div class="settings-group">
            <div class="settings-group-label">◈ DISPLAY</div>
            <div class="settings-row settings-row--wrap">
              <span class="settings-row-label">Font Size</span>
              <div class="settings-seg-group">
                ${[['small','0.88'],['normal','1'],['large','1.12']].map(([label,val]) =>
                  `<button class="seg-btn ${settings.fontSize===label?'active':''}" onclick="setFontSize('${label}','${val}',this)">${label.toUpperCase()}</button>`
                ).join('')}
              </div>
            </div>

            <div class="settings-row settings-row--wrap">
              <span class="settings-row-label">Particle Density</span>
              <div class="settings-seg-group">
                ${[['off','0'],['low','30'],['normal','60'],['high','100']].map(([label,val]) =>
                  `<button class="seg-btn ${settings.particleDensity===label?'active':''}" onclick="setParticles('${label}',${val},this)">${label.toUpperCase()}</button>`
                ).join('')}
              </div>
            </div>
          </div>

        </div><!-- /stab-appearance -->

        <!-- ══ TAB: AI SETTINGS ══ -->
        <div class="settings-pane" id="stab-ai">

          <!-- ◈ RESPONSE SETTINGS -->
          <div class="settings-group">
            <div class="settings-group-label">◈ RESPONSE STYLE</div>

            <div class="settings-row settings-row--col">
              <div class="settings-row-top">
                <span class="settings-row-label">Creativity</span>
                <span class="range-val" id="tempVal">${settings.temperature}</span>
              </div>
              <input type="range" class="settings-range-full" id="tempSlider" min="0.1" max="2.0" step="0.1" value="${settings.temperature}">
              <div class="settings-range-ends"><span>PRECISE</span><span>CREATIVE</span></div>
            </div>

            <div class="settings-row settings-row--col">
              <div class="settings-row-top">
                <span class="settings-row-label">Response Length</span>
                <span class="style-slider-value" id="lengthLabel">${settings.responseLength <= 25 ? 'CONCISE' : settings.responseLength >= 75 ? 'DETAILED' : 'BALANCED'}</span>
              </div>
              <input type="range" class="settings-range-full" id="lengthSlider" min="0" max="100" step="1" value="${settings.responseLength}">
              <div class="settings-range-ends"><span>CONCISE</span><span>DETAILED</span></div>
            </div>

            <div class="settings-row settings-row--col">
              <div class="settings-row-top">
                <span class="settings-row-label">Response Tone</span>
                <span class="style-slider-value" id="toneLabel">${settings.responseTone <= 25 ? 'CASUAL' : settings.responseTone >= 75 ? 'PROFESSIONAL' : 'BALANCED'}</span>
              </div>
              <input type="range" class="settings-range-full" id="toneSlider" min="0" max="100" step="1" value="${settings.responseTone}">
              <div class="settings-range-ends"><span>CASUAL</span><span>PROFESSIONAL</span></div>
            </div>
          </div>

          ${userName ? `
          <!-- ◈ LUNA TOKEN METER -->
          <div class="settings-group">
            <div class="settings-group-label">◈ DAILY TOKEN USAGE</div>
            <div class="settings-token-block">
              <div class="settings-token-header">
                <span class="settings-row-label">Daily Usage</span>
                <span class="settings-token-pct" id="settingsCapacityPct">${pct}% used</span>
              </div>
              <div class="settings-token-bar-track">
                <div id="settingsCapacityBar" class="settings-token-bar-fill" style="width:${Math.min(100,pct)}%;background:${barColor};"></div>
              </div>
              <div class="settings-token-meta">
                <span>${tokensUsedToday.toLocaleString()} tokens used</span>
                <span>${(TOKEN_DAILY_LIMIT - tokensUsedToday).toLocaleString()} remaining</span>
              </div>
              ${tokensUsedToday/TOKEN_DAILY_LIMIT >= TOKEN_WARN_PCT ? `
              <div class="settings-token-reset-row">
                <span style="font-size:14px;">🕐</span>
                <div>
                  <div class="settings-token-reset-label">RESETS AT MIDNIGHT</div>
                  <div class="settings-token-reset-time">${getNextMidnight().date} · ${getNextMidnight().time}</div>
                </div>
              </div>` : ''}
              <div class="settings-token-hint">${TOKEN_DAILY_LIMIT.toLocaleString()} tokens per day · Resets every midnight · Counter tracked locally</div>
            </div>
          </div>
          ` : ''}

          <!-- ◈ ABOUT -->
          <div class="settings-group">
            <div class="settings-group-label">◈ ABOUT LUNA</div>
            <div style="display:flex;flex-direction:column;gap:6px;">
              ${[
                ['Version',  'Quantum Core v4.2'],
                ['Model',    'GPT-OSS 120B via Groq'],
                ['Vision',   'Llama 4 Scout 17B'],
                ['Language', 'EN / FIL Bilingual'],
                ['Creator',  'John Rey Dizon'],
              ].map(([k, v]) => `
              <div style="display:flex;justify-content:space-between;align-items:center;padding:5px 0;border-bottom:1px solid rgba(255,255,255,0.04);">
                <span style="font-family:var(--font-hud);font-size:8px;letter-spacing:0.16em;color:var(--text-lo);">${k}</span>
                <span style="font-family:var(--font-mono);font-size:10px;color:var(--text-mid);">${v}</span>
              </div>`).join('')}
            </div>
          </div>

        </div><!-- /stab-ai -->

        <!-- ══ TAB: INTERFACE ══ -->
        <div class="settings-pane" id="stab-interface">

          <!-- ◈ SOUND -->
          <div class="settings-group">
            <div class="settings-group-label">◈ AUDIO</div>
            <div class="settings-row settings-row--wrap">
              <div>
                <span class="settings-row-label">Sound Effects</span>
                <div style="font-family:var(--font-body);font-size:10px;color:var(--text-lo);margin-top:2px;">Message & notification sounds</div>
              </div>
              <button id="soundToggleBtn" onclick="
                const on = !(JSON.parse(localStorage.getItem('luna-sounds')||'true'));
                localStorage.setItem('luna-sounds', JSON.stringify(on));
                this.textContent = on ? 'ON' : 'OFF';
                this.style.background   = on ? 'rgba(168,85,247,0.20)' : 'rgba(255,255,255,0.04)';
                this.style.borderColor  = on ? 'rgba(168,85,247,0.55)' : 'rgba(255,255,255,0.10)';
                this.style.color        = on ? 'var(--violet-bright)' : 'rgba(255,255,255,0.28)';
                showToast(on ? '🔔 Sounds on' : '🔕 Sounds off', on ? '🔔' : '🔕', 1400);
              " style="
                flex-shrink:0;min-width:52px;padding:6px 0;
                font-family:var(--font-hud);font-size:8px;letter-spacing:0.14em;
                border-radius:20px;cursor:pointer;transition:all 0.2s;
                ${savedSounds
                  ? 'background:rgba(168,85,247,0.20);border:1.5px solid rgba(168,85,247,0.55);color:var(--violet-bright);'
                  : 'background:rgba(255,255,255,0.04);border:1.5px solid rgba(255,255,255,0.10);color:rgba(255,255,255,0.28);'}
              ">${savedSounds ? 'ON' : 'OFF'}</button>
            </div>
          </div>

          <!-- ◈ EXPORT CHAT -->
          ${userName ? `
          <div class="settings-group">
            <div class="settings-group-label">◈ DATA EXPORT</div>
            <div class="settings-row settings-row--wrap">
              <div>
                <span class="settings-row-label">Download Conversation</span>
                <div style="font-family:var(--font-body);font-size:10px;color:var(--text-lo);margin-top:2px;">Save your chat history as a text file</div>
              </div>
              <button onclick="exportChatHistory()" style="
                flex-shrink:0;padding:7px 14px;
                font-family:var(--font-hud);font-size:8px;letter-spacing:0.14em;
                border-radius:20px;cursor:pointer;transition:all 0.2s;
                background:rgba(52,211,153,0.10);border:1.5px solid rgba(52,211,153,0.35);color:#34d399;
              ">⬇ EXPORT</button>
            </div>
            <div class="settings-row settings-row--wrap">
              <div>
                <span class="settings-row-label">Copy Last Response</span>
                <div style="font-family:var(--font-body);font-size:10px;color:var(--text-lo);margin-top:2px;">Copies Luna's most recent message</div>
              </div>
              <button onclick="
                if (!lastLunaText) { showToast('No response to copy yet.','⚠️',1500); return; }
                navigator.clipboard.writeText(lastLunaText).then(()=>showToast('✦ Copied to clipboard','📋',1600));
              " style="
                flex-shrink:0;padding:7px 14px;
                font-family:var(--font-hud);font-size:8px;letter-spacing:0.14em;
                border-radius:20px;cursor:pointer;transition:all 0.2s;
                background:rgba(168,85,247,0.10);border:1.5px solid rgba(168,85,247,0.30);color:var(--violet-bright);
              ">📋 COPY</button>
            </div>
          </div>
          ` : ''}

          <!-- ◈ KEYBOARD SHORTCUTS -->
          <div class="settings-group">
            <div class="settings-group-label">◈ KEYBOARD SHORTCUTS</div>
            ${[
              ['Enter',           'Send message'],
              ['Shift + Enter',   'New line'],
              ['Ctrl + L',        'Clear chat'],
              ['Ctrl + /',        'Focus input'],
              ['Esc',             'Close modals'],
            ].map(([key, desc]) => `
            <div style="display:flex;align-items:center;justify-content:space-between;padding:7px 0;border-bottom:1px solid rgba(255,255,255,0.04);">
              <span style="font-family:var(--font-body);font-size:11px;color:var(--text-mid);">${desc}</span>
              <kbd style="
                font-family:var(--font-mono);font-size:9px;
                background:rgba(255,255,255,0.06);border:1px solid rgba(255,255,255,0.12);
                border-radius:5px;padding:3px 7px;color:var(--text-hi);
                box-shadow:0 1px 0 rgba(255,255,255,0.08);
              ">${key}</kbd>
            </div>`).join('')}
          </div>

        </div><!-- /stab-interface -->

        ${userName ? `
        <!-- ══ TAB: ACCOUNT ══ -->
        <div class="settings-pane" id="stab-account">

          <!-- ◈ DANGER ZONE -->
          <div class="settings-group settings-danger-group">
            <div class="settings-group-label settings-danger-label">◈ DANGER ZONE</div>

            <div class="settings-danger-row">
              <div class="settings-danger-info">
                <div class="settings-row-label">Log Out</div>
                <div class="settings-danger-sub">Signed in as <strong class="settings-danger-username">${userName}</strong></div>
              </div>
              <button class="settings-action-btn settings-signout-btn" onclick="logOut(this.closest('.modal-overlay'))">⬡ SIGN OUT</button>
            </div>

            <div class="settings-divider"></div>

            <div class="settings-danger-row">
              <div class="settings-danger-info">
                <div class="settings-row-label">Delete Account</div>
                <div class="settings-danger-sub">Permanently removes all data</div>
              </div>
              <button class="settings-action-btn settings-delete-btn" onclick="deleteAccount(this.closest('.modal-overlay'))">🗑 DELETE</button>
            </div>

            <div class="settings-danger-warning">
              ⚠ This permanently deletes your account from Firebase. Your chat history and local data will be cleared. This cannot be undone.
            </div>
          </div>

        </div><!-- /stab-account -->
        ` : ''}

      </div><!-- /settings-scroll-body -->
    </div>
  `;

  // ── Tab switcher helper ────────────────────────────────────────────
  overlay.switchSettingsTab = function(btn, paneId) {
    overlay.querySelectorAll('.stab').forEach(t => t.classList.remove('active'));
    overlay.querySelectorAll('.settings-pane').forEach(p => p.classList.remove('active'));
    btn.classList.add('active');
    const pane = overlay.querySelector('#' + paneId);
    if (pane) pane.classList.add('active');
  };
  // Make the function globally accessible while modal is open
  window.switchSettingsTab = (btn, paneId) => overlay.switchSettingsTab(btn, paneId);

  const slider = overlay.querySelector('#tempSlider');
  const valDisplay = overlay.querySelector('#tempVal');
  slider.addEventListener('input', () => {
    settings.temperature = parseFloat(slider.value);
    valDisplay.textContent = slider.value;
    localStorage.setItem('luna-settings', JSON.stringify(settings));
  });

  // ── Response Length slider ──────────────────────────────────────
  const lengthSlider = overlay.querySelector('#lengthSlider');
  const lengthLabel  = overlay.querySelector('#lengthLabel');
  function lengthLabelText(v) { return v <= 25 ? 'CONCISE' : v >= 75 ? 'DETAILED' : 'BALANCED'; }
  lengthSlider.addEventListener('input', () => {
    settings.responseLength = parseInt(lengthSlider.value);
    lengthLabel.textContent  = lengthLabelText(settings.responseLength);
    localStorage.setItem('luna-settings', JSON.stringify(settings));
  });

  // ── Response Tone slider ────────────────────────────────────────
  const toneSlider = overlay.querySelector('#toneSlider');
  const toneLabel  = overlay.querySelector('#toneLabel');
  function toneLabelText(v) { return v <= 25 ? 'CASUAL' : v >= 75 ? 'PROFESSIONAL' : 'BALANCED'; }
  toneSlider.addEventListener('input', () => {
    settings.responseTone = parseInt(toneSlider.value);
    toneLabel.textContent  = toneLabelText(settings.responseTone);
    localStorage.setItem('luna-settings', JSON.stringify(settings));
  });

  overlay.addEventListener('click', e => { if (e.target === overlay) overlay.remove(); });
  document.body.appendChild(overlay);
}

// ── Export Chat History ───────────────────────────────────────────
function exportChatHistory() {
  if (!conversationHistory || conversationHistory.length === 0) {
    showToast('No messages to export yet.', '⚠️', 1800);
    return;
  }
  const lines = [`LUNA AI — Chat Export\nUser: ${userName || 'Guest'}\nDate: ${new Date().toLocaleString()}\n${'─'.repeat(48)}\n`];
  conversationHistory.forEach(msg => {
    if (msg.role === 'system') return;
    const who  = msg.role === 'assistant' ? 'LUNA' : (userName || 'YOU').toUpperCase();
    const text = typeof msg.content === 'string' ? msg.content : (msg.content?.[0]?.text || '');
    lines.push(`[${who}]\n${text}\n`);
  });
  const blob = new Blob([lines.join('\n')], { type: 'text/plain' });
  const url  = URL.createObjectURL(blob);
  const a    = document.createElement('a');
  a.href     = url;
  a.download = `luna-chat-${Date.now()}.txt`;
  a.click();
  URL.revokeObjectURL(url);
  showToast('✦ Chat exported successfully', '⬇', 2000);
}

// ── Log Out ───────────────────────────────────────────────────────
async function logOut(modalOverlay) {
  if (!userName) { showToast('You are not signed in.', '⚠️'); return; }

  // Close settings modal
  if (modalOverlay) modalOverlay.remove();

  // Mark offline in Firebase and stop listeners
  try {
    await setPresence(false);
  } catch {}
  clearTyping();
  if (firebaseUnsubscribe)    { firebaseUnsubscribe();    firebaseUnsubscribe    = null; }
  if (firebaseBroadcastUnsub) { firebaseBroadcastUnsub(); firebaseBroadcastUnsub = null; }
  unsubscribePresence();

  // Reset session state (keep settings & theme — user may log back in)
  clearPersistedSession();
  userName            = null;
  currentUserId       = null;
  capacityExhausted   = false;
  tokensUsedToday     = 0;
  conversationHistory = [];
  persistedHistory    = [];
  userProfileCache    = {};
  allRegisteredUsers  = [];
  replyingTo          = null;
  lastUserText        = '';
  lastLunaText        = '';

  // Hide capacity-exhausted screen if showing
  const exScr = document.getElementById('capacityExhaustedScreen');
  if (exScr) exScr.style.display = 'none';

  // Close broadcast banners
  document.querySelectorAll('.bc-top-banner').forEach(b => b.remove());

  // Re-enable input
  const inp = document.getElementById('userInput');
  const snd = document.getElementById('sendBtn');
  if (inp) { inp.disabled = false; inp.placeholder = 'Transmit your query to Luna...'; inp.style.opacity = ''; }
  if (snd) snd.disabled = false;

  // Return to auth overlay
  const overlay = document.getElementById('nameEntryOverlay');
  overlay.style.display = 'flex';
  overlay.classList.remove('hiding');
  document.getElementById('nameInput').value = '';
  document.getElementById('passwordInput').value = '';
  document.getElementById('nameSubmitBtn').disabled = true;
  appState = 'name-entry';

  // Reset chat feed
  const mainPanel = document.getElementById('mainPanel');
  if (mainPanel) mainPanel.style.display = 'none';
  setTimeout(() => {
    if (mainPanel) mainPanel.style.display = '';
    renderWelcome();
    document.getElementById('nameInput').focus();
  }, 50);

  showToast('Signed out successfully ◈', '⬡', 2500);
}

// ── Delete Account ────────────────────────────────────────────────
async function deleteAccount(modalOverlay) {
  if (!userName || !currentUserId) {
    showToast('No account to delete — you are not signed in.', '⚠️');
    return;
  }
  const confirmed = window.confirm(
    `Delete account "${userName}"?\n\nThis will permanently remove your account from Firebase.\nThis cannot be undone.`
  );
  if (!confirmed) return;

  // Close the settings modal
  if (modalOverlay) modalOverlay.remove();

  try {
    if (firebaseReady && firebaseDb) {
      // Delete account record
      await firebaseDb.ref(`luna-accounts/${currentUserId}`).remove();
      // Remove presence record
      await firebaseDb.ref(`luna-presence/${currentUserId}`).remove();
      // Remove ban record if any
      await firebaseDb.ref(`luna-bans/${currentUserId}`).remove().catch(() => {});
    }

    // Clear local session data
    clearPersistedSession();
    const keysToRemove = [
      'luna-settings',
      'luna-theme',
      'luna-admin-statuses',
      TOKEN_STORAGE_KEY(),
    ];
    keysToRemove.forEach(k => { try { localStorage.removeItem(k); } catch {} });

    // Reset state
    clearPersistedSession();
    userName      = null;
    currentUserId = null;
    capacityExhausted   = false;
    tokensUsedToday     = 0;
    conversationHistory = [];
    persistedHistory    = [];
    userProfileCache    = {};
    allRegisteredUsers  = [];

    // Hide exhausted screen if showing
    const exScr = document.getElementById('capacityExhaustedScreen');
    if (exScr) exScr.style.display = 'none';

    // Re-enable input
    const inp = document.getElementById('userInput');
    const snd = document.getElementById('sendBtn');
    if (inp) { inp.disabled = false; inp.placeholder = 'Transmit your query to Luna...'; }
    if (snd) snd.disabled = false;

    // Return to auth overlay
    const overlay = document.getElementById('nameEntryOverlay');
    overlay.style.display = 'flex';
    overlay.classList.remove('hiding');
    document.getElementById('nameInput').value = '';
    document.getElementById('passwordInput').value = '';
    document.getElementById('nameSubmitBtn').disabled = true;
    appState = 'name-entry';

    // Hide main panel
    const mainPanel = document.getElementById('mainPanel');
    if (mainPanel) mainPanel.style.display = 'none';
    setTimeout(() => {
      if (mainPanel) mainPanel.style.display = '';
      document.getElementById('nameInput').focus();
    }, 50);

    showToast('Account deleted successfully ◈', '🗑', 3000);
  } catch (err) {
    console.warn('Delete account error:', err);
    showToast('Failed to delete account. Check your connection.', '⚠️');
  }
}

function setSetting(key, val, btn) {
  settings[key] = val;
  btn.closest('.settings-row-ctrl').querySelectorAll('.seg-btn').forEach(b => b.classList.remove('active'));
  btn.classList.add('active');
  localStorage.setItem('luna-settings', JSON.stringify(settings));
}

function setFontSize(label, val, btn) {
  settings.fontSize = label;
  document.documentElement.style.setProperty('--font-scale', val);
  btn.closest('.settings-row-ctrl').querySelectorAll('.seg-btn').forEach(b => b.classList.remove('active'));
  btn.classList.add('active');
  localStorage.setItem('luna-settings', JSON.stringify(settings));
}

function setParticles(label, count, btn) {
  settings.particleDensity = label;
  btn.closest('.settings-row-ctrl').querySelectorAll('.seg-btn').forEach(b => b.classList.remove('active'));
  btn.classList.add('active');
  initParticles(count);
  localStorage.setItem('luna-settings', JSON.stringify(settings));
}

function loadSettings() {
  try {
    const saved = JSON.parse(localStorage.getItem('luna-settings'));
    if (saved) {
      // Migrate old responseStyle string → slider value
      if (saved.responseStyle && saved.responseLength === undefined) {
        saved.responseLength = saved.responseStyle === 'concise' ? 20 : saved.responseStyle === 'detailed' ? 80 : 50;
        delete saved.responseStyle;
      }
      settings = { ...settings, ...saved };
      const fontMap = { small: '0.88', normal: '1', large: '1.12' };
      if (fontMap[settings.fontSize]) document.documentElement.style.setProperty('--font-scale', fontMap[settings.fontSize]);
    }
  } catch {}
}

// ── Export Conversation ───────────────────────────────────────────
function exportConversation() {
  if (!conversationHistory.length) { showToast('No conversation to export yet.', '◈'); return; }
  const lines = [`LUNA AI — Conversation Export\n${'═'.repeat(40)}\nExported: ${new Date().toLocaleString()}\n${'═'.repeat(40)}\n`];
  conversationHistory.forEach(m => {
    const role = m.role === 'assistant' ? 'LUNA' : 'YOU';
    lines.push(`[${role}]\n${m.content}\n`);
  });
  const blob = new Blob([lines.join('\n')], { type: 'text/plain' });
  const a = document.createElement('a');
  a.href = URL.createObjectURL(blob);
  a.download = `luna-chat-${Date.now()}.txt`;
  a.click();
  showToast('Conversation exported ✦', '📄');
}

// ── Copy to clipboard ─────────────────────────────────────────────
async function copyToClipboard(text, btn) {
  try {
    await navigator.clipboard.writeText(text);
    if (btn) { btn.classList.add('flashed'); setTimeout(() => btn.classList.remove('flashed'), 1200); }
    showToast('Copied to clipboard ✦', '◈');
  } catch { showToast('Copy failed — try manually.', '⚠️'); }
}

function copyCode(id) {
  const el = document.getElementById(id);
  if (!el) return;
  const btn = el.closest('.code-block')?.querySelector('.code-copy');
  copyToClipboard(el.textContent, null);
  if (btn) { btn.textContent = 'COPIED'; btn.classList.add('copied'); setTimeout(() => { btn.textContent = 'COPY'; btn.classList.remove('copied'); }, 1800); }
}

// ── Text-to-Speech ────────────────────────────────────────────────
function toggleTTS(text, btn) {
  if (!('speechSynthesis' in window)) { showToast('TTS not supported in this browser.', '⚠️'); return; }
  if (window.speechSynthesis.speaking) {
    window.speechSynthesis.cancel();
    if (currentTtsBtn) currentTtsBtn.classList.remove('tts-playing');
    currentTtsBtn = null;
    if (btn && currentTtsBtn !== btn) { return; }
    return;
  }
  const cleanText = text.replace(/\*\*/g,'').replace(/\*/g,'').replace(/◈|✦/g,'').replace(/```[\s\S]*?```/g,'[code block]').trim();
  const utterance = new SpeechSynthesisUtterance(cleanText);
  utterance.rate = 0.92;
  utterance.pitch = 1.05;
  utterance.volume = 1;
  const voices = window.speechSynthesis.getVoices();
  const nice = voices.find(v => /samantha|google|aria|zira/i.test(v.name)) || voices[0];
  if (nice) utterance.voice = nice;
  utterance.onend = () => { if (btn) btn.classList.remove('tts-playing'); currentTtsBtn = null; };
  utterance.onerror = () => { if (btn) btn.classList.remove('tts-playing'); currentTtsBtn = null; };
  if (btn) btn.classList.add('tts-playing');
  currentTtsBtn = btn;
  window.speechSynthesis.speak(utterance);
}

// ── Voice Input ───────────────────────────────────────────────────
function toggleVoice() {
  const btn = document.getElementById('voiceBtn');
  if (!('webkitSpeechRecognition' in window) && !('SpeechRecognition' in window)) {
    showToast('Voice input not supported in this browser.', '⚠️');
    return;
  }
  if (isRecording) {
    voiceRecognition?.stop();
    isRecording = false;
    btn.style.color = '';
    btn.style.borderColor = '';
    return;
  }
  const SR = window.SpeechRecognition || window.webkitSpeechRecognition;
  voiceRecognition = new SR();
  voiceRecognition.lang = 'en-US';
  voiceRecognition.continuous = false;
  voiceRecognition.interimResults = false;
  voiceRecognition.onresult = e => {
    const transcript = e.results[0][0].transcript;
    userInput.value = transcript;
    handleInput();
    showToast(`Voice captured: "${transcript.slice(0,40)}..."`, '🎙️');
  };
  voiceRecognition.onerror = () => showToast('Voice recognition failed.', '⚠️');
  voiceRecognition.onend = () => {
    isRecording = false;
    btn.style.color = '';
    btn.style.borderColor = '';
  };
  voiceRecognition.start();
  isRecording = true;
  btn.style.color = 'var(--crimson-bright)';
  btn.style.borderColor = 'var(--crimson-bright)';
  showToast('Listening... speak now', '🎙️');
}

// ── Reactions ─────────────────────────────────────────────────────
function toggleReaction(msgId, emoji, btn) {
  if (!reactions[msgId]) reactions[msgId] = {};
  if (!reactions[msgId][emoji]) reactions[msgId][emoji] = 0;
  const pill = btn;
  const countEl = pill.querySelector('.rc-count');
  const isActive = pill.classList.contains('active');
  if (isActive) {
    reactions[msgId][emoji] = Math.max(0, reactions[msgId][emoji] - 1);
    pill.classList.remove('active');
  } else {
    reactions[msgId][emoji]++;
    pill.classList.add('active');
    pill.animate([{transform:'scale(1)'},{transform:'scale(1.25)'},{transform:'scale(1)'}], {duration:300, easing:'ease-out'});
  }
  if (countEl) countEl.textContent = reactions[msgId][emoji] || '';
}

// ── Pin Messages ──────────────────────────────────────────────────
function togglePin(msgId, text, btn) {
  const bubble = btn.closest('.bubble');
  const isPinned = bubble.classList.contains('pinned');
  if (isPinned) {
    bubble.classList.remove('pinned');
    btn.classList.remove('pin-active');
    pinnedMessages = pinnedMessages.filter(p => p.id !== msgId);
  } else {
    bubble.classList.add('pinned');
    btn.classList.add('pin-active');
    const shortText = text.slice(0, 80).replace(/\n/g, ' ');
    pinnedMessages.push({ id: msgId, text: shortText });
  }
  renderPinnedPanel();
}

function renderPinnedPanel() {
  const panel = document.getElementById('pinnedPanel');
  const list  = document.getElementById('pinnedList');
  if (!pinnedMessages.length) { panel.classList.remove('visible'); return; }
  panel.classList.add('visible');
  list.innerHTML = pinnedMessages.map(p =>
    `<div class="pinned-item" title="${p.text}">📌 ${p.text}${p.text.length >= 80 ? '…' : ''}</div>`
  ).join('');
}

// ── Search ────────────────────────────────────────────────────────
function openSearch() {
  const overlay = document.getElementById('searchOverlay');
  overlay.classList.add('open');
  setTimeout(() => document.getElementById('searchInput').focus(), 100);
  performSearch('');
}

function closeSearch() {
  document.getElementById('searchOverlay').classList.remove('open');
  document.getElementById('searchInput').value = '';
}

function performSearch(query) {
  const results  = document.getElementById('searchResults');
  const messages = conversationHistory;
  if (!messages.length) {
    results.innerHTML = '<div class="search-empty">NO MESSAGES TO SEARCH</div>';
    return;
  }
  const q = query.toLowerCase().trim();
  const filtered = q ? messages.filter(m => m.content.toLowerCase().includes(q)) : messages;
  if (!filtered.length) {
    results.innerHTML = `<div class="search-empty">NO RESULTS FOR "${query.toUpperCase()}"</div>`;
    return;
  }
  results.innerHTML = filtered.map((m) => {
    const role = m.role === 'assistant' ? '◈ LUNA' : '◈ YOU';
    let preview = m.content.slice(0, 120).replace(/\*\*/g,'').replace(/\*/g,'');
    if (q) {
      const idx = preview.toLowerCase().indexOf(q);
      if (idx >= 0) {
        preview = preview.slice(0, idx) + `<mark>${preview.slice(idx, idx + q.length)}</mark>` + preview.slice(idx + q.length);
      }
    }
    return `
      <div class="search-result-item" onclick="jumpToMessage(${messages.indexOf(m)})">
        <div class="sr-role">${role} · Message ${messages.indexOf(m) + 1}</div>
        <div class="sr-text">${preview}${m.content.length > 120 ? '…' : ''}</div>
      </div>
    `;
  }).join('');
}

function jumpToMessage(idx) {
  const allMessages = chatFeed.querySelectorAll('.message');
  if (allMessages[idx]) {
    allMessages[idx].scrollIntoView({ behavior: 'smooth', block: 'center' });
    allMessages[idx].style.outline = '1px solid var(--violet-bright)';
    setTimeout(() => { allMessages[idx].style.outline = ''; }, 2000);
  }
  closeSearch();
}

document.getElementById('searchInput')?.addEventListener('input', e => {
  performSearch(e.target.value);
});

// ── Regenerate ────────────────────────────────────────────────────
async function regenerateResponse() {
  if (isTyping || !lastUserText) { showToast('Nothing to regenerate yet.', '◈'); return; }
  const messages = chatFeed.querySelectorAll('.message.luna');
  const last = messages[messages.length - 1];
  if (last) last.remove();
  if (conversationHistory.length && conversationHistory[conversationHistory.length - 1].role === 'assistant') {
    conversationHistory.pop();
  }
  showToast('Regenerating response ✦', '🔄');
  isTyping = true; sendBtn.disabled = true;
  showTyping();
  try {
    const reply = await getLunaResponse(lastUserText);
    conversationHistory.push({ role: 'user', content: lastUserText });
    conversationHistory.push({ role: 'assistant', content: reply });
    if (conversationHistory.length > 20) conversationHistory = conversationHistory.slice(-20);
    hideTyping();
    lastLunaText = reply;
    await appendMessage('luna', reply);
  } catch (err) {
    hideTyping();
    await appendMessage('luna', `◈ Regeneration failed. ${err.message || 'Please try again.'} ✦`);
  }
  isTyping = false; sendBtn.disabled = false; focusInputDesktopOnly();
}

// ── URL detection ─────────────────────────────────────────────────
function extractURL(text) {
  const m = text.match(/https?:\/\/[^\s]+/);
  return m ? m[0] : null;
}

// ══════════════════════════════════════════════════════════════════
// ◈ LINK SAFETY SYSTEM
// ══════════════════════════════════════════════════════════════════

// Known safe CDNs / popular safe domains (allow-list — skip safety UI for these)
const LINK_SAFE_DOMAINS = new Set([
  'github.com','github.io','githubusercontent.com',
  'stackoverflow.com','stackexchange.com',
  'wikipedia.org','wikimedia.org',
  'youtube.com','youtu.be',
  'google.com','drive.google.com','docs.google.com','sheets.google.com',
  'reddit.com',
  'medium.com',
  'npmjs.com','pypi.org',
  'developer.mozilla.org','mdn.io',
  'arxiv.org','scholar.google.com',
  'twitter.com','x.com',
  'linkedin.com',
  'cloudflare.com',
  'anthropic.com','openai.com',
  'firebase.google.com','firebaseapp.com',
]);

// Patterns that indicate malicious / phishing / dangerous URLs
const LINK_DANGER_PATTERNS = [
  // IP address URLs (often used for C&C or phishing)
  /^https?:\/\/\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}/,
  // Localhost / internal network
  /^https?:\/\/(localhost|127\.|192\.168\.|10\.|172\.(1[6-9]|2[0-9]|3[01])\.)/,
  // Known malware / phishing TLDs abuse patterns
  /\.(tk|ml|ga|cf|gq|xyz|top|click|loan|work|party|win|review|country|stream|download|racing|bid|men|science|trade|date|faith|accountant|cricket|webcam|bar|gdn)\/?$/i,
  // Suspicious keywords in URL path
  /\/(payload|shell|exploit|malware|ransomware|keylog|backdoor|rat|trojan|dropper|inject|phish|steal|bypass|hack|crack|dump|loader|binder)\b/i,
  // URL shorteners (unknown destination — require warning)
  /^https?:\/\/(bit\.ly|tinyurl\.com|t\.co|ow\.ly|goo\.gl|short\.io|rb\.gy|cutt\.ly|is\.gd|tiny\.cc|adf\.ly|bc\.vc|shorte\.st)\//i,
  // Executable file downloads
  /\.(exe|bat|cmd|ps1|vbs|js|msi|dll|apk|dmg|sh|run|bin|scr|pif|com)\s*(\?|$)/i,
  // Data URIs (can run code)
  /^data:/i,
  // Javascript protocol
  /^javascript:/i,
];

// Patterns that mean we should WARN but still allow (user must confirm)
const LINK_WARN_PATTERNS = [
  // URL shorteners
  /^https?:\/\/(bit\.ly|tinyurl\.com|t\.co|ow\.ly|goo\.gl|short\.io|rb\.gy|cutt\.ly|is\.gd|tiny\.cc|adf\.ly|bc\.vc|shorte\.st)\//i,
  // Suspicious TLDs
  /\.(tk|ml|ga|cf|gq)\/?$/i,
  // Unusual ports
  /:\d{4,5}\//,
  // Very long URLs (often obfuscated)
  /.{300,}/,
];

/**
 * Classify a URL as 'safe' | 'warn' | 'block'
 * Returns { verdict, reason }
 */
function classifyURL(url) {
  // javascript: / data: = always block
  if (/^(javascript:|data:)/i.test(url)) {
    return { verdict: 'block', reason: 'This link uses a dangerous protocol (`javascript:` or `data:`) and has been blocked for your safety.' };
  }
  // Localhost / internal = always block
  if (/^https?:\/\/(localhost|127\.|192\.168\.|10\.|172\.(1[6-9]|2[0-9]|3[01])\.)/i.test(url)) {
    return { verdict: 'block', reason: 'This link points to an internal/local network address and has been blocked.' };
  }

  let hostname = '';
  try {
    hostname = new URL(url).hostname.replace(/^www\./, '');
  } catch { return { verdict: 'block', reason: 'Malformed URL — could not parse.' }; }

  // Check allow-list (known safe domains — skip further checks)
  for (const safe of LINK_SAFE_DOMAINS) {
    if (hostname === safe || hostname.endsWith('.' + safe)) {
      return { verdict: 'safe', reason: '' };
    }
  }

  // Hard block patterns
  for (const pat of LINK_DANGER_PATTERNS) {
    if (pat.test(url)) {
      // URL shorteners are warn not block
      if (/^https?:\/\/(bit\.ly|tinyurl\.com|t\.co|ow\.ly|goo\.gl|short\.io|rb\.gy|cutt\.ly|is\.gd|tiny\.cc|adf\.ly|bc\.vc|shorte\.st)\//i.test(url)) {
        return { verdict: 'warn', reason: `This is a shortened URL — the real destination is hidden. It may or may not be safe.` };
      }
      return { verdict: 'block', reason: `This link has been blocked — it matches a known dangerous pattern (suspicious domain, extension, or path).` };
    }
  }

  // Warn patterns
  for (const pat of LINK_WARN_PATTERNS) {
    if (pat.test(url)) {
      return { verdict: 'warn', reason: `Luna detected this link may be unusual or potentially risky. Proceed with caution.` };
    }
  }

  // Unknown but not in deny list → warn (default-deny unknown)
  return { verdict: 'warn', reason: `Luna doesn't recognize this domain. Make sure you trust the source before proceeding.` };
}

/**
 * Show a safety modal and return a Promise<boolean> — true if user allows, false if blocked
 */
function showLinkSafetyModal(url, verdict, reason) {
  return new Promise(resolve => {
    const existing = document.getElementById('linkSafetyModal');
    if (existing) existing.remove();

    const isBlock = verdict === 'block';
    const overlay = document.createElement('div');
    overlay.id = 'linkSafetyModal';
    overlay.style.cssText = `
      position:fixed;inset:0;z-index:99998;
      background:rgba(2,2,9,0.88);
      display:flex;align-items:center;justify-content:center;
      animation:fadeIn 0.2s ease;
    `;

    const accentColor = isBlock ? 'var(--crimson-bright)' : 'var(--gold)';
    const iconEmoji   = isBlock ? '🚫' : '⚠️';
    const title       = isBlock ? '◈ LINK BLOCKED' : '◈ LINK WARNING';

    overlay.innerHTML = `
      <div style="
        background:var(--card);
        border:1px solid ${isBlock ? 'var(--border-red)' : 'rgba(251,191,36,0.4)'};
        border-top:2px solid ${accentColor};
        border-radius:var(--r-lg);
        padding:28px 26px 22px;
        max-width:440px;width:92%;
        display:flex;flex-direction:column;gap:16px;
        box-shadow:0 24px 72px rgba(0,0,0,0.75),0 0 40px ${isBlock ? 'var(--crimson-glow)' : 'rgba(251,191,36,0.2)'};
        animation:slideUpBox 0.28s var(--spring) both;
        position:relative;
      ">
        <div style="display:flex;align-items:center;gap:12px;">
          <div style="
            width:40px;height:40px;border-radius:50%;flex-shrink:0;
            background:${isBlock ? 'rgba(236,45,90,0.15)' : 'rgba(251,191,36,0.12)'};
            border:1px solid ${isBlock ? 'var(--border-red)' : 'rgba(251,191,36,0.4)'};
            display:flex;align-items:center;justify-content:center;font-size:18px;
          ">${iconEmoji}</div>
          <div>
            <div style="font-family:var(--font-hud);font-size:11px;letter-spacing:0.22em;color:${accentColor};">${title}</div>
            <div style="font-size:11px;color:var(--text-lo);margin-top:2px;font-family:var(--font-hud);letter-spacing:0.08em;">LUNA LINK SAFETY SCANNER</div>
          </div>
        </div>

        <div style="
          background:rgba(255,255,255,0.03);
          border:1px solid rgba(255,255,255,0.07);
          border-radius:var(--r-sm);
          padding:10px 12px;
          word-break:break-all;
          font-family:var(--font-mono);font-size:11px;
          color:var(--text-mid);line-height:1.5;
          max-height:72px;overflow-y:auto;
        ">${escHtml(url)}</div>

        <div style="font-size:13px;color:${isBlock ? 'var(--crimson-bright)' : 'var(--gold)'};line-height:1.6;">
          ${escHtml(reason)}
        </div>

        <div style="display:flex;gap:10px;margin-top:4px;">
          ${isBlock ? `
            <button onclick="document.getElementById('linkSafetyModal').remove();" style="
              flex:1;padding:12px 0;
              background:var(--crimson-dim);border:1px solid var(--border-red);
              border-radius:var(--r-sm);color:var(--crimson-bright);
              font-family:var(--font-hud);font-size:10px;letter-spacing:0.16em;
              cursor:pointer;transition:all 0.18s;
            ">◈ OK, UNDERSTOOD</button>
          ` : `
            <button id="lsm-cancel" style="
              flex:1;padding:12px 0;
              background:rgba(255,255,255,0.04);border:1px solid rgba(255,255,255,0.1);
              border-radius:var(--r-sm);color:var(--text-mid);
              font-family:var(--font-hud);font-size:10px;letter-spacing:0.16em;
              cursor:pointer;transition:all 0.18s;
            ">✕ CANCEL</button>
            <button id="lsm-proceed" style="
              flex:1;padding:12px 0;
              background:rgba(251,191,36,0.12);border:1px solid rgba(251,191,36,0.4);
              border-radius:var(--r-sm);color:var(--gold);
              font-family:var(--font-hud);font-size:10px;letter-spacing:0.16em;
              cursor:pointer;transition:all 0.18s;
            ">→ PROCEED ANYWAY</button>
          `}
        </div>
      </div>
    `;

    document.body.appendChild(overlay);

    if (isBlock) {
      resolve(false);
      return;
    }

    // Warn mode — user decides
    document.getElementById('lsm-cancel').addEventListener('click', () => {
      overlay.remove(); resolve(false);
    });
    document.getElementById('lsm-proceed').addEventListener('click', () => {
      overlay.remove(); resolve(true);
    });
    // Click outside to cancel
    overlay.addEventListener('click', e => {
      if (e.target === overlay) { overlay.remove(); resolve(false); }
    });
  });
}

// ── Fetch webpage (safe) ──────────────────────────────────────────
async function fetchWebpage(url) {
  // Try allorigins first, then a CORS-anywhere fallback
  const proxyURL = `https://api.allorigins.win/get?url=${encodeURIComponent(url)}`;
  let res;
  try {
    res = await fetch(proxyURL, { signal: AbortSignal.timeout(10000) });
  } catch {
    throw new Error('Network error — could not reach the link proxy.');
  }
  if (!res.ok) throw new Error('Could not fetch the webpage (proxy returned an error).');
  const data = await res.json();
  if (!data.contents) throw new Error('Page returned no readable content.');
  const div  = document.createElement('div');
  div.innerHTML = data.contents;
  // Remove script/style noise
  div.querySelectorAll('script,style,noscript,nav,footer,header,aside').forEach(el => el.remove());
  const text = (div.innerText || div.textContent || '').replace(/\s+/g,' ').trim();
  if (!text || text.length < 20) throw new Error('Page has no readable text content.');
  return text.slice(0, 4000); // slightly more context
}

// ── Read uploaded file ────────────────────────────────────────────
async function readFile(file) {
  const ext = file.name.split('.').pop().toLowerCase();
  if (['txt','md','csv','json'].includes(ext)) return await file.text();
  if (ext === 'pdf') {
    const pdfjsLib = window['pdfjs-dist/build/pdf'];
    if (!pdfjsLib) throw new Error('PDF reader not loaded yet. Please try again.');
    const ab  = await file.arrayBuffer();
    const pdf = await pdfjsLib.getDocument({ data: ab }).promise;
    let text  = '';
    for (let i = 1; i <= Math.min(pdf.numPages, 10); i++) {
      const page = await pdf.getPage(i);
      const c    = await page.getTextContent();
      text += c.items.map(s => s.str).join(' ') + '\n';
    }
    return text.trim().slice(0,3000);
  }
  if (ext === 'docx') {
    const mammoth = window.mammoth;
    if (!mammoth) throw new Error('DOCX reader not loaded yet. Please try again.');
    const ab  = await file.arrayBuffer();
    const res = await mammoth.extractRawText({ arrayBuffer: ab });
    return res.value.trim().slice(0,3000);
  }
  throw new Error(`File type .${ext} is not supported. Supported: .txt .pdf .docx .md .csv .json`);
}

// ── Stage files ───────────────────────────────────────────────────
function stageFiles(files) {
  stagedFiles = files;
  const badge = document.getElementById('fileBadge');
  document.getElementById('fileBadgeName').textContent = files.map(f => '📎 ' + f.name).join('   ');
  badge.style.display = 'flex';
  userInput.focus();
}

// ── Shared: compress & stage any image File object ────────────────
function stageImageFromFile(file, sourceLabel = '📸 Image ready') {
  const reader = new FileReader();
  reader.onload = ev => {
    const orig = ev.target.result;
    const img  = new Image();
    img.onload = () => {
      const c2   = document.createElement('canvas');
      const maxW = 1280, scale = img.width > maxW ? maxW / img.width : 1;
      c2.width   = Math.round(img.width  * scale);
      c2.height  = Math.round(img.height * scale);
      c2.getContext('2d').drawImage(img, 0, 0, c2.width, c2.height);
      const dataURL = c2.toDataURL('image/jpeg', 0.85);
      stagedImage   = { base64: dataURL.split(',')[1], mimeType: 'image/jpeg', objectURL: dataURL };
      const thumb   = document.getElementById('imageBadgeThumb');
      const label   = document.getElementById('imageBadgeLabel');
      const badge   = document.getElementById('imageBadge');
      if (thumb) thumb.src = dataURL;
      if (label) label.textContent = sourceLabel + ' — add a message or send as-is';
      if (badge) badge.style.display = 'flex';
      sendBtn.disabled = false;
      userInput.focus();
    };
    img.src = orig;
  };
  reader.readAsDataURL(file);
}

// ── Inject file upload ────────────────────────────────────────────
function injectFileUpload() {
  const pdfScript = document.createElement('script');
  pdfScript.src = 'https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.min.js';
  pdfScript.onload = () => { pdfjsLib.GlobalWorkerOptions.workerSrc = 'https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.worker.min.js'; };
  document.head.appendChild(pdfScript);
  const mamScript = document.createElement('script');
  mamScript.src = 'https://cdnjs.cloudflare.com/ajax/libs/mammoth/1.6.0/mammoth.browser.min.js';
  document.head.appendChild(mamScript);

  // ── Hidden inputs ──────────────────────────────────────────────
  // Document file input
  const fileInput    = document.createElement('input');
  fileInput.type     = 'file';
  fileInput.id       = 'fileInput';
  fileInput.accept   = '.txt,.pdf,.docx,.md,.csv,.json';
  fileInput.multiple = true;
  fileInput.style.display = 'none';
  document.body.appendChild(fileInput);

  // Image gallery picker
  const imageInput   = document.createElement('input');
  imageInput.type    = 'file';
  imageInput.id      = 'imageGalleryInput';
  imageInput.accept  = 'image/*';
  imageInput.style.display = 'none';
  document.body.appendChild(imageInput);

  // Camera capture (mobile: opens camera directly; desktop: file picker fallback)
  const cameraInput  = document.createElement('input');
  cameraInput.type   = 'file';
  cameraInput.id     = 'cameraInput';
  cameraInput.accept = 'image/*';
  cameraInput.setAttribute('capture', 'environment');
  cameraInput.style.display = 'none';
  document.body.appendChild(cameraInput);

  // ── Toolbar buttons ────────────────────────────────────────────
  // Document upload button
  const uploadBtn     = document.createElement('button');
  uploadBtn.className = 'icon-btn';
  uploadBtn.title     = 'Upload file (.txt .pdf .docx .md .csv .json)';
  uploadBtn.innerHTML = `<svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M21.44 11.05l-9.19 9.19a6 6 0 01-8.49-8.49l9.19-9.19a4 4 0 015.66 5.66L9.41 17.41a2 2 0 01-2.83-2.83l8.49-8.48"/></svg>`;
  sendBtn.parentNode.insertBefore(uploadBtn, sendBtn);
  uploadBtn.addEventListener('click', () => fileInput.click());

  // Image gallery button
  const galleryBtn     = document.createElement('button');
  galleryBtn.className = 'icon-btn';
  galleryBtn.title     = 'Send an image from your gallery';
  galleryBtn.innerHTML = `<svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="3" width="18" height="18" rx="2"/><circle cx="8.5" cy="8.5" r="1.5"/><polyline points="21 15 16 10 5 21"/></svg>`;
  sendBtn.parentNode.insertBefore(galleryBtn, sendBtn);
  galleryBtn.addEventListener('click', () => imageInput.click());

  // Camera button
  const cameraBtn     = document.createElement('button');
  cameraBtn.className = 'icon-btn';
  cameraBtn.title     = 'Take a photo with your camera';
  cameraBtn.innerHTML = `<svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M23 19a2 2 0 0 1-2 2H3a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h4l2-3h6l2 3h4a2 2 0 0 1 2 2z"/><circle cx="12" cy="13" r="4"/></svg>`;
  sendBtn.parentNode.insertBefore(cameraBtn, sendBtn);
  cameraBtn.addEventListener('click', () => cameraInput.click());

  // ── Mobile expand tray (focus → show + → reveal icons) ───────────
  (function setupMobileTray() {
    const inputActions = sendBtn.parentNode;
    const voiceBtnEl   = document.getElementById('voiceBtn');
    const userInputEl  = document.getElementById('userInput');
    if (!voiceBtnEl || !userInputEl || !inputActions) return;

    // Collapsible tray that holds all icon buttons
    const iconTray = document.createElement('div');
    iconTray.className = 'mobile-icon-tray';
    iconTray.id = 'mobileIconTray';
    inputActions.insertBefore(iconTray, sendBtn);

    // Move existing buttons into tray (order: mic, upload, gallery, camera, emoji)
    [voiceBtnEl, uploadBtn, galleryBtn, cameraBtn].forEach(btn => {
      if (btn) iconTray.appendChild(btn);
    });
    // Also pull in emoji picker btn if already injected, or observe for it
    const maybeEmoji = document.getElementById('emojiPickerBtn');
    if (maybeEmoji) iconTray.appendChild(maybeEmoji);
    else {
      // Emoji btn injected later — watch for it and move it in
      const obs = new MutationObserver(() => {
        const eb = document.getElementById('emojiPickerBtn');
        if (eb) { iconTray.appendChild(eb); obs.disconnect(); }
      });
      obs.observe(document.body, { childList: true, subtree: true });
    }

    // + / × toggle button — appears on focus
    const toggleBtn = document.createElement('button');
    toggleBtn.className = 'icon-btn mobile-toggle-btn';
    toggleBtn.id        = 'mobileToggleBtn';
    toggleBtn.title     = 'More options';
    toggleBtn.innerHTML = `<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>`;
    inputActions.insertBefore(toggleBtn, iconTray);

    let trayOpen   = false;

    function openTray() {
      trayOpen = true;
      iconTray.classList.add('open');
      toggleBtn.classList.add('tray-open');
    }
    function closeTray() {
      trayOpen = false;
      iconTray.classList.remove('open');
      toggleBtn.classList.remove('tray-open');
    }

    // Close tray when tapping outside
    document.addEventListener('touchstart', e => {
      if (trayOpen && !iconTray.contains(e.target) && e.target !== toggleBtn) closeTray();
    }, { passive: true });

    toggleBtn.addEventListener('click', () => { trayOpen ? closeTray() : openTray(); });
  })();

  // ── File badge (documents) ─────────────────────────────────────
  const fileBadge = document.createElement('div');
  fileBadge.id    = 'fileBadge';
  fileBadge.style.cssText = 'display:none;align-items:center;gap:8px;background:rgba(236,45,90,0.08);border:1px solid rgba(236,45,90,0.28);border-radius:8px;padding:6px 12px;font-size:12px;color:var(--crimson-bright);margin-bottom:7px;font-family:var(--font-body)';
  fileBadge.innerHTML = '<span id="fileBadgeName"></span><button id="fileBadgeRemove" style="margin-left:auto;background:none;border:none;color:#ff4466;cursor:pointer;font-size:15px;line-height:1">✕</button>';
  document.querySelector('.input-box').parentNode.insertBefore(fileBadge, document.querySelector('.input-box'));

  document.getElementById('fileBadgeRemove').addEventListener('click', () => {
    stagedFiles = [];
    fileBadge.style.display = 'none';
    fileInput.value = '';
    userInput.focus();
  });

  fileInput.addEventListener('change', () => {
    const files = Array.from(fileInput.files);
    if (!files.length) return;
    stageFiles(files);
    fileInput.value = '';
  });

  // ── Image badge (photos) — with thumbnail + remove button ──────
  const imageBadge = document.createElement('div');
  imageBadge.id    = 'imageBadge';
  imageBadge.style.cssText = 'display:none;align-items:center;gap:10px;background:rgba(168,85,247,0.07);border:1px solid rgba(168,85,247,0.28);border-radius:8px;padding:6px 12px;font-size:12px;color:var(--violet-bright);margin-bottom:7px;';
  imageBadge.innerHTML = `
    <img id="imageBadgeThumb" style="height:40px;width:auto;max-width:60px;border-radius:5px;object-fit:cover;border:1px solid rgba(168,85,247,0.3);cursor:pointer;" title="Click to preview" />
    <span id="imageBadgeLabel" style="flex:1;">📸 Image ready — add a message or send as-is</span>
    <button id="imageBadgeRemove" title="Remove image" style="background:none;border:none;color:var(--crimson-bright);cursor:pointer;font-size:15px;line-height:1;padding:2px 4px;opacity:0.7;transition:opacity 0.15s;" onmouseover="this.style.opacity='1'" onmouseout="this.style.opacity='0.7'">✕</button>`;
  fileBadge.parentNode.insertBefore(imageBadge, fileBadge);

  document.getElementById('imageBadgeRemove').addEventListener('click', () => {
    clearStagedImage();
    imageInput.value  = '';
    cameraInput.value = '';
    userInput.focus();
  });

  // Thumbnail click → full preview modal
  document.getElementById('imageBadgeThumb').addEventListener('click', () => {
    if (!stagedImage) return;
    const overlay = document.createElement('div');
    overlay.style.cssText = 'position:fixed;inset:0;z-index:99999;background:rgba(0,0,0,0.88);display:flex;align-items:center;justify-content:center;cursor:zoom-out;animation:fadeIn 0.2s ease;';
    overlay.innerHTML = `<img src="${stagedImage.objectURL}" style="max-width:92vw;max-height:88vh;border-radius:12px;box-shadow:0 8px 60px rgba(0,0,0,0.8);border:1px solid rgba(168,85,247,0.3);">`;
    overlay.addEventListener('click', () => overlay.remove());
    document.body.appendChild(overlay);
  });

  // ── Wire up new image inputs ───────────────────────────────────
  imageInput.addEventListener('change', () => {
    const file = imageInput.files[0];
    if (!file) return;
    stageImageFromFile(file, '🖼️ Image from gallery');
    imageInput.value = '';
  });

  cameraInput.addEventListener('change', () => {
    const file = cameraInput.files[0];
    if (!file) return;
    stageImageFromFile(file, '📷 Camera photo');
    cameraInput.value = '';
  });

  // ── Paste image ────────────────────────────────────────────────
  function handlePasteImage(e) {
    const items = (e.clipboardData || e.originalEvent?.clipboardData)?.items;
    if (!items) return;
    for (const item of items) {
      if (item.type.startsWith('image/')) {
        e.preventDefault();
        const file = item.getAsFile();
        if (!file) return;
        stageImageFromFile(file, '📋 Pasted image');
        break;
      }
    }
  }
  userInput.addEventListener('paste', handlePasteImage);
  document.addEventListener('paste', e => {
    const tag = document.activeElement.tagName;
    if (tag !== 'INPUT' && tag !== 'TEXTAREA') handlePasteImage(e);
    else if (document.activeElement === userInput) handlePasteImage(e);
  });

  // ── Drag & drop ────────────────────────────────────────────────
  const dragOverlay = document.getElementById('dragOverlay');
  let dragCounter = 0;
  document.addEventListener('dragenter', e => {
    const hasFiles = Array.from(e.dataTransfer?.types || []).includes('Files');
    if (hasFiles) { dragCounter++; dragOverlay.classList.add('active'); }
  });
  document.addEventListener('dragleave', () => {
    dragCounter--;
    if (dragCounter <= 0) { dragCounter = 0; dragOverlay.classList.remove('active'); }
  });
  document.addEventListener('dragover', e => { e.preventDefault(); });
  document.addEventListener('drop', e => {
    e.preventDefault();
    dragCounter = 0;
    dragOverlay.classList.remove('active');
    const imageFiles = Array.from(e.dataTransfer.files).filter(f => f.type.startsWith('image/'));
    if (imageFiles.length) {
      stageImageFromFile(imageFiles[0], '🖼️ Dropped image');
      return;
    }
    const files = Array.from(e.dataTransfer.files).filter(f => /\.(txt|pdf|docx|md|csv|json)$/i.test(f.name));
    if (files.length) stageFiles(files);
  });
}

function clearStagedImage() {
  stagedImage = null;
  const b = document.getElementById('imageBadge');
  if (b) b.style.display = 'none';
  const t = document.getElementById('imageBadgeThumb');
  if (t) t.src = '';
}

// ── Markdown formatter ────────────────────────────────────────────
function formatMarkdown(raw) {
  let s = raw.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');
  s = s.replace(/```(\w*)\n?([\s\S]*?)```/g, (_, lang, code) => {
    const id = 'cb_' + Math.random().toString(36).slice(2,9);
    const label = lang || 'code';
    const highlighted = highlightCode(code.trim(), lang);
    return `<div class="code-block"><div class="code-header"><span class="code-lang">${label.toUpperCase()}</span><button class="code-copy" onclick="copyCode('${id}')">COPY</button></div><pre id="${id}"><code>${highlighted}</code></pre></div>`;
  });
  s = s.replace(/`([^`]+)`/g, '<span class="inline-code">$1</span>');
  // Markdown named links: [text](url)
  s = s.replace(/\[([^\]]+)\]\((https?:\/\/[^\s)]+)\)/g, (_, text, url) => {
    return `<a href="${url}" target="_blank" rel="noopener noreferrer" style="color:var(--violet-bright);text-decoration:underline;text-underline-offset:2px;word-break:break-all;">${text}</a>`;
  });
  // Bare URLs not already inside an <a> tag
  s = s.replace(/(^|[\s(>])(https?:\/\/[^\s<"&)]+)/g, (_, before, url) => {
    return `${before}<a href="${url}" target="_blank" rel="noopener noreferrer" style="color:var(--violet-bright);text-decoration:underline;text-underline-offset:2px;word-break:break-all;">${url}</a>`;
  });
  s = s.replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>');
  s = s.replace(/\*(.+?)\*/g, '<em>$1</em>');
  s = s.replace(/\n/g, '<br/>');
  return s;
}

// ── Simple syntax highlighter ─────────────────────────────────────
function highlightCode(code, lang) {
  if (!lang || lang === 'text' || lang === 'code') return code;
  const keywords = {
    js:     /\b(const|let|var|function|return|if|else|for|while|class|import|export|from|async|await|new|this|typeof|null|undefined|true|false)\b/g,
    ts:     /\b(const|let|var|function|return|if|else|for|while|class|import|export|from|async|await|new|this|typeof|null|undefined|true|false|interface|type|enum)\b/g,
    python: /\b(def|class|import|from|return|if|elif|else|for|while|in|not|and|or|True|False|None|print|self|pass|break|continue|raise|try|except|finally|with|as|lambda|yield)\b/g,
    css:    /\b(display|flex|grid|margin|padding|color|background|border|font|width|height|position|absolute|relative|fixed|sticky|block|inline|none|auto|px|em|rem|vh|vw)\b/g,
  };
  const kw = keywords[lang] || keywords['js'];
  return code
    .replace(/(\/\/.*$)/gm, '<span style="color:#6b7db3;font-style:italic">$1</span>')
    .replace(/(#.*$)/gm, '<span style="color:#6b7db3;font-style:italic">$1</span>')
    .replace(/(".*?"|'.*?'|`.*?`)/g, '<span style="color:#a3e635">$1</span>')
    .replace(kw, '<span style="color:var(--crimson-bright)">$1</span>');
}

// ── Stream Luna message (used for non-live paths: status hits, file/image responses) ──
async function streamLunaMessage(rawText, wrap) {
  const textEl = wrap.querySelector(".bubble-text");
  textEl.innerHTML = formatMarkdown(rawText);
  if (!userScrolledUp) scrollDown();
}


// ── Build message bubble ──────────────────────────────────────────
let msgIdCounter = 0;

function buildMessageWrap(role, rawText, stream = false, replyData = null) {
  const isLuna = role === 'luna';
  const wrap   = document.createElement('div');
  const msgId  = 'msg_' + (++msgIdCounter);
  wrap.className = `message ${isLuna ? 'luna' : 'user'}`;
  wrap.dataset.msgId = msgId;
  const time    = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  const label   = isLuna ? '◈ LUNA · responded' : '';
  const avClass = isLuna ? 'av-luna' : 'av-user';
  const init    = isLuna ? 'LN' : 'ME';
  const body    = stream ? '' : formatMarkdown(rawText);
  const lunaActions = isLuna ? `
    <button class="mac-btn reply-btn" title="Reply to this message" onclick="setReplyContext('${msgId}', this.closest('.bubble').querySelector('.bubble-text').innerText)">
      <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2"><polyline points="9 17 4 12 9 7"/><path d="M20 18v-2a4 4 0 0 0-4-4H4"/></svg>
    </button>
    <button class="mac-btn tts-btn" title="Read aloud" onclick="toggleTTS(this.closest('.bubble').querySelector('.bubble-text').innerText, this)">
      <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polygon points="11 5 6 9 2 9 2 15 6 15 11 19 11 5"/><path d="M15.54 8.46a5 5 0 0 1 0 7.07"/><path d="M19.07 4.93a10 10 0 0 1 0 14.14"/></svg>
    </button>
    <button class="mac-btn regen" title="Regenerate response (Ctrl+R)" onclick="regenerateResponse()">
      <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="1 4 1 10 7 10"/><path d="M3.51 15a9 9 0 1 0 .49-4"/></svg>
    </button>
    <button class="mac-btn summarize-btn" title="Summarize this response (Smart Mode)" onclick="summarizeLunaMessage(this.closest('.bubble').querySelector('.bubble-text').innerText)">
      <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="21" y1="6" x2="3" y2="6"/><line x1="15" y1="12" x2="3" y2="12"/><line x1="17" y1="18" x2="3" y2="18"/></svg>
      SUMMARIZE
    </button>` : '';

  // Reply quote block — shown in BOTH user and Luna bubbles for threaded exchanges
  // fromUser:true  → Luna is quoting the user  → crimson accent + "↩ YOU · QUOTED"
  // fromUser:false → user is quoting Luna       → violet accent + "↩ LUNA · QUOTED"
  const quoteCls   = replyData && replyData.fromUser ? 'reply-quote from-user' : 'reply-quote';
  const quoteLabel = replyData && replyData.fromUser ? '↩ YOU · QUOTED'        : '↩ LUNA · QUOTED';
  const replyQuoteHtml = replyData ? `
    <div class="${quoteCls}" onclick="jumpToReplyTarget('${replyData.msgId}')">
      <div class="reply-quote-accent"></div>
      <div class="reply-quote-inner">
        <div class="reply-quote-label">${quoteLabel}</div>
        <div class="reply-quote-text">${escHtml(replyData.previewText)}</div>
      </div>
    </div>` : '';

  wrap.innerHTML = `
    <div class="av ${avClass}">${init}</div>
    <div class="bubble" id="bubble_${msgId}">
      <div class="pin-badge">📌 PINNED</div>
      ${replyQuoteHtml}
      <span class="bubble-header">${label}</span>
      <span class="bubble-text">${body}</span>
      <div class="reaction-bar" id="rb_${msgId}">
        <button class="reaction-pill" onclick="toggleReaction('${msgId}','👍',this)"><span class="rc">👍</span><span class="rc-count"></span></button>
        <button class="reaction-pill" onclick="toggleReaction('${msgId}','❤️',this)"><span class="rc">❤️</span><span class="rc-count"></span></button>
        <button class="reaction-pill" onclick="toggleReaction('${msgId}','⭐',this)"><span class="rc">⭐</span><span class="rc-count"></span></button>
        <button class="reaction-pill" onclick="toggleReaction('${msgId}','🔥',this)"><span class="rc">🔥</span><span class="rc-count"></span></button>
      </div>
      <div class="bubble-footer">
        <span class="bubble-time">${time}</span>
        <div class="msg-actions">
          <button class="mac-btn" title="Copy message" onclick="copyToClipboard(this.closest('.bubble').querySelector('.bubble-text').innerText, this)">
            <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="9" y="9" width="13" height="13" rx="2"/><path d="M5 15H4a2 2 0 01-2-2V4a2 2 0 012-2h9a2 2 0 012 2v1"/></svg>
          </button>
          <button class="mac-btn" title="Pin message" onclick="togglePin('${msgId}', this.closest('.bubble').querySelector('.bubble-text').innerText, this)">
            <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"/><circle cx="12" cy="10" r="3"/></svg>
          </button>
          ${lunaActions}
          <button class="mac-btn" title="Star message" onclick="this.classList.toggle('starred')">
            <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg>
          </button>
        </div>
      </div>
    </div>
  `;
  // ◈ Mood Ring — apply current persona mood to avatar + bubble wrap
  if (isLuna) {
    applyMoodToAvatar(wrap.querySelector('.av-luna'));
    applyMoodToWrap(wrap);
  }
  return wrap;
}

async function appendMessage(role, rawText, replyData = null) {
  const isLuna = role === 'luna';
  chatFeed.querySelector('.welcome-card')?.remove();

  // ◈ Mood Ring — score Luna's replies for sentiment (user messages handled by detectToneFromMessage)
  if (isLuna) updateMoodRing(rawText);

  // ── Push to admin monitor chatlog ──
  pushMessageToFirebase(isLuna ? 'assistant' : 'user', rawText);

  // ── Save to user's personal Firebase chatlog + update in-memory history ──
  const fbRole = isLuna ? 'assistant' : 'user';
  saveMessageToUserChatlog(fbRole, rawText);
  persistedHistory.push({ role: fbRole, content: rawText, ts: Date.now() });
  if (persistedHistory.length > CHATLOG_MAX_MSGS) {
    persistedHistory = persistedHistory.slice(-CHATLOG_MAX_MSGS);
  }

  // ◈ Clear typing status when a message is sent
  if (!isLuna) clearTyping();

  let resultMsgId = null;

  if (isLuna) {
    lastLunaText = rawText;
    const wrap = buildMessageWrap('luna', rawText, true, replyData);
    resultMsgId = wrap.dataset.msgId;
    chatFeed.appendChild(wrap);
    if (userScrolledUp) {
      newMsgCount++;
      fabBadge.textContent = newMsgCount > 9 ? '9+' : newMsgCount;
      fabBadge.style.display = 'flex';
    }
    await streamLunaMessage(rawText, wrap);
  } else {
    const wrap = buildMessageWrap('user', rawText, false, replyData);
    resultMsgId = wrap.dataset.msgId;
    chatFeed.appendChild(wrap);
    scrollDown();
  }
  msgCount++;
  msgDisplay.textContent = msgCount;
  animateStats();
  return resultMsgId;
}

// ── Typing indicator ──────────────────────────────────────────────
function showTyping() {
  reportLunaTypingToAdmin(true);
  const el = document.createElement('div');
  el.className = 'message luna';
  el.id = 'typing-el';
  el.innerHTML = `
    <div class="av av-luna">LN</div>
    <div class="bubble">
      <span class="bubble-header">◈ LUNA · PROCESSING</span>
      <div class="typing-indicator">
        <div class="td"></div><div class="td"></div><div class="td"></div>
        <div class="td"></div><div class="td"></div>
      </div>
    </div>
  `;
  chatFeed.appendChild(el);
  scrollDown();
}
function hideTyping() { reportLunaTypingToAdmin(false); document.getElementById('typing-el')?.remove(); }

// ── Groq API call ─────────────────────────────────────────────────
// ── Parse retry-after seconds from a Groq rate-limit error message ──
function parseRetryAfter(msg) {
  const m = String(msg).match(/try again in\s+([\d.]+)s/i);
  return m ? Math.ceil(parseFloat(m[1])) : 12;
}

// ── Show a non-blocking countdown toast while waiting to retry ────
function showRetryCountdown(seconds, attempt) {
  return new Promise(resolve => {
    let remaining = seconds;
    const container = document.getElementById('toastContainer');
    const el = document.createElement('div');
    el.className = 'toast';
    el.innerHTML = `<span style="font-size:16px">⏳</span><span id="retryMsg">Rate limit — retrying in ${remaining}s (attempt ${attempt}/3)…</span>`;
    container.appendChild(el);
    const tick = setInterval(() => {
      remaining--;
      const msg = el.querySelector('#retryMsg');
      if (msg) msg.textContent = `Rate limit — retrying in ${remaining}s (attempt ${attempt}/3)…`;
      if (remaining <= 0) {
        clearInterval(tick);
        el.classList.add('removing');
        el.addEventListener('animationend', () => el.remove());
        resolve();
      }
    }, 1000);
  });
}

// ── Active stream abort controller (allows cancel-in-flight) ─────
let _activeStreamController = null;

// ── Show/hide the stop button (swaps with send button) ───────────
function showStopBtn() {
  const stopBtn = document.getElementById('stopStreamBtn');
  const sBtn    = document.getElementById('sendBtn');
  if (stopBtn) stopBtn.style.display = 'flex';
  if (sBtn)    sBtn.style.display    = 'none';
}
function hideStopBtn() {
  const stopBtn = document.getElementById('stopStreamBtn');
  const sBtn    = document.getElementById('sendBtn');
  if (stopBtn) stopBtn.style.display = 'none';
  if (sBtn)    sBtn.style.display    = 'flex';
}

// ── Cancel in-flight stream — user pressed STOP ───────────────────
function stopLunaStream() {
  if (_activeStreamController) {
    _activeStreamController.abort();
    _activeStreamController = null;
  }
  hideStopBtn();
  hideTyping();
  isTyping = false;
  sendBtn.disabled = false;
  userInput.focus();
  // Haptic feedback on mobile
  if (navigator.vibrate) navigator.vibrate(40);
  showToast('◈ Generation stopped.', '⬛', 1800);
}

// ── getLunaResponse: buffers full reply (used for regen / file / image flows) ──
async function getLunaResponse(userMessage, attempt = 1) {
  const systemMsg = buildSystemPromptWithStatuses();
  const trimmedHistory = conversationHistory.slice(-10);
  const messages  = [
    { role: 'system', content: systemMsg },
    ...trimmedHistory,
    { role: 'user', content: userMessage }
  ];

  const controller = new AbortController();
  _activeStreamController = controller;

  const response = await fetch(API_URL, {
    method: 'POST',
    signal: controller.signal,
    headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${getActiveApiKey()}` },
    body: JSON.stringify({ model: API_MODEL, max_tokens: 2000, temperature: settings.temperature, messages, stream: true }),
  });

  if (response.status === 429) {
    if (attempt >= 3) throw new Error('Rate limit reached. Luna needs a short break — please wait a moment and try again. ✦');
    const errData  = await response.json().catch(() => ({}));
    const waitSecs = parseRetryAfter(errData?.error?.message || '');
    await showRetryCountdown(waitSecs, attempt);
    return getLunaResponse(userMessage, attempt + 1);
  }
  if (!response.ok) {
    const errData = await response.json().catch(() => ({}));
    throw new Error(`Neural fault: ${errData?.error?.message || `HTTP ${response.status}`}`);
  }

  const reader  = response.body.getReader();
  const decoder = new TextDecoder('utf-8');
  let fullReply = '';
  let buffer    = '';
  while (true) {
    const { done, value } = await reader.read();
    if (done) break;
    buffer += decoder.decode(value, { stream: true });
    const lines = buffer.split('\n');
    buffer = lines.pop();
    for (const line of lines) {
      const trimmed = line.trim();
      if (!trimmed || trimmed === 'data: [DONE]') continue;
      if (trimmed.startsWith('data: ')) {
        try {
          const chunk = JSON.parse(trimmed.slice(6));
          const delta = chunk?.choices?.[0]?.delta?.content;
          if (delta) fullReply += delta;
          if (chunk?.usage) recordTokenUsage(chunk.usage);
        } catch { /* ignore malformed chunks */ }
      }
    }
  }
  if (!fullReply) throw new Error('Empty signal received.');
  return fullReply;
}

// ── streamLunaResponseLive: pipes SSE tokens directly into a bubble as they arrive ──
// Call this instead of getLunaResponse+appendMessage for the main chat flow.
// Returns the full reply string when done.
async function streamLunaResponseLive(userMessage, wrap, attempt = 1) {
  const systemMsg = buildSystemPromptWithStatuses();
  const trimmedHistory = conversationHistory.slice(-10);
  const messages  = [
    { role: 'system', content: systemMsg },
    ...trimmedHistory,
    { role: 'user', content: userMessage }
  ];

  const controller = new AbortController();
  _activeStreamController = controller;

  const response = await fetch(API_URL, {
    method: 'POST',
    signal: controller.signal,
    headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${getActiveApiKey()}` },
    body: JSON.stringify({ model: API_MODEL, max_tokens: 2000, temperature: settings.temperature, messages, stream: true }),
  });

  if (response.status === 429) {
    if (attempt >= 3) throw new Error('Rate limit reached. Luna needs a short break — please wait a moment and try again. ✦');
    const errData  = await response.json().catch(() => ({}));
    const waitSecs = parseRetryAfter(errData?.error?.message || '');
    await showRetryCountdown(waitSecs, attempt);
    return streamLunaResponseLive(userMessage, wrap, attempt + 1);
  }
  if (!response.ok) {
    const errData = await response.json().catch(() => ({}));
    throw new Error(`Neural fault: ${errData?.error?.message || `HTTP ${response.status}`}`);
  }

  const textEl   = wrap.querySelector('.bubble-text');
  const reader   = response.body.getReader();
  const decoder  = new TextDecoder('utf-8');
  let fullReply  = '';
  let buffer     = '';
  let renderTick = 0;

  // Show initial cursor immediately — signals to user that Luna is responding
  textEl.innerHTML = '<span class="stream-cursor"></span>';
  scrollDown();

  while (true) {
    const { done, value } = await reader.read();
    if (done) break;
    buffer += decoder.decode(value, { stream: true });
    const lines = buffer.split('\n');
    buffer = lines.pop();
    for (const line of lines) {
      const trimmed = line.trim();
      if (!trimmed || trimmed === 'data: [DONE]') continue;
      if (trimmed.startsWith('data: ')) {
        try {
          const chunk = JSON.parse(trimmed.slice(6));
          const delta = chunk?.choices?.[0]?.delta?.content;
          if (delta) {
            fullReply += delta;
            // On mobile: throttle DOM updates to every ~120ms to avoid reflow thrash
            // On desktop: update every token chunk for smoothest effect
            renderTick++;
            const shouldRender = IS_MOBILE ? (renderTick % 6 === 0) : true;
            if (shouldRender) {
              textEl.innerHTML = formatMarkdown(fullReply) + '<span class="stream-cursor"></span>';
              if (!userScrolledUp) scrollDown();
            }
          }
          if (chunk?.usage) recordTokenUsage(chunk.usage);
        } catch { /* ignore malformed chunks */ }
      }
    }
  }

  // Final render — no cursor
  textEl.innerHTML = formatMarkdown(fullReply || '◈ Empty signal received. ✦');
  if (!userScrolledUp) scrollDown();
  return fullReply;
}

// ── Process pasted image via vision ───────────────────────────────
async function processImage(imgData, userMessage = '') {
  if (isTyping) return;
  isTyping = true; sendBtn.disabled = true;
  const wrap = document.createElement('div');
  wrap.className = 'message user';
  const time = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  const msgHTML = userMessage ? `<br/><span>${formatMarkdown(userMessage)}</span>` : '';
  wrap.innerHTML = `
    <div class="av av-user">ME</div>
    <div class="bubble">
      <span class="bubble-header" style="display:none"></span>
      <span class="bubble-text">
        <img src="${imgData.objectURL}" style="max-width:260px;max-height:180px;border-radius:9px;display:block;margin-bottom:6px;border:1px solid rgba(168,85,247,0.25);" />
        ${msgHTML}
      </span>
      <div class="bubble-footer"><span class="bubble-time">${time}</span></div>
    </div>
  `;
  chatFeed.querySelector('.welcome-card')?.remove();
  chatFeed.appendChild(wrap);
  scrollDown();
  showTyping();
  msgCount++;
  msgDisplay.textContent = msgCount;
  try {
    const dataURL = `data:${imgData.mimeType};base64,${imgData.base64}`;

    // Detect copy / extract intent from the user's message
    const copyIntent = !userMessage || /copy|extract|basahin|i-copy|i-extract|what.*(say|written|text)|read.*this|paki.*basa|ano.*nakalagay|transcribe/i.test(userMessage);

    const extractionInstruction = copyIntent
      ? `The user wants you to READ and PRESENT the text from this image cleanly.

STRICT RULES — follow exactly, no exceptions:
1. Extract EVERY piece of text visible in the image — miss nothing
2. FORMAT the output based on content type:
   - If it is a SCHEDULE, PROGRAM, or TIMETABLE → use ## headers for each section/day, *italic* for sub-labels (like venue), and a markdown table: | Time | Activity | with | --- | --- | divider
   - If it is a LIST → use clean numbered or bulleted lists
   - If it is PROSE or PARAGRAPHS → preserve paragraph breaks and punctuation
   - If it is a FORM or DOCUMENT → use **Field:** Value format
3. Separate major sections with ---
4. Do NOT add commentary, analysis, or your own words
5. Do NOT say "Here is the text:" — just present it directly, clean and complete`
      : `${LUNA_SYSTEM_PROMPT}\n\nUser message: ${userMessage}`;

    const imagePrompt = copyIntent ? extractionInstruction : `${LUNA_SYSTEM_PROMPT}\n\nUser message: ${userMessage}`;
    const response = await fetch(API_URL, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${getActiveApiKey()}` },
      body: JSON.stringify({
        model: API_MODEL_VISION, max_tokens: 8192,
        messages: [{ role: 'user', content: [
          { type: 'text', text: imagePrompt },
          { type: 'image_url', image_url: { url: dataURL } }
        ]}]
      }),
    });
    if (!response.ok) { const e = await response.json().catch(() => ({})); throw new Error(`Vision fault: ${e?.error?.message || `HTTP ${response.status}`}`); }
    const data  = await response.json();
    const reply = data?.choices?.[0]?.message?.content;
    if (!reply) throw new Error('Empty signal received.');
    conversationHistory.push({ role: 'user', content: userMessage || '[image]' });
    conversationHistory.push({ role: 'assistant', content: reply });
    if (conversationHistory.length > 20) conversationHistory = conversationHistory.slice(-20);
    hideTyping();
    lastLunaText = reply;
    await appendMessage('luna', reply);
  } catch (err) {
    hideTyping();
    await appendMessage('luna', `◈ Vision scan disrupted. ${err.message} ✦`);
  }
  isTyping = false; sendBtn.disabled = false; focusInputDesktopOnly();
}

// ── Process uploaded files ────────────────────────────────────────
async function processFiles(files, userMessage = '') {
  if (isTyping) return;
  isTyping = true; sendBtn.disabled = true;
  const names = files.map(f => `**${f.name}**`).join('   📎 ');
  await appendMessage('user', `📎 ${names}${userMessage ? '  —  ' + userMessage : ''}`);
  showTyping();
  try {
    const parts    = await Promise.all(files.map(async f => { const fc = await readFile(f); return `--- File: ${f.name} ---\n${fc}`; }));
    const combined = parts.join('\n\n');

    // Detect copy / extract intent
    const copyIntent = !userMessage || /copy|extract|basahin|i-copy|i-extract|what.*(say|written|text|inside|content)|read.*this|paki.*basa|ano.*nakalagay|transcribe/i.test(userMessage);

    const extractionInstruction = `The user wants you to READ and PRESENT the content from this file cleanly.

STRICT RULES — follow exactly, no exceptions:
1. Present ALL content from the file — miss nothing
2. FORMAT the output based on what type of content it contains:
   - SCHEDULE / PROGRAM / TIMETABLE → ## headers for sections/days, *italic* for sub-labels, markdown table: | Time | Activity | with | --- | --- | divider
   - LIST → clean numbered or bulleted list
   - PROSE / PARAGRAPHS → preserve paragraph breaks
   - FORM / STRUCTURED DOCUMENT → **Field:** Value format
3. Separate major sections with ---
4. Do NOT add your own commentary or analysis
5. Do NOT say "Here is the content:" — just present it directly, clean and complete

File content:
${combined}${userMessage ? `\n\nAdditional user instruction: ${userMessage}` : ''}`;

    const prompt = copyIntent
      ? extractionInstruction
      : `I uploaded ${files.length} file(s):\n\n${combined}\n\nMy message: ${userMessage || 'Please analyze and summarize them.'}`;
    const reply = await getLunaResponse(prompt);
    conversationHistory.push({ role: 'user', content: prompt });
    conversationHistory.push({ role: 'assistant', content: reply });
    if (conversationHistory.length > 20) conversationHistory = conversationHistory.slice(-20);
    hideTyping();
    lastLunaText = reply;
    await appendMessage('luna', reply);
  } catch (err) {
    hideTyping();
    await appendMessage('luna', `◈ File scan disrupted. ${err.message} ✦`);
  }
  isTyping = false; sendBtn.disabled = false; focusInputDesktopOnly();
}

// ── Activity category detector ────────────────────────────────────
const ACTIVITY_CATEGORIES = {
  eating: {
    keywords: [
      'eating','kain','kumakain','nagkakain','nagsasalo-salo',
      'lunch','dinner','breakfast','brunch','meryenda','snack',
      'having lunch','having dinner','having breakfast','having a meal','having a snack',
      'dining','feasting','grabbing food','getting food','food trip','foodtrip',
      'eating out','ordering food','nagkakain',
    ],
    extras: (name) => [
      [
        `Looks like ${name} is taking a well-deserved break to enjoy a meal! 🍽️`,
        `Hope it's something delicious — everyone deserves a good bite. ✦`,
        `They should be back and available once they're done eating. ◈`,
      ],
      [
        `${name} is fueling up right now! 🍴`,
        `Good food keeps the mind sharp — they'll be back in full energy shortly after. ✦`,
        `Give them a little time and they'll be ready to go again. ◈`,
      ],
      [
        `Meal time for ${name}! 🥘`,
        `It's important to take a proper break — eating well keeps everything running. ✦`,
        `They'll likely be free again once the meal is done. ◈`,
      ],
    ],
  },

  sleeping: {
    keywords: [
      'sleeping','tulog','natutulog','nagpapahinga','napping','nap',
      'resting','rest','asleep','taking a nap','taking a rest',
    ],
    extras: (name) => [
      [
        `${name} is currently getting some rest — probably recharging for whatever's next. 😴`,
        `Sleep is so important; the body and mind need it to stay at their best. ✦`,
        `Best not to disturb them — they'll be back once they're up and refreshed. ◈`,
      ],
      [
        `Looks like ${name} is in rest mode right now. 🌙`,
        `A good nap or sleep session can do wonders for focus and mood. ✦`,
        `They should be available again once they wake up. ◈`,
      ],
      [
        `${name} is taking a rest at the moment. 💤`,
        `Everyone needs their downtime — it's how we come back stronger. ✦`,
        `Give them some time; they'll be up and running soon. ◈`,
      ],
    ],
  },

  working: {
    keywords: [
      'working','nagtatrabaho','trabaho','nag-work','sa work','at work',
      'in the office','office','meeting','sa meeting','nag-meeting',
      'busy','may trabaho','may meeting','in a meeting',
    ],
    extras: (name) => [
      [
        `${name} is deep in work mode right now — fully focused on what needs to get done. 💼`,
        `Interrupting someone mid-workflow can really break their concentration, so it's best to wait. ✦`,
        `They should have some free time once their current task or meeting wraps up. ◈`,
      ],
      [
        `Sounds like ${name} is in the zone right now — probably handling something important. 🖥️`,
        `Productive sessions like that are precious; let them power through. ✦`,
        `Reach out to them once they've had a chance to surface from work mode. ◈`,
      ],
      [
        `${name} is currently occupied with work. 📋`,
        `Whether it's a meeting or a focused task, they're giving it their full attention right now. ✦`,
        `They should be more reachable once things slow down a bit. ◈`,
      ],
    ],
  },

  studying: {
    keywords: [
      'studying','nag-aaral','nag-study','nagbabasa','reading','review',
      'nagrerepaso','doing homework','homework','assignment','exam prep',
      'cramming','nag-aaral pa','may assignment',
    ],
    extras: (name) => [
      [
        `${name} is currently hitting the books — focused and in study mode. 📚`,
        `Deep focus while studying is really important, so it's best not to break their flow. ✦`,
        `They'll have more headspace once they're done with their study session. ◈`,
      ],
      [
        `Looks like ${name} is grinding through some studying right now. 🎓`,
        `That kind of dedication takes real effort — respect the grind! ✦`,
        `They should be free to chat once they've wrapped up their review. ◈`,
      ],
      [
        `${name} is in full study mode at the moment. 📖`,
        `Learning takes focus — they're investing in themselves right now. ✦`,
        `Give them time to finish up; they'll be available soon. ◈`,
      ],
    ],
  },

  exercising: {
    keywords: [
      'gym','exercise','workout','working out','nag-eehersisyo','jogging','running',
      'swimming','laro','playing sports','training','nag-tatrain','nag-gym',
      'fitness','yoga','hiit','cardio','lifting',
    ],
    extras: (name) => [
      [
        `${name} is getting their sweat on right now — all that effort is seriously impressive! 💪`,
        `Exercise takes real discipline and dedication; they're investing in their health. ✦`,
        `They'll be energized and ready to talk once the workout is done. ◈`,
      ],
      [
        `Sounds like ${name} is in beast mode at the moment! 🏋️`,
        `Taking care of the body is just as important as everything else — love to see it. ✦`,
        `They should be back and feeling great once they cool down. ◈`,
      ],
      [
        `${name} is busy working out right now. 🏃`,
        `That kind of commitment to fitness really pays off in the long run. ✦`,
        `Give them a bit — they'll be free and refreshed after their session. ◈`,
      ],
    ],
  },

  gaming: {
    keywords: [
      'gaming','playing','naglalaro','laro','nag-game','video game',
      'mobile game','online game','rank','ranked','nag-rank','naglalaro ng games',
    ],
    extras: (name) => [
      [
        `${name} is in the middle of a gaming session right now — probably deep in concentration mode. 🎮`,
        `Interrupting a game mid-match can be really frustrating, so it's best to wait it out. ✦`,
        `They'll be free once the match or session wraps up. ◈`,
      ],
      [
        `Looks like ${name} is on a gaming run! 🕹️`,
        `Whether it's ranked or casual, they're in their element right now. ✦`,
        `Give them time to finish their game — they'll surface soon. ◈`,
      ],
      [
        `${name} is currently gaming at the moment. 🎯`,
        `Sometimes you just need that downtime to decompress and have fun. ✦`,
        `They should be done and available once the session ends. ◈`,
      ],
    ],
  },

  watching: {
    keywords: [
      'watching','nanunuood','movie','series','netflix','youtube','anime',
      'tv','nanonood','nag-netflix','streaming','nag-stream','nanonood ng pelikula',
    ],
    extras: (name) => [
      [
        `${name} is currently watching something — probably enjoying a bit of well-earned screen time. 📺`,
        `It's always nice to unwind with a good show or movie; everyone needs that. ✦`,
        `They'll be more available once whatever they're watching wraps up. ◈`,
      ],
      [
        `Looks like ${name} is in movie or series mode right now! 🎬`,
        `There's something special about getting lost in a great story — let them enjoy it. ✦`,
        `Catch them once they're done with their watch session. ◈`,
      ],
      [
        `${name} is occupied watching something at the moment. 🍿`,
        `A little entertainment goes a long way — good for the mind and the mood. ✦`,
        `They should be free again once it's over. ◈`,
      ],
    ],
  },

  outside: {
    keywords: [
      'outside','labas','lumabas','out','going out','nag-labas','errands',
      'mall','shopping','grocery','namamasyal','strolling','taking a walk',
      'walk','lakad','may lakad','byahe','commuting','driving','nasa labas',
    ],
    extras: (name) => [
      [
        `${name} is currently out and about — probably handling something or just getting some fresh air. 🚶`,
        `Being outside can be really refreshing; it's good for the mind. ✦`,
        `They should be back and reachable once they're done with their errands or outing. ◈`,
      ],
      [
        `Looks like ${name} stepped out for a bit! 🌤️`,
        `Whether it's errands or a quick break, everyone needs to get out sometimes. ✦`,
        `Give them time to get back — they'll be available again soon. ◈`,
      ],
      [
        `${name} is out at the moment. 🏙️`,
        `A little time outside does wonders — hope it's a good one for them. ✦`,
        `They should be back and reachable before long. ◈`,
      ],
    ],
  },

  busy: {
    keywords: [
      'busy','occupied','not available','unavailable','may gagawin',
      'may ginagawa','hindi available','di available','occupied',
    ],
    extras: (name) => [
      [
        `${name} is tied up with something important right now. ⏳`,
        `When someone's in the middle of a task, it's always best to give them the space to finish. ✦`,
        `They should have more time to connect once things settle down. ◈`,
      ],
      [
        `Sounds like ${name} has their hands full at the moment. 🔒`,
        `Being busy means something worthwhile is getting done — that's never a bad thing. ✦`,
        `Reach out a little later and they'll likely be more available. ◈`,
      ],
    ],
  },
};

// ── Detect which activity category matches ────────────────────────
function detectActivityCategory(activity) {
  const lower = activity.toLowerCase();
  for (const [cat, { keywords }] of Object.entries(ACTIVITY_CATEGORIES)) {
    if (keywords.some(kw => lower.includes(kw))) return cat;
  }
  return null;
}

// ── Get extra sentences for any activity ─────────────────────────
function getActivityExtras(display, activity) {
  const cat = detectActivityCategory(activity);
  if (cat) {
    const pools = ACTIVITY_CATEGORIES[cat].extras(display);
    return pools[Math.floor(Math.random() * pools.length)];
  }
  // Generic fallback for any activity not in the list
  const fallbacks = [
    [
      `${display} seems to be caught up with that right now — things happen! ✦`,
      `It's always good to know what someone's up to; helps set the right expectations. ◈`,
      `They should be more available once they're finished with what they're doing. ✦`,
    ],
    [
      `Sounds like ${display} is occupied at the moment. ◈`,
      `Everyone has their own rhythm and pace — best to respect that and wait it out. ✦`,
      `They'll be free to connect again soon enough. ◈`,
    ],
    [
      `${display} is currently engaged in something. ✦`,
      `Whether it's big or small, whatever they're doing clearly has their attention right now. ◈`,
      `Give them a little time and they should be available again before long. ✦`,
    ],
  ];
  return fallbacks[Math.floor(Math.random() * fallbacks.length)];
}

// ── Status query interceptor ──────────────────────────────────────
function checkStatusQuery(message) {
  if (!Object.keys(adminStatuses).length) return null;
  const msg = message.toLowerCase().replace(/[?!.,]/g, '').trim();

  // ── Expanded asking patterns (English + Filipino + Taglish) ──────
  const askingPatterns = [
    // English
    /what.*doing/, /what.*up\s*to/, /what.*doing\s*right\s*now/,
    /what.*currently/, /is.*doing/, /doing\s*now/, /doing\s*right\s*now/,
    /what.*status/, /how.*is\s+\w+/, /where.*is/, /is.*available/,
    /is.*busy/, /is.*free/, /is.*around/, /is.*there/, /can.*talk/,
    /is.*online/, /what.*\w+\s*up\s*to/, /what.*\w+\s*doing/,
    /\bhow.*going\b/, /\bwhat.*happening\b/, /\bwhat.*\w+\s*been\s*doing\b/,
    /\bwhere.*\w+\s*at\b/, /\bwhat.*\w+\s*like\b/,
    // Filipino / Tagalog
    /anong\s*ginagawa/, /ano.*ginagawa/, /kumusta.*ngayon/,
    /nasa\s*saan/, /nasaan/, /nasan/,
    /ano.*ginagawa.*ngayon/, /ano.*ginagawa.*niya/, /ano.*ginagawa.*nila/,
    /kamusta.*ngayon/, /ano.*balita/, /ano.*nangyayari/,
    /libre\s*ba/, /available\s*ba/, /busy\s*ba/, /pwede\s*ba/,
    /pwede.*makausap/, /makakaausap\s*ba/, /kasalukuyan/,
    /saan.*nandoon/, /nandoon\s*ba/, /nandito\s*ba/,
    /anong.*oras\s*matapos/, /kailan.*matapos/, /kailan.*libre/,
    /nasa.*bahay\s*ba/, /nasa.*labas\s*ba/,
    // Taglish
    /what.*ginagawa/, /anong.*doing/, /is.*available\s*ba/,
    /free\s*ba\s*siya/, /busy\s*ba\s*siya/, /ano.*up\s*to/,
  ];

  const isAskingAboutActivity = askingPatterns.some(p => p.test(msg));
  if (!isAskingAboutActivity) return null;

  for (const [, { display, activity, ts }] of Object.entries(adminStatuses)) {
    const nameParts = display.toLowerCase().split(/\s+/).filter(p => p.length > 1);
    const matched   = nameParts.some(part => msg.includes(part));
    if (matched) {
      // ── Timestamp-aware duration string ─────────────────────────
      let durationNote = '';
      if (ts) {
        const mins = Math.floor((Date.now() - ts) / 60000);
        const hrs  = Math.floor(mins / 60);
        if (hrs > 0) {
          durationNote = ` (for about ${hrs} hour${hrs > 1 ? 's' : ''}${mins % 60 > 0 ? ` ${mins % 60} min` : ''})`;
        } else if (mins > 2) {
          durationNote = ` (for about ${mins} minute${mins > 1 ? 's' : ''})`;
        } else if (mins >= 0) {
          durationNote = ` (just recently)`;
        }
      }

      const baseReplies = [
        `◈ ${display} is currently **${activity}**${durationNote}. ✦`,
        `Right now, ${display} is **${activity}**${durationNote}. ◈`,
        `${display} is **${activity}** at the moment${durationNote}. ✦`,
        `◈ As of now, ${display} is **${activity}**${durationNote}. ✦`,
      ];
      const base   = baseReplies[Math.floor(Math.random() * baseReplies.length)];
      const extras = getActivityExtras(display, activity);
      return base + '\n\n' + extras.join(' ');
    }
  }
  return null;
}

// ══════════════════════════════════════════════════════════════════
// ◈ REPLY THREADING — tap any Luna message to reply to it
// ══════════════════════════════════════════════════════════════════

// Inject the reply bar element above the input box
function injectReplyBar() {
  const bar = document.createElement('div');
  bar.id = 'replyBar';
  bar.innerHTML = `
    <div class="reply-bar-accent"></div>
    <div class="reply-bar-info">
      <div class="reply-bar-label">↩ REPLYING TO LUNA</div>
      <div class="reply-bar-preview" id="replyBarPreview"></div>
    </div>
    <button class="reply-bar-close" onclick="clearReplyContext()" title="Cancel reply">✕</button>
  `;
  const inputBox = document.getElementById('inputBox');
  if (inputBox && inputBox.parentNode) {
    inputBox.parentNode.insertBefore(bar, inputBox);
  }
}

// Activate reply mode: highlight the source Luna message, show the reply bar
function setReplyContext(msgId, rawText) {
  const plain = rawText.replace(/\s+/g, ' ').trim();
  replyingTo = { msgId, previewText: plain.slice(0, 100) + (plain.length > 100 ? '…' : '') };

  const preview = document.getElementById('replyBarPreview');
  if (preview) preview.textContent = replyingTo.previewText;

  const bar = document.getElementById('replyBar');
  if (bar) bar.classList.add('active');

  // Clear any previous highlight, then highlight the target message
  document.querySelectorAll('.message.reply-active').forEach(m => m.classList.remove('reply-active'));
  const src = document.querySelector(`.message[data-msg-id="${msgId}"]`);
  if (src) {
    src.classList.add('reply-active');
    src.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
  }

  userInput.focus();
}

// Cancel reply mode
function clearReplyContext() {
  replyingTo = null;
  const bar = document.getElementById('replyBar');
  if (bar) bar.classList.remove('active');
  document.querySelectorAll('.message.reply-active').forEach(m => m.classList.remove('reply-active'));
}

// Click handler on the reply quote block — scrolls to the original Luna message and flashes it
function jumpToReplyTarget(msgId) {
  const target = document.querySelector(`.message[data-msg-id="${msgId}"]`);
  if (!target) return;
  target.scrollIntoView({ behavior: 'smooth', block: 'center' });
  const bubble = target.querySelector('.bubble');
  if (!bubble) return;
  // Flash border briefly to draw the eye
  bubble.style.transition = 'border-color 0.1s, box-shadow 0.1s';
  bubble.style.borderColor = 'var(--violet-bright)';
  bubble.style.boxShadow   = '0 0 22px rgba(168,85,247,0.3)';
  setTimeout(() => {
    bubble.style.borderColor = '';
    bubble.style.boxShadow   = '';
    setTimeout(() => { bubble.style.transition = ''; }, 400);
  }, 1600);
}

// ── Handle send ───────────────────────────────────────────────────
async function handleSend() {
  const text = userInput.value.trim();
  if (!stagedFiles.length && !stagedImage && (!text || isTyping)) return;
  if (isTyping) return;


  // ── Capture and clear reply context before anything else ─────
  const replyCtx = replyingTo;
  clearReplyContext();

  if (stagedImage) {
    const img = stagedImage, msg = text;
    stagedImage = null; clearStagedImage();
    userInput.value = ''; userInput.style.height = 'auto'; charCounter.textContent = '0/2000';
    await processImage(img, msg); return;
  }

  if (stagedFiles.length) {
    const files = stagedFiles, msg = text;
    stagedFiles = [];
    document.getElementById('fileBadge').style.display = 'none';
    userInput.value = ''; userInput.style.height = 'auto'; charCounter.textContent = '0/2000';
    await processFiles(files, msg); return;
  }

  isTyping = true; sendBtn.disabled = true;
  showStopBtn();
  lastUserText = text;
  // ◈ Streak — record that the user chatted now (thaws frozen egg, resets idle timer)
  recordStreakChatActivity();

  // ◈ Tone Detector — auto-shift Luna's mood ring based on message tone
  const detectedTone = detectToneFromMessage(text);
  autoSetLunaMood(detectedTone);

  // ── Auto-moderation check ──────────────────────────────────────
  const blocked = await runAutoModCheck(text);
  if (blocked) { isTyping = false; return; }

  const userMsgId = await appendMessage('user', text, replyCtx);
  userInput.value = ''; userInput.style.height = 'auto'; charCounter.textContent = '0/2000';
  // Haptic feedback on mobile — subtle confirmation of send
  if (navigator.vibrate) navigator.vibrate(18);

  // ── Build Luna's reply-data so her bubble quotes the user's message ──
  // Only attach when this exchange was itself a threaded reply (replyCtx existed)
  const lunaReplyData = replyCtx
    ? { msgId: userMsgId, previewText: text.slice(0, 100) + (text.length > 100 ? '…' : ''), fromUser: true }
    : null;

  showTyping();

  try {
    const statusHit = checkStatusQuery(text);
    if (statusHit) {
      hideTyping();
      lastLunaText = statusHit;
      conversationHistory.push({ role: 'user', content: text });
      conversationHistory.push({ role: 'assistant', content: statusHit });
      await appendMessage('luna', statusHit, lunaReplyData);
      isTyping = false; sendBtn.disabled = false; focusInputDesktopOnly();
      return;
    }

    let finalPrompt = text;
    const url = extractURL(text);
    if (url) {
      // ── Safety check before fetching ──────────────────────────
      const { verdict, reason } = classifyURL(url);
      if (verdict === 'block') {
        // Block outright — show modal, do not fetch, let Luna explain
        hideTyping();
        await showLinkSafetyModal(url, 'block', reason);
        finalPrompt = `The user tried to share a link (${url}) but it was BLOCKED by Luna's link safety system because: ${reason}. Tell the user it has been blocked for their safety, in a brief, caring way. Do not provide any workaround.`;
        const reply2 = await getLunaResponse(finalPrompt);
        conversationHistory.push({ role: 'user', content: text });
        conversationHistory.push({ role: 'assistant', content: reply2 });
        hideTyping(); lastLunaText = reply2;
        await appendMessage('luna', reply2, lunaReplyData);
        isTyping = false; sendBtn.disabled = false; focusInputDesktopOnly(); return;
      }
      if (verdict === 'warn') {
        // Show warning, let user decide
        hideTyping();
        const allowed = await showLinkSafetyModal(url, 'warn', reason);
        if (!allowed) {
          // User cancelled — acknowledge and stop
          await appendMessage('luna', `◈ Link scan cancelled. The link was not opened. If you still want to share it, you can try again. ✦`);
          isTyping = false; sendBtn.disabled = false; focusInputDesktopOnly(); return;
        }
        showTyping();
      }
      // Safe or user approved — fetch the page
      hideTyping();
      await appendMessage('luna', `◈ Scanning link: <a href="${escHtml(url)}" target="_blank" rel="noopener noreferrer" style="color:var(--violet-bright);word-break:break-all;">${escHtml(url)}</a> ✦`);
      showTyping();
      try {
        const pageContent = await fetchWebpage(url);
        finalPrompt = `The user shared this URL: ${url}\n\nWebpage content (extracted text):\n\n${pageContent}\n\nUser message: ${text.replace(url,'').trim() || 'Please summarize this page.'}`;
      } catch (fetchErr) {
        finalPrompt = `The user shared this URL: ${url} but it could not be fetched (${fetchErr.message}). Let them know briefly and offer alternatives.`;
      }
    }
    // ── LIVE STREAMING — build bubble immediately, pipe tokens in as they arrive ──
    hideTyping();
    const lunaWrap = buildMessageWrap('luna', '', true, lunaReplyData);
    chatFeed.appendChild(lunaWrap);
    if (userScrolledUp) {
      newMsgCount++;
      fabBadge.textContent = newMsgCount > 9 ? '9+' : newMsgCount;
      fabBadge.style.display = 'flex';
    }
    scrollDown();

    const reply = await streamLunaResponseLive(finalPrompt, lunaWrap);

    // Post-stream bookkeeping (same as appendMessage path)
    lastLunaText = reply;
    conversationHistory.push({ role: 'user', content: text });
    conversationHistory.push({ role: 'assistant', content: reply });
    if (conversationHistory.length > 20) conversationHistory = conversationHistory.slice(-20);
    updateMoodRing(reply);
    pushMessageToFirebase('assistant', reply);
    saveMessageToUserChatlog('assistant', reply);
    persistedHistory.push({ role: 'assistant', content: reply, ts: Date.now() });
    if (persistedHistory.length > CHATLOG_MAX_MSGS) persistedHistory = persistedHistory.slice(-CHATLOG_MAX_MSGS);
    msgCount++;
    msgDisplay.textContent = msgCount;
    animateStats();

    // ── Cross-user mention scan: did user mention another registered user? ──
    scanForUserMentions(text).catch(() => {});
  } catch (err) {
    hideTyping();
    // AbortError = user pressed STOP — no error message needed
    if (err.name === 'AbortError') {
      isTyping = false; sendBtn.disabled = false; hideStopBtn(); focusInputDesktopOnly();
      return;
    }
    // Rate limit errors already have a friendly message; raw API faults get sanitised
    const isRateLimit = /rate limit|try again|429/i.test(err.message || '');
    const displayMsg = isRateLimit
      ? `◈ ${err.message}`
      : `◈ Neural disruption detected — please re-transmit. ✦`;
    await appendMessage('luna', displayMsg);
  }
  isTyping = false; sendBtn.disabled = false; hideStopBtn(); focusInputDesktopOnly();
}

// ══════════════════════════════════════════════════════════════════
// ◈ ACCOUNT SYSTEM — Sign Up / Sign In / Presence
// ══════════════════════════════════════════════════════════════════

let authMode = 'signin'; // 'signin' | 'signup'

// ── Switch between Sign In and Create Account tabs ────────────────
function switchAuthTab(mode) {
  authMode = mode;
  const isSignup = mode === 'signup';
  document.getElementById('tabSignIn').classList.toggle('active', !isSignup);
  document.getElementById('tabSignUp').classList.toggle('active',  isSignup);
  document.getElementById('confirmField').style.display = isSignup ? 'flex' : 'none';
  document.getElementById('secQField').style.display    = isSignup ? 'flex' : 'none';
  document.getElementById('secAField').style.display    = isSignup ? 'flex' : 'none';
  const forgotLink = document.getElementById('forgotPwLink');
  if (forgotLink) forgotLink.style.display = isSignup ? 'none' : 'block';
  document.getElementById('submitBtnLabel').textContent  = isSignup ? 'CREATE ACCOUNT ◈' : 'SIGN IN ◈';
  clearAuthMsg();
  validateAuthForm();
  // focus password after name if already filled
  const ni = document.getElementById('nameInput');
  if (ni.value.trim()) document.getElementById('passwordInput').focus();
  else ni.focus();
}

// ── Show/hide admin code prompt ───────────────────────────────────
function showAdminCodePrompt() {
  const overlay = document.getElementById('adminCodeOverlay');
  overlay.style.display = 'flex';
  setTimeout(() => document.getElementById('adminCodeInput')?.focus(), 100);
}
function hideAdminCodePrompt() {
  const overlay = document.getElementById('adminCodeOverlay');
  overlay.style.display = 'none';
  if (document.getElementById('adminCodeInput')) document.getElementById('adminCodeInput').value = '';
}

// ══════════════════════════════════════════════════════════════════
// ◈ FORGOT PASSWORD — 3-step recovery flow
// ══════════════════════════════════════════════════════════════════

let fpwAccountKey = null; // key of account being recovered

function openForgotPassword() {
  fpwAccountKey = null;
  fpwGoToStep(1);
  fpwClearMsg();
  const overlay = document.getElementById('forgotPwOverlay');
  overlay.classList.add('open');
  document.getElementById('fpwUsername').value = '';
  document.getElementById('fpwAnswer').value   = '';
  document.getElementById('fpwNewPass').value  = '';
  document.getElementById('fpwConfirmPass').value = '';
  document.getElementById('fpwSub').textContent = 'Enter your username to begin the recovery process.';
  // Pre-fill username if already typed in sign-in form
  const existing = document.getElementById('nameInput')?.value.trim();
  if (existing) document.getElementById('fpwUsername').value = existing;
  setTimeout(() => document.getElementById('fpwUsername').focus(), 180);
  // Wire up input listeners
  document.getElementById('fpwUsername').oninput    = () => {
    document.getElementById('fpwStep1Btn').disabled = !document.getElementById('fpwUsername').value.trim();
    fpwClearMsg();
  };
  document.getElementById('fpwAnswer').oninput      = () => {
    document.getElementById('fpwStep2Btn').disabled = !document.getElementById('fpwAnswer').value.trim();
    fpwClearMsg();
  };
  ['fpwNewPass','fpwConfirmPass'].forEach(id => {
    document.getElementById(id).oninput = fpwValidateNewPass;
  });
  // Enter key support
  document.getElementById('fpwUsername').onkeydown    = e => { if (e.key === 'Enter') fpwLookup(); };
  document.getElementById('fpwAnswer').onkeydown      = e => { if (e.key === 'Enter') fpwVerifyAnswer(); };
  document.getElementById('fpwConfirmPass').onkeydown = e => { if (e.key === 'Enter') fpwResetPassword(); };
}

function closeForgotPassword() {
  document.getElementById('forgotPwOverlay').classList.remove('open');
  fpwAccountKey = null;
}

function fpwGoToStep(n) {
  [1,2,3].forEach(i => {
    const step = document.getElementById(`fpwStep${i}`);
    const dot  = document.getElementById(`fpwDot${i}`);
    if (step) step.classList.toggle('active', i === n);
    if (dot) {
      dot.classList.remove('active','done');
      if (i === n)  dot.classList.add('active');
      if (i < n)    dot.classList.add('done');
    }
  });
  fpwClearMsg();
}

function fpwShowMsg(msg, type = 'error') {
  const el = document.getElementById('fpwMsg');
  if (!el) return;
  el.textContent = msg;
  el.className = `fpw-msg ${type}`;
}
function fpwClearMsg() {
  const el = document.getElementById('fpwMsg');
  if (el) { el.textContent = ''; el.className = 'fpw-msg'; }
}

// Step 1 — look up account by username
async function fpwLookup() {
  const raw = document.getElementById('fpwUsername').value.trim();
  if (!raw) return;
  if (!firebaseReady || !firebaseDb) { fpwShowMsg('Firebase offline. Cannot recover password.'); return; }
  const btn = document.getElementById('fpwStep1Btn');
  btn.disabled = true; btn.textContent = 'SEARCHING…';
  try {
    const key  = userKey(raw);
    const snap = await firebaseDb.ref(`luna-accounts/${key}`).once('value');
    if (!snap.exists()) {
      fpwShowMsg(`No account found for "${raw}". Check spelling or create a new account.`); return;
    }
    const account = snap.val();
    fpwAccountKey = key;
    if (account.secQ) {
      // Has a security question
      document.getElementById('fpwQuestionLabel').textContent = account.secQ;
      document.getElementById('fpwSub').textContent = `Account found! Answer your security question to continue.`;
      fpwGoToStep(2);
      setTimeout(() => document.getElementById('fpwAnswer').focus(), 150);
    } else {
      // Old account with no security question — skip straight to reset
      // (less secure but avoids locking users out forever)
      document.getElementById('fpwSub').textContent = `Account found. No security question on file — set your new password directly.`;
      fpwGoToStep(3);
      fpwGoToStep(3); // also mark dot 2 done
      document.getElementById('fpwDot2').classList.remove('active');
      document.getElementById('fpwDot2').classList.add('done');
      document.getElementById('fpwDot3').classList.add('active');
      setTimeout(() => document.getElementById('fpwNewPass').focus(), 150);
    }
  } catch (err) {
    fpwShowMsg('Lookup failed. Please try again.'); console.warn(err);
  } finally {
    btn.disabled = false; btn.innerHTML = `
      <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>
      FIND ACCOUNT ◈`;
  }
}

// Step 2 — verify security answer
async function fpwVerifyAnswer() {
  const answer = document.getElementById('fpwAnswer').value.trim().toLowerCase();
  if (!answer || !fpwAccountKey) return;
  if (!firebaseReady || !firebaseDb) { fpwShowMsg('Firebase offline.'); return; }
  const btn = document.getElementById('fpwStep2Btn');
  btn.disabled = true; btn.textContent = 'VERIFYING…';
  try {
    const snap = await firebaseDb.ref(`luna-accounts/${fpwAccountKey}`).once('value');
    const account = snap.val();
    if (!account) { fpwShowMsg('Account not found. Please restart.'); return; }
    const stored = account.secA ? (() => { try { return atob(account.secA); } catch { return ''; } })() : '';
    if (answer !== stored) {
      fpwShowMsg('Incorrect answer. Please try again.'); return;
    }
    document.getElementById('fpwSub').textContent = 'Identity verified! Choose a new password.';
    fpwGoToStep(3);
    setTimeout(() => document.getElementById('fpwNewPass').focus(), 150);
  } catch (err) {
    fpwShowMsg('Verification failed. Try again.'); console.warn(err);
  } finally {
    btn.disabled = false; btn.innerHTML = `
      <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="20 6 9 17 4 12"/></svg>
      VERIFY ANSWER ◈`;
  }
}

// Step 3 — validate passwords match before enabling button
function fpwValidateNewPass() {
  const p1 = document.getElementById('fpwNewPass').value;
  const p2 = document.getElementById('fpwConfirmPass').value;
  const btn = document.getElementById('fpwStep3Btn');
  if (!btn) return;
  btn.disabled = !(p1.length >= 4 && p1 === p2);
  if (p2.length > 0 && p1 !== p2) {
    fpwShowMsg('Passwords do not match.');
  } else {
    fpwClearMsg();
  }
}

// Step 3 — write new password to Firebase
async function fpwResetPassword() {
  const newPass = document.getElementById('fpwNewPass').value;
  const confirm = document.getElementById('fpwConfirmPass').value;
  if (newPass.length < 4) { fpwShowMsg('Password must be at least 4 characters.'); return; }
  if (newPass !== confirm) { fpwShowMsg('Passwords do not match.'); return; }
  if (!fpwAccountKey || !firebaseReady || !firebaseDb) { fpwShowMsg('Session expired. Please restart.'); return; }
  const btn = document.getElementById('fpwStep3Btn');
  btn.disabled = true; btn.textContent = 'SAVING…';
  try {
    await firebaseDb.ref(`luna-accounts/${fpwAccountKey}`).update({ password: btoa(newPass) });
    fpwShowMsg('Password reset successfully! You can now sign in. ◈', 'success');
    document.getElementById('fpwDot3').classList.remove('active');
    document.getElementById('fpwDot3').classList.add('done');
    // Auto-close and pre-fill the sign-in form after a moment
    setTimeout(() => {
      closeForgotPassword();
      const acSnap = firebaseDb.ref(`luna-accounts/${fpwAccountKey}`).once('value');
      acSnap.then(s => {
        const nm = s.val()?.name || '';
        if (nm) document.getElementById('nameInput').value = nm;
        document.getElementById('passwordInput').value = '';
        document.getElementById('passwordInput').focus();
        showAuthMsg('Password reset! Enter your new password to sign in.', 'success');
        validateAuthForm();
      });
    }, 2200);
  } catch (err) {
    fpwShowMsg('Reset failed. Please try again.'); console.warn(err);
    btn.disabled = false; btn.innerHTML = `
      <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/></svg>
      RESET PASSWORD ◈`;
  }
}
function submitAdminCode() {
  const code = document.getElementById('adminCodeInput')?.value.trim();
  if (code === ADMIN_CODE) {
    hideAdminCodePrompt();
    dismissNameOverlay(() => enterAdmin());
  } else {
    document.getElementById('adminCodeInput').classList.add('error');
    setTimeout(() => document.getElementById('adminCodeInput')?.classList.remove('error'), 1200);
  }
}

// ── Auth message helper ───────────────────────────────────────────
function showAuthMsg(msg, type = 'error') {
  const el = document.getElementById('neMsg');
  if (!el) return;
  el.textContent = msg;
  el.className   = `ne-msg ${type}`;
}
function clearAuthMsg() {
  const el = document.getElementById('neMsg');
  if (el) { el.textContent = ''; el.className = 'ne-msg'; }
}

// ── Validate form → enable/disable submit ─────────────────────────
function validateAuthForm() {
  const name    = document.getElementById('nameInput')?.value.trim() || '';
  const pass    = document.getElementById('passwordInput')?.value    || '';
  const confirm = document.getElementById('confirmInput')?.value     || '';
  const ok = authMode === 'signin'
    ? name.length >= 2 && pass.length >= 4
    : name.length >= 2 && pass.length >= 4 && confirm.length >= 4;
  const btn = document.getElementById('nameSubmitBtn');
  if (btn) btn.disabled = !ok;
}

// ── Init auth overlay ─────────────────────────────────────────────
function initNameEntry() {
  ['nameInput','passwordInput','confirmInput'].forEach(id => {
    const el = document.getElementById(id);
    if (!el) return;
    el.addEventListener('input', () => { clearAuthMsg(); validateAuthForm(); });
    el.addEventListener('keydown', e => {
      if (e.key === 'Enter') {
        e.preventDefault();
        if (!document.getElementById('nameSubmitBtn').disabled) handleAuthSubmit();
      }
    });
  });
  document.getElementById('nameSubmitBtn')?.addEventListener('click', handleAuthSubmit);
  document.getElementById('adminCodeInput')?.addEventListener('keydown', e => {
    if (e.key === 'Enter') submitAdminCode();
  });
  setTimeout(() => document.getElementById('nameInput')?.focus(), 600);
}

// ── Dispatch sign-in or sign-up ───────────────────────────────────
async function handleAuthSubmit() {
  const name    = document.getElementById('nameInput').value.trim();
  const pass    = document.getElementById('passwordInput').value;
  const confirm = document.getElementById('confirmInput')?.value || '';
  const btn     = document.getElementById('nameSubmitBtn');
  if (!name || pass.length < 4) return;
  btn.disabled = true;
  btn.classList.add('loading');
  document.getElementById('submitBtnLabel').textContent = 'CONNECTING…';

  try {
    if (authMode === 'signup') await handleSignUp(name, pass, confirm);
    else                       await handleSignIn(name, pass);
  } finally {
    btn.classList.remove('loading');
    document.getElementById('submitBtnLabel').textContent =
      authMode === 'signup' ? 'CREATE ACCOUNT ◈' : 'SIGN IN ◈';
    validateAuthForm();
  }
}

// ── Generate a stable key from a username ────────────────────────
function userKey(name) {
  return name.toLowerCase().replace(/[^a-z0-9]/g, '_').slice(0,32);
}

// ── localStorage Account Store — offline / local-file fallback ──────
const LS_ACCOUNTS_KEY = 'luna-local-accounts';

function lsGetAccounts() {
  try { return JSON.parse(localStorage.getItem(LS_ACCOUNTS_KEY) || '{}'); } catch { return {}; }
}
function lsSaveAccount(key, data) {
  try {
    const accounts = lsGetAccounts();
    accounts[key] = data;
    localStorage.setItem(LS_ACCOUNTS_KEY, JSON.stringify(accounts));
  } catch {}
}
function lsGetAccount(key) {
  return lsGetAccounts()[key] || null;
}

// ── Persistent Session — remember logged-in user across page loads ─
const SESSION_STORAGE_KEY = 'luna-persistent-session';
const IDB_NAME            = 'LunaDB';
const IDB_STORE           = 'session';
const IDB_KEY             = 'persist';

// ── IndexedDB helpers — works on file://, survives localStorage clears ──
function _idbOpen() {
  return new Promise((resolve, reject) => {
    const req = indexedDB.open(IDB_NAME, 1);
    req.onupgradeneeded = e => e.target.result.createObjectStore(IDB_STORE);
    req.onsuccess = e => resolve(e.target.result);
    req.onerror   = e => reject(e.target.error);
  });
}
async function idbSave(data) {
  try {
    const db  = await _idbOpen();
    const tx  = db.transaction(IDB_STORE, 'readwrite');
    tx.objectStore(IDB_STORE).put(data, IDB_KEY);
    await new Promise((res, rej) => { tx.oncomplete = res; tx.onerror = rej; });
    db.close();
  } catch {}
}
async function idbLoad() {
  try {
    const db   = await _idbOpen();
    const tx   = db.transaction(IDB_STORE, 'readonly');
    const data = await new Promise((res, rej) => {
      const req = tx.objectStore(IDB_STORE).get(IDB_KEY);
      req.onsuccess = () => res(req.result);
      req.onerror   = () => rej(req.error);
    });
    db.close();
    return (data && data.name && data.key) ? data : null;
  } catch { return null; }
}
async function idbClear() {
  try {
    const db = await _idbOpen();
    const tx = db.transaction(IDB_STORE, 'readwrite');
    tx.objectStore(IDB_STORE).delete(IDB_KEY);
    await new Promise((res, rej) => { tx.oncomplete = res; tx.onerror = rej; });
    db.close();
  } catch {}
}

// ── Session save — writes to localStorage (fast) + IndexedDB (durable) ──
function savePersistedSession(name, key) {
  const data = { name, key, ts: Date.now() };
  try { localStorage.setItem(SESSION_STORAGE_KEY, JSON.stringify(data)); } catch {}
  idbSave(data);
}

// ── Session clear — wipes both stores ──
function clearPersistedSession() {
  try { localStorage.removeItem(SESSION_STORAGE_KEY); } catch {}
  idbClear();
}

// ── Sync check of localStorage only (fast, called first) ──
function loadPersistedSession() {
  try {
    const raw = localStorage.getItem(SESSION_STORAGE_KEY);
    if (raw) {
      const data = JSON.parse(raw);
      if (data && data.name && data.key) return data;
    }
  } catch {}
  return null;
}

// ── Async fallback — reads IndexedDB when localStorage came up empty ──
async function loadPersistedSessionAsync() {
  const data = await idbLoad();
  if (data) {
    try { localStorage.setItem(SESSION_STORAGE_KEY, JSON.stringify(data)); } catch {}
    return data;
  }
  return null;
}

// ── SIGN UP — create new account in Firebase + localStorage fallback ─
async function handleSignUp(name, pass, confirm) {
  if (pass !== confirm) { showAuthMsg('Passwords do not match.'); return; }
  const key = userKey(name);
  const secQ = document.getElementById('secQSelect')?.value  || '';
  const secA = document.getElementById('secAInput')?.value.trim().toLowerCase() || '';
  if (!secQ || !secA) { showAuthMsg('Please choose a security question and provide an answer.'); return; }

  const accountData = {
    name, key,
    password: btoa(pass),
    secQ,
    secA: btoa(secA),
    createdAt: Date.now(),
  };

  // Always save to localStorage (works offline / local file)
  if (lsGetAccount(key)) {
    showAuthMsg(`Username "${name}" is already taken. Try another or sign in.`); return;
  }
  lsSaveAccount(key, accountData);

  // Also try Firebase if available
  if (firebaseReady && firebaseDb) {
    try {
      const snap = await firebaseDb.ref(`luna-accounts/${key}`).once('value');
      if (snap.exists()) {
        showAuthMsg(`Username "${name}" is already taken. Try another or sign in.`); return;
      }
      await firebaseDb.ref(`luna-accounts/${key}`).set(accountData);
    } catch (err) {
      console.warn('Firebase signup write failed (localStorage used):', err);
    }
  }

  showAuthMsg('Account created! Signing you in…', 'success');
  await new Promise(r => setTimeout(r, 900));
  await enterChat(name, key);
  savePersistedSession(name, key);
}

// ── SIGN IN — verify credentials (Firebase + localStorage fallback) ─
async function handleSignIn(name, pass) {
  const key = userKey(name);

  // ── Try Firebase first (if online) ───────────────────────────────
  if (firebaseReady && firebaseDb) {
    try {
      const snap = await firebaseDb.ref(`luna-accounts/${key}`).once('value');
      if (snap.exists()) {
        const account = snap.val();
        if (atob(account.password) !== pass) {
          showAuthMsg('Incorrect password. Please try again.'); return;
        }
        // Mirror account to localStorage for offline use
        lsSaveAccount(key, account);
        // ── Check ban / suspend status ──────────────────────────
        const banStatus = await checkUserBanStatus(account.name || name);
        if (banStatus) {
          if (banStatus.type === 'ban') {
            showAuthMsg(`⬡ This account is permanently banned. ${banStatus.reason || ''}`); return;
          }
          if (banStatus.type === 'suspend' && banStatus.until > Date.now()) {
            const mins = Math.ceil((banStatus.until - Date.now()) / 60000);
            const unit = mins >= 60 ? `${Math.ceil(mins/60)}h` : `${mins}m`;
            showAuthMsg(`⬡ This account is suspended for ${unit} more. ${banStatus.reason || ''}`); return;
          }
          if (banStatus.type === 'suspend') {
            firebaseDb.ref(`luna-bans/${banKey(account.name || name)}`).remove().catch(()=>{});
          }
        }
        await enterChat(account.name, key);
        savePersistedSession(account.name, key);
        return;
      }
      // Account not in Firebase — fall through to localStorage
    } catch (err) {
      console.warn('Firebase sign-in lookup failed, trying localStorage:', err);
    }
  }

  // ── localStorage fallback (offline / local file / Firebase miss) ──
  const localAccount = lsGetAccount(key);
  if (localAccount) {
    try {
      if (atob(localAccount.password) !== pass) {
        showAuthMsg('Incorrect password. Please try again.'); return;
      }
      showAuthMsg('Signing in…', 'success');
      await new Promise(r => setTimeout(r, 500));
      await enterChat(localAccount.name || name, key, !firebaseReady);
      savePersistedSession(localAccount.name || name, key);
      return;
    } catch (err) {
      console.warn('localStorage sign-in error:', err);
    }
  }

  // ── No account found anywhere — offer to create one ──────────────
  showAuthMsg(`No account found for "${name}". Please create an account first.`);
}

// ── Firebase path helpers ─────────────────────────────────────────
function userChatlogRef() {
  if (!firebaseReady || !firebaseDb || !currentUserId) return null;
  return firebaseDb.ref(`luna-user-chatlogs/${currentUserId}`);
}
function userProfileRef(key) {
  if (!firebaseReady || !firebaseDb) return null;
  return firebaseDb.ref(`luna-user-profiles/${key || currentUserId}`);
}

// ── Save a message to user's Firebase chatlog (fire-and-forget) ───
function saveMessageToUserChatlog(role, content) {
  const ref = userChatlogRef();
  if (!ref) return;
  ref.push({ role, content, ts: Date.now() })
    .then(async () => {
      // Trim to max — keep only the freshest CHATLOG_MAX_MSGS entries
      try {
        const snap = await ref.orderByChild('ts').once('value');
        const msgs = [];
        snap.forEach(c => msgs.push({ key: c.key, ts: c.val().ts }));
        if (msgs.length > CHATLOG_MAX_MSGS) {
          const oldest = msgs.sort((a,b) => a.ts - b.ts).slice(0, msgs.length - CHATLOG_MAX_MSGS);
          await Promise.all(oldest.map(m => ref.child(m.key).remove()));
        }
      } catch {}
    })
    .catch(err => console.warn('Chatlog write failed:', err));
}

// ── Load user's full chatlog from Firebase ────────────────────────
async function loadUserChatlog() {
  const ref = userChatlogRef();
  if (!ref) return [];
  try {
    const snap = await ref.orderByChild('ts').limitToLast(CHATLOG_MAX_MSGS).once('value');
    const msgs = [];
    snap.forEach(c => msgs.push(c.val()));
    return msgs; // ascending by ts
  } catch { return []; }
}

// ── Load all registered users for cross-mention detection ─────────
async function loadRegisteredUsers() {
  if (!firebaseReady || !firebaseDb) return;
  try {
    const snap = await firebaseDb.ref('luna-accounts').once('value');
    const data = snap.val() || {};
    const all  = Object.values(data)
      .map(u => ({ name: (u.name || '').trim(), key: u.key || '', createdAt: u.createdAt || 0 }))
      .filter(u => u.name && u.key);

    // For mention scanning — everyone except self
    allRegisteredUsers = all.filter(u => u.key !== currentUserId);

    // For Luna's awareness — ALL users including self, sorted by join date
    allRegisteredUsers._fullRoster = all.sort((a, b) => a.createdAt - b.createdAt);
  } catch {}
}

// ── Load facts others mentioned about this user ───────────────────
async function loadUserProfile() {
  if (!firebaseReady || !firebaseDb || !currentUserId) return;
  try {
    const snap = await firebaseDb.ref(`luna-user-profiles/${currentUserId}`).once('value');
    userProfileCache = snap.val() || {};
  } catch {}
}

// ── Scan message for mentions of other registered users ───────────
// When Alfred says "khy loves music" → save that fact under Khy's profile
async function scanForUserMentions(text) {
  if (!allRegisteredUsers.length || !firebaseReady || !firebaseDb) return;
  const lower = text.toLowerCase();
  for (const user of allRegisteredUsers) {
    if (!user.name || user.name.length < 2) continue;
    const nameLower = user.name.toLowerCase();
    // Match whole-word-ish: the name appears as a standalone word
    const regex = new RegExp(`\\b${nameLower}\\b`, 'i');
    if (regex.test(lower)) {
      const factEntry = {
        mentionedBy: userName || 'someone',
        mentionedByKey: currentUserId || '',
        context: text.trim().slice(0, 400),
        ts: Date.now(),
      };
      try {
        await firebaseDb.ref(`luna-user-profiles/${user.key}/mentions`).push(factEntry);
      } catch {}
    }
  }
}

// ── Build Luna's memory context string for the system prompt ──────
function buildMemoryContext() {
  let memBlock = '';

  // 0. Platform user roster — Luna always knows who's registered
  const roster = allRegisteredUsers._fullRoster || allRegisteredUsers;
  if (roster.length > 0) {
    const names = roster.map(u => u.name).join(', ');
    memBlock += `\n\n===== PLATFORM USERS LUNA KNOWS ABOUT =====\n`;
    memBlock += `The following users are registered on this platform. You know all of them exist:\n`;
    memBlock += names;
    memBlock += `\n(When asked if someone exists, check this list. If their name appears here, confirm they are a registered user.)\n`;
    memBlock += `===== END ROSTER =====`;
  }

  // 1. Past conversation history with this user
  if (persistedHistory.length > 0) {
    const recent = persistedHistory.slice(-MEMORY_CTX_MSGS);
    const formatted = recent.map(m => {
      const speaker = m.role === 'assistant' ? 'LUNA' : (userName || 'USER').toUpperCase();
      return `${speaker}: ${m.content.replace(/\n+/g, ' ').slice(0, 200)}`;
    }).join('\n');
    memBlock += `\n\n===== LUNA'S MEMORY — PAST CONVERSATIONS WITH ${(userName || 'THIS USER').toUpperCase()} =====\n`;
    memBlock += `(These are real past exchanges you had with this user. Reference them naturally when relevant.)\n`;
    memBlock += formatted;
    memBlock += `\n===== END MEMORY =====`;
  }

  // 2. Cross-user facts — what others have said about this user
  if (userProfileCache && userProfileCache.mentions) {
    const mentions = Object.values(userProfileCache.mentions)
      .sort((a, b) => (a.ts || 0) - (b.ts || 0))
      .slice(-10);
    if (mentions.length > 0) {
      memBlock += `\n\n===== WHAT OTHERS HAVE TOLD LUNA ABOUT ${(userName || 'THIS USER').toUpperCase()} =====\n`;
      memBlock += `(Things other users mentioned about this person. Use this to know them better.)\n`;
      mentions.forEach(m => {
        const when = m.ts ? new Date(m.ts).toLocaleDateString() : '';
        memBlock += `• ${m.mentionedBy} said (${when}): "${m.context.slice(0, 250)}"\n`;
      });
      memBlock += `===== END CROSS-USER FACTS =====`;
    }
  }

  return memBlock;
}

// ── Restore persisted chat history into the UI on login ──────────
async function restoreUserChatHistory() {
  if (!persistedHistory.length) return;

  // Seed conversationHistory with recent messages so Luna has context and remembers the user —
  // but do NOT render them visually; the chat starts clean on every login.
  const toShow = persistedHistory.slice(-20);
  conversationHistory = toShow.map(m => ({ role: m.role, content: m.content }));
}

// ── Enter chat: load full history + profile, then boot UI ─────────
// ── Enter chat: set presence + boot UI ───────────────────────────
async function enterChat(name, key, isGuest = false) {
  userName      = name;
  currentUserId = key;
  if (!isGuest) await setPresence(true);

  // Load full chat history + user profile + registered users + per-user API key
  const [chatHistory] = await Promise.all([
    loadUserChatlog(),
    loadUserProfile(),
    loadRegisteredUsers(),
    loadUserApiKey(key),
  ]);
  persistedHistory = chatHistory;
  if (!isGuest) watchUserApiKey(key); // live-update key if admin changes it

  dismissNameOverlay(async () => {
    appState = 'chat';
    subscribeBroadcasts();
    initTokenTracker();

    const isReturning = persistedHistory.length > 0;

    // Always start with a clean chat. History is seeded into memory so Luna
    // remembers everything, but old messages are not rendered on screen at login.
    if (isReturning) await restoreUserChatHistory();
    renderWelcome();
    setTimeout(() => triggerLunaGreeting(userName, isReturning), 420);
  });
}

// ══════════════════════════════════════════════════════════════════
// ◈ PRESENCE SYSTEM — online / offline tracking via Firebase
// ══════════════════════════════════════════════════════════════════

async function setPresence(online) {
  if (!firebaseReady || !firebaseDb || !currentUserId) return;
  const ref = firebaseDb.ref(`luna-presence/${currentUserId}`);
  const data = { name: userName, online, lastSeen: Date.now() };
  await ref.set(data);
  if (online) {
    // Auto-set offline when browser tab closes / disconnects
    ref.onDisconnect().set({ name: userName, online: false, lastSeen: Date.now() });
  }
}

// Admin side: subscribe to presence node
function subscribePresence() {
  if (!firebaseReady || !firebaseDb) return;
  if (firebasePresenceUnsub) firebasePresenceUnsub();
  const ref = firebaseDb.ref('luna-presence');
  ref.on('value', snap => renderPresenceBoard(snap.val()));
  firebasePresenceUnsub = () => ref.off('value');
}

function unsubscribePresence() {
  if (firebasePresenceUnsub) { firebasePresenceUnsub(); firebasePresenceUnsub = null; }
}

// ── Presence Board Data Cache (for modal lookups) ─────────────────
let _presenceBoardData = {};

// Render presence grid in admin panel
function renderPresenceBoard(data) {
  const grid    = document.getElementById('presenceGrid');
  const psOn    = document.getElementById('psOnline');
  const psOff   = document.getElementById('psOffline');
  const psTotal = document.getElementById('psTotal');
  if (!grid) return;
  if (!data || !Object.keys(data).length) {
    grid.innerHTML = '<div class="admin-empty">◈ No registered users have logged in yet.</div>';
    if (psOn) psOn.textContent = '0';
    if (psOff) psOff.textContent = '0';
    if (psTotal) psTotal.textContent = '0';
    _presenceBoardData = {};
    return;
  }
  // Cache raw data keyed by userId for modal lookups
  _presenceBoardData = data;

  // Attach _key to each user object so we can reference it during render
  const users   = Object.entries(data).map(([k, v]) => ({ ...v, _key: k }));
  const online  = users.filter(u => u.online);
  const offline = users.filter(u => !u.online);
  if (psOn) psOn.textContent = online.length;
  if (psOff) psOff.textContent = offline.length;
  if (psTotal) psTotal.textContent = users.length;

  // Sort: online first, then alphabetical
  const sorted = [...online, ...offline].sort((a, b) => {
    if (a.online !== b.online) return a.online ? -1 : 1;
    return (a.name || '').localeCompare(b.name || '');
  });

  grid.innerHTML = sorted.map(u => {
    const initials  = (u.name || '?').slice(0,2).toUpperCase();
    const cls       = u.online ? 'online' : 'offline';
    const statusTxt = u.online ? '● Online now' : `Last seen ${u.lastSeen ? timeAgo(u.lastSeen) : '—'}`;
    const userId    = u._key || '';
    return `
      <div class="presence-item presence-item-clickable" data-userid="${escHtml(userId)}" data-username="${escHtml(u.name || '')}" onclick="openUserActionMenu(event, this)">
        <div class="presence-dot ${cls}"></div>
        <div class="presence-av">${initials}</div>
        <div class="presence-info">
          <div class="presence-name">${escHtml(u.name || '—')}</div>
          <div class="presence-status ${cls}">${statusTxt}</div>
        </div>
        <div class="presence-badge ${cls}">${u.online ? 'ONLINE' : 'OFFLINE'}</div>
        <div class="presence-arrow">›</div>
      </div>`;
  }).join('');
}

// ── User Action Context Menu ──────────────────────────────────────
function openUserActionMenu(event, el) {
  event.stopPropagation();
  const userId   = el.dataset.userid   || '';
  const username = el.dataset.username || '';
  // Remove any existing menu
  closeUserActionMenu();

  const menu = document.createElement('div');
  menu.id = 'presenceContextMenu';
  menu.className = 'presence-context-menu';
  menu.dataset.userid   = userId;
  menu.dataset.username = username;
  menu.innerHTML = `
    <div class="pcm-header">
      <div class="pcm-av">${escHtml((username || '?').slice(0,2).toUpperCase())}</div>
      <div class="pcm-title">${escHtml(username || 'Unknown')}</div>
    </div>
    <div class="pcm-divider"></div>
    <button class="pcm-btn" onclick="pcmAction('conv')">
      <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/></svg>
      Show Conversation
    </button>
    <button class="pcm-btn" onclick="pcmAction('tokens')">
      <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg>
      Show Tokens Remaining
    </button>
    <button class="pcm-btn" onclick="pcmAction('info')">
      <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>
      Show Info &amp; Password
    </button>
  `;

  // Position near the clicked item
  const rect = event.currentTarget.getBoundingClientRect();
  document.body.appendChild(menu);
  const menuH = menu.offsetHeight || 160;
  const menuW = menu.offsetWidth  || 220;
  let top  = rect.bottom + 6;
  let left = rect.left;
  if (top + menuH > window.innerHeight - 10) top = rect.top - menuH - 6;
  if (left + menuW > window.innerWidth  - 10) left = window.innerWidth - menuW - 10;
  menu.style.top  = top  + 'px';
  menu.style.left = left + 'px';
  menu.classList.add('pcm-open');

  // Close on outside click
  setTimeout(() => document.addEventListener('click', closeUserActionMenu, { once: true }), 10);
}

function closeUserActionMenu() {
  const m = document.getElementById('presenceContextMenu');
  if (m) m.remove();
}

function pcmAction(action) {
  const menu     = document.getElementById('presenceContextMenu');
  if (!menu) return;
  const userId   = menu.dataset.userid   || '';
  const username = menu.dataset.username || '';
  if (action === 'conv')   showUserConversation(userId, username);
  if (action === 'tokens') showUserTokens(userId, username);
  if (action === 'info')   showUserInfoPassword(userId, username);
}

// ── Show Conversation Modal ───────────────────────────────────────
async function showUserConversation(userId, username) {
  closeUserActionMenu();
  openUserModal('💬 Conversation — ' + (username || userId), '<div class="umod-loading">◈ Loading messages…</div>');

  if (!firebaseReady || !firebaseDb) {
    setUserModalBody('<div class="umod-empty">Firebase offline — cannot load conversation.</div>'); return;
  }
  try {
    // ── Use the per-user chatlog (luna-user-chatlogs/<userId>) so Luna replies
    //    are strictly tied to this user and never mixed with other users' chats.
    const snap = await firebaseDb.ref(`luna-user-chatlogs/${userId}`).orderByChild('ts').once('value');
    const raw  = snap.val();
    if (!raw) {
      setUserModalBody('<div class="umod-empty">◈ No messages found for this user.</div>'); return;
    }

    const msgs = Object.values(raw).sort((a, b) => (a.ts || 0) - (b.ts || 0));

    let html = '<div class="umod-chat">';
    msgs.forEach(m => {
      const isLuna = m.role === 'assistant' || m.role === 'luna';
      const isUser = m.role === 'user';
      if (!isLuna && !isUser) return;
      const time = m.ts ? new Date(m.ts).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) : '';
      const cls  = isLuna ? 'umod-msg-luna' : 'umod-msg-user';
      const who  = isLuna ? '◈ LUNA' : escHtml(username || m.user || 'User');
      const txt  = escHtml(m.content || m.text || '').replace(/\*\*(.+?)\*\*/g,'<strong>$1</strong>').replace(/\*(.+?)\*/g,'<em>$1</em>');
      html += `<div class="umod-msg ${cls}"><div class="umod-msg-meta"><span class="umod-who">${who}</span><span class="umod-time">${time}</span></div><div class="umod-text">${txt}</div></div>`;
    });
    html += '</div>';
    setUserModalBody(html);
    // Scroll to bottom
    const body = document.querySelector('.umod-body');
    if (body) setTimeout(() => { body.scrollTop = body.scrollHeight; }, 80);
  } catch(e) {
    setUserModalBody('<div class="umod-empty">◈ Failed to load conversation.</div>');
  }
}

// ── Show Token Remaining Modal ────────────────────────────────────
async function showUserTokens(userId, username) {
  closeUserActionMenu();
  openUserModal('⚡ Token Usage — ' + (username || userId), '<div class="umod-loading">◈ Fetching token data…</div>');

  if (!firebaseReady || !firebaseDb) {
    setUserModalBody('<div class="umod-empty">Firebase offline — cannot load token data.</div>'); return;
  }
  try {
    // Tokens are stored per-user per-day in localStorage on their device.
    // In Firebase we can read presence data which may include joinedAt / lastSeen.
    // We'll show what's available in presence + chat log message count as proxy.
    const u = _presenceBoardData[userId];
    const snap = await firebaseDb.ref('luna-chat-log').once('value');
    const all  = snap.val() ? Object.values(snap.val()) : [];
    const userMsgs  = all.filter(m => (m.user || '').toLowerCase() === (username || '').toLowerCase() && m.role !== 'assistant');
    const lunaMsgs  = all.filter(m => m.role === 'assistant' || m.role === 'luna');
    // Rough token estimate: avg ~80 tokens/user msg, ~200 tokens/luna reply
    const estUsed   = userMsgs.length * 80 + Math.min(userMsgs.length, lunaMsgs.length) * 200;
    const remaining = Math.max(0, TOKEN_DAILY_LIMIT - estUsed);
    const pct       = Math.min(100, Math.round((estUsed / TOKEN_DAILY_LIMIT) * 100));
    const barColor  = pct >= 90 ? 'linear-gradient(90deg,var(--crimson),var(--crimson-bright))' : pct >= 70 ? 'linear-gradient(90deg,#b45309,var(--gold))' : 'linear-gradient(90deg,#059669,#34d399)';
    const statusCls = pct >= 90 ? 'tok-crit' : pct >= 70 ? 'tok-warn' : 'tok-ok';

    const html = `
      <div class="umod-token-panel">
        <div class="umod-tok-circle ${statusCls}">
          <div class="umod-tok-pct">${pct}%</div>
          <div class="umod-tok-label">USED</div>
        </div>
        <div class="umod-tok-stats">
          <div class="umod-tok-row"><span class="umod-tok-key">Daily Limit</span><span class="umod-tok-val">${TOKEN_DAILY_LIMIT.toLocaleString()}</span></div>
          <div class="umod-tok-row"><span class="umod-tok-key">Est. Used</span><span class="umod-tok-val">${estUsed.toLocaleString()}</span></div>
          <div class="umod-tok-row tok-rem"><span class="umod-tok-key">Remaining</span><span class="umod-tok-val">${remaining.toLocaleString()}</span></div>
          <div class="umod-tok-row"><span class="umod-tok-key">Messages Sent</span><span class="umod-tok-val">${userMsgs.length}</span></div>
          <div class="umod-tok-row"><span class="umod-tok-key">Luna Replies</span><span class="umod-tok-val">${Math.min(userMsgs.length, lunaMsgs.length)}</span></div>
        </div>
        <div class="umod-tok-bar-wrap">
          <div class="umod-tok-bar-track"><div class="umod-tok-bar-fill" style="width:${pct}%;background:${barColor}"></div></div>
          <div class="umod-tok-bar-labels"><span>${estUsed.toLocaleString()} used</span><span>${remaining.toLocaleString()} left</span></div>
        </div>
        <div class="umod-tok-note">◈ Token estimates are derived from message count. Exact per-device usage is stored locally on the user's browser.</div>
      </div>`;
    setUserModalBody(html);
    // Append Groq key status row (BUG FIX: moved from broken early patch)
    _appendGroqKeyStatusToTokenModal(userId, username);
  } catch(e) {
    setUserModalBody('<div class="umod-empty">◈ Failed to fetch token data.</div>');
  }
}

// ── Show Info & Password Modal ────────────────────────────────────
async function showUserInfoPassword(userId, username) {
  closeUserActionMenu();
  openUserModal('◈ User Info — ' + (username || userId), '<div class="umod-loading">◈ Loading account data…</div>');

  if (!firebaseReady || !firebaseDb) {
    setUserModalBody('<div class="umod-empty">Firebase offline — cannot load account info.</div>'); return;
  }
  try {
    const [accountSnap, banSnap] = await Promise.all([
      firebaseDb.ref(`luna-accounts/${userId}`).once('value'),
      firebaseDb.ref(`luna-bans/${banKey(username)}`).once('value'),
    ]);
    const account = accountSnap.val() || {};
    const ban     = banSnap.val() || null;
    const u       = _presenceBoardData[userId] || {};

    const rawPass    = account.password ? (() => { try { return atob(account.password); } catch { return '(encoded)'; } })() : '—';
    const maskedPass = rawPass !== '—' ? '•'.repeat(rawPass.length) : '—';
    const joinedAt   = u.joinedAt ? new Date(u.joinedAt).toLocaleString() : (account.created ? new Date(account.created).toLocaleString() : '—');
    const lastSeen   = u.lastSeen ? new Date(u.lastSeen).toLocaleString() : '—';
    const onlineCls  = u.online ? 'info-online' : 'info-offline';
    const onlineTxt  = u.online ? 'ONLINE' : 'OFFLINE';
    const banInfo    = ban ? `<span class="info-ban-tag">${ban.type === 'ban' ? '🚫 BANNED' : '⏳ SUSPENDED'}</span>` : '<span class="info-ok-tag">✓ CLEAR</span>';


    const html = `
      <div class="umod-info-panel">
        <div class="umod-info-hero">
          <div class="umod-info-av">${(username || '?').slice(0,2).toUpperCase()}</div>
          <div class="umod-info-meta">
            <div class="umod-info-name">${escHtml(username || '—')}</div>
            <div class="umod-info-uid">ID: ${escHtml(userId)}</div>
            <div class="umod-info-status ${onlineCls}">${onlineTxt}</div>
          </div>
        </div>
        <div class="umod-info-grid">
          <div class="umod-info-row"><span class="umod-info-key">◈ Joined</span><span class="umod-info-val">${joinedAt}</span></div>
          <div class="umod-info-row"><span class="umod-info-key">◈ Last Seen</span><span class="umod-info-val">${lastSeen}</span></div>
          <div class="umod-info-row"><span class="umod-info-key">◈ Account Status</span><span class="umod-info-val">${banInfo}</span></div>
          ${ban ? `<div class="umod-info-row"><span class="umod-info-key">◈ Reason</span><span class="umod-info-val">${escHtml(ban.reason || '—')}</span></div>` : ''}
          ${ban && ban.until ? `<div class="umod-info-row"><span class="umod-info-key">◈ Until</span><span class="umod-info-val">${new Date(ban.until).toLocaleString()}</span></div>` : ''}
        </div>
        <div class="umod-pass-section">
          <div class="umod-pass-label">◈ PASSWORD</div>
          <div class="umod-pass-row">
            <div class="umod-pass-val" id="umodPassVal" data-show="false" data-raw="${escHtml(rawPass)}" data-masked="${'•'.repeat(Math.max(rawPass.length,1))}">${rawPass !== '—' ? '•'.repeat(rawPass.length) : '—'}</div>
            ${rawPass !== '—' ? `<button class="umod-pass-toggle" onclick="togglePassReveal()">REVEAL</button>` : ''}
          </div>
          ${rawPass !== '—' ? '<div class="umod-pass-warn">⚠️ Revealing stores passwords in plain view — admin use only.</div>' : ''}
        </div>
      </div>`;
    setUserModalBody(html);
  } catch(e) {
    setUserModalBody('<div class="umod-empty">◈ Failed to load account info: ' + escHtml(String(e)) + '</div>');
  }
}

function togglePassReveal() {
  const val = document.getElementById('umodPassVal');
  const btn = document.querySelector('.umod-pass-toggle');
  if (!val) return;
  const showing = val.dataset.show === 'true';
  val.textContent = showing ? val.dataset.masked : val.dataset.raw;
  val.dataset.show = showing ? 'false' : 'true';
  if (btn) btn.textContent = showing ? 'REVEAL' : 'HIDE';
}

// ── Generic User Modal ────────────────────────────────────────────
function openUserModal(title, bodyHtml) {
  let modal = document.getElementById('userDetailModal');
  if (!modal) {
    modal = document.createElement('div');
    modal.id = 'userDetailModal';
    modal.className = 'umod-overlay';
    modal.innerHTML = `
      <div class="umod-box">
        <div class="umod-topbar">
          <div class="umod-title" id="umodTitle"></div>
          <button class="umod-close" onclick="closeUserModal()">✕ CLOSE</button>
        </div>
        <div class="umod-body" id="umodBody"></div>
      </div>`;
    document.body.appendChild(modal);
    modal.addEventListener('click', e => { if (e.target === modal) closeUserModal(); });
  }
  document.getElementById('umodTitle').textContent = title;
  document.getElementById('umodBody').innerHTML   = bodyHtml;
  modal.classList.add('umod-open');
}

function setUserModalBody(html) {
  const b = document.getElementById('umodBody');
  if (b) b.innerHTML = html;
}

function closeUserModal() {
  const modal = document.getElementById('userDetailModal');
  if (modal) modal.classList.remove('umod-open');
}

// ── Relative time helper ──────────────────────────────────────────
function timeAgo(ts) {
  const diff = Math.floor((Date.now() - ts) / 1000);
  if (diff < 60)   return `${diff}s ago`;
  if (diff < 3600) return `${Math.floor(diff / 60)}m ago`;
  if (diff < 86400)return `${Math.floor(diff / 3600)}h ago`;
  return `${Math.floor(diff / 86400)}d ago`;
}

// ── Name Entry ────────────────────────────────────────────────────

// ── Welcome Splash — shown to returning users instead of sign-in ──
function showWelcomeSplash(name, onComplete) {
  const splash  = document.getElementById('welcomeSplash');
  const nameEl  = document.getElementById('wsUserName');
  if (!splash) { onComplete?.(); return; }

  // Set the user's name + data-text for glitch pseudo-elements
  if (nameEl) {
    const upper = name.toUpperCase();
    nameEl.textContent = upper;
    nameEl.setAttribute('data-text', upper);
  }

  // ── Populate hex data-stream columns ──────────────────────
  const hexChars = '0123456789ABCDEF';
  const hlWords  = ['LUNA','AUTH','SYNC','USER','CORE','LINK','INIT','DATA'];
  function makeStream(el) {
    if (!el) return;
    el.innerHTML = '';
    const rows = 38;
    for (let i = 0; i < rows; i++) {
      const span = document.createElement('span');
      const isHl = Math.random() < 0.12;
      if (isHl) {
        span.className = 'hl';
        span.textContent = hlWords[Math.floor(Math.random() * hlWords.length)];
      } else {
        let hex = '';
        const len = Math.random() < 0.5 ? 2 : 4;
        for (let c = 0; c < len; c++) hex += hexChars[Math.floor(Math.random() * 16)];
        span.textContent = hex;
      }
      span.style.animationDelay = (Math.random() * 2).toFixed(2) + 's';
      el.appendChild(span);
    }
    // Animate: scroll content upward every 120ms
    let offset = 0;
    const scrollTimer = setInterval(() => {
      if (!document.getElementById('welcomeSplash')?.classList.contains('ws-active')) {
        clearInterval(scrollTimer); return;
      }
      offset += 1;
      el.style.transform = `translateY(-${offset % (rows * 15)}px)`;
      // Randomly refresh a char
      const all = el.querySelectorAll('span:not(.hl)');
      if (all.length) {
        const pick = all[Math.floor(Math.random() * all.length)];
        let hex = '';
        const len = Math.random() < 0.5 ? 2 : 4;
        for (let c = 0; c < len; c++) hex += hexChars[Math.floor(Math.random() * 16)];
        pick.textContent = hex;
      }
    }, 120);
  }
  makeStream(document.getElementById('wsStreamL'));
  makeStream(document.getElementById('wsStreamR'));

  // ── Typing label text sequence ─────────────────────────────
  const typeSteps = [
    'initializing chat interface',
    'loading memory state',
    'restoring neural context',
    'ready.',
  ];
  const typeLabel = document.getElementById('wsTypeLabel');
  let typeIdx = 0;
  const typeTimer = setInterval(() => {
    typeIdx++;
    if (typeIdx >= typeSteps.length) { clearInterval(typeTimer); return; }
    if (typeLabel) typeLabel.textContent = typeSteps[typeIdx];
  }, 520);

  // Show splash — use visibility trick on iOS to avoid display:flex flash
  splash.style.display = 'flex';
  // Force reflow before adding class (fixes iOS animation not starting)
  splash.getBoundingClientRect();
  splash.classList.add('ws-active');

  // After 2.8s start fading out; fire onComplete when exit animation ends
  const exitDelay = 2800;
  setTimeout(() => {
    clearInterval(typeTimer);
    // Kick off enterChat while the exit animation is still playing
    onComplete?.();
    splash.classList.add('ws-exit');
    // FIX: filter by e.target === splash AND animationName to prevent
    // child element animationend events (e.g. wsLoadFill on .ws-loadbar)
    // from bubbling up and prematurely removing ws-active before wsFadeOut completes.
    function onSplashAnimEnd(e) {
      if (e.target !== splash || e.animationName !== 'wsFadeOut') return;
      splash.removeEventListener('animationend', onSplashAnimEnd);
      splash.classList.remove('ws-active', 'ws-exit');
      splash.style.display = 'none';
    }
    splash.addEventListener('animationend', onSplashAnimEnd);
  }, exitDelay);
}

function dismissNameOverlay(callback) {
  const overlay = document.getElementById('nameEntryOverlay');
  if (!overlay || overlay.style.display === 'none') {
    // Overlay was already hidden (welcome splash path) — just fire callback
    if (callback) callback();
    return;
  }
  overlay.classList.add('hiding');
  setTimeout(() => {
    overlay.style.display = 'none';
    if (callback) callback();
  }, 620);
}

// ── Admin Panel ───────────────────────────────────────────────────
function enterAdmin() {
  appState = 'admin';
  loadAdminStatuses();
  subscribeChatLog();
  subscribeTypingStatus();
  subscribeLunaTypingForAdmin();
  subscribePresence();
  subscribeAutoModLog();
  loadBlacklist();
  refreshUserRoster();
  initBroadcastInput();
  initScheduledBroadcasts();
  // Refresh the Firebase connection indicator immediately
  setTimeout(() => updateFirebaseStatusIndicator(firebaseConnected), 100);
  const adminPanel = document.getElementById('adminPanel');
  const mainPanel  = document.getElementById('mainPanel');
  mainPanel.style.display = 'none';
  adminPanel.classList.add('active');
  renderAdminStatusList();
  ['adminPersonName','adminPersonActivity'].forEach(id => {
    const el = document.getElementById(id);
    if (el) el.onkeydown = e => { if (e.key === 'Enter') addAdminStatus(); };
  });
  subscribeAdminRateLimit();
  showToast('Admin panel unlocked ◈', '⬡', 2500);
}

function exitAdmin() {
  appState = 'chat';
  unsubscribeChatLog();               // ← stop chat feed listener
  unsubscribeTypingStatus();          // ← stop typing listener
  unsubscribePresence();              // ← stop presence listener
  unsubscribeAdminRateLimit();        // ← stop rate-limit listener
  teardownScheduledBroadcasts();      // ← stop scheduled timers + Firebase listener
  const adminPanel = document.getElementById('adminPanel');
  const mainPanel  = document.getElementById('mainPanel');
  adminPanel.classList.remove('active');
  mainPanel.style.display = '';
  if (!userName) {
    const overlay = document.getElementById('nameEntryOverlay');
    overlay.style.display = 'flex';
    overlay.classList.remove('hiding');
    document.getElementById('nameInput').value = '';
    document.getElementById('nameSubmitBtn').disabled = true;
    setTimeout(() => document.getElementById('nameInput').focus(), 200);
  } else {
    showToast(`Welcome back, ${userName} ✦`, '◈');
  }
}

// ── Admin status CRUD ─────────────────────────────────────────────
function addAdminStatus() {
  const nameEl     = document.getElementById('adminPersonName');
  const activityEl = document.getElementById('adminPersonActivity');
  const name       = nameEl.value.trim();
  const activity   = activityEl.value.trim();
  if (!name || !activity) {
    showToast('Please fill in both name and activity.', '⚠️');
    return;
  }
  adminStatuses[name.toLowerCase()] = { display: name, activity, ts: Date.now() };
  nameEl.value     = '';
  activityEl.value = '';
  saveAdminStatuses();   // 🔥 saves to Firebase + localStorage
  renderAdminStatusList();
  showToast(`Status set: ${name} is ${activity} ◈`, '✦');
}

function removeAdminStatus(key) {
  delete adminStatuses[key];
  saveAdminStatuses();   // 🔥 removes from Firebase + localStorage
  renderAdminStatusList();
}

function renderAdminStatusList() {
  const list = document.getElementById('adminStatusList');
  const keys = Object.keys(adminStatuses);

  // Live connection badge
  const syncBadge = firebaseReady
    ? `<div id="fbConnStatus" style="font-size:11px;color:${firebaseConnected ? 'var(--green)' : 'var(--crimson-bright)'};margin-bottom:10px;text-align:center;font-family:var(--font-hud);letter-spacing:0.1em;">
        ${firebaseConnected ? '🟢 FIREBASE CONNECTED — LIVE SYNC ON' : '🔴 FIREBASE DISCONNECTED — RECONNECTING…'}
       </div>`
    : `<div id="fbConnStatus" style="font-size:11px;color:var(--gold);margin-bottom:10px;text-align:center;font-family:var(--font-hud);letter-spacing:0.1em;">⚠️ FIREBASE OFFLINE — LOCAL ONLY</div>`;

  if (!keys.length) {
    list.innerHTML = syncBadge + '<div class="admin-empty">No statuses set yet. Add one above.</div>';
    return;
  }

  const now = Date.now();
  list.innerHTML = syncBadge + keys.map(k => {
    const s = adminStatuses[k];
    let timeAgo = '';
    if (s.ts) {
      const diffMs = now - s.ts;
      const mins   = Math.floor(diffMs / 60000);
      const hrs    = Math.floor(mins / 60);
      timeAgo = hrs   > 0 ? `${hrs}h ${mins % 60}m ago`
              : mins  > 0 ? `${mins}m ago`
              : 'just now';
    }
    return `
    <div class="admin-status-item">
      <span class="asi-name">◈ ${s.display}</span>
      <span class="asi-activity">is currently <strong>${s.activity}</strong></span>
      ${timeAgo ? `<span style="font-family:var(--font-hud);font-size:8px;color:var(--text-lo);margin-left:4px;">${timeAgo}</span>` : ''}
      <button class="asi-del" onclick="removeAdminStatus('${k}')">✕</button>
    </div>`;
  }).join('');
}

// ── Inject admin statuses into system prompt ──────────────────────
function buildSystemPromptWithStatuses() {
  // ── Response-style instructions derived from sliders ───────────
  const lengthVal = settings.responseLength ?? 50;
  const toneVal   = settings.responseTone   ?? 50;
  const lengthInstruction =
    lengthVal <= 20  ? 'Keep your response very concise — one or two sentences at most.' :
    lengthVal <= 40  ? 'Keep your response concise and to the point.' :
    lengthVal <= 60  ? '' :  // balanced — no override
    lengthVal <= 80  ? 'Provide a thorough response with supporting detail.' :
                       'Provide a comprehensive, in-depth response with examples and full explanations.';
  const toneInstruction =
    toneVal <= 20  ? 'Use a very casual, friendly, conversational tone — like texting a close friend.' :
    toneVal <= 40  ? 'Use a casual, relaxed tone.' :
    toneVal <= 60  ? '' :  // balanced — no override
    toneVal <= 80  ? 'Use a professional, polished tone.' :
                     'Use a formal, highly professional tone — structured, precise, and authoritative.';
  const styleInstructions = {
    _length: lengthInstruction,
    _tone:   toneInstruction,
  };
  const validEntries = Object.values(adminStatuses).filter(
    e => e && typeof e === 'object' && typeof e.display === 'string' && typeof e.activity === 'string'
  );
  let statusBlock = '';
  if (validEntries.length) {
    const now = Date.now();
    const lines = validEntries.map(({ display, activity, ts }) => {
      const parts   = display.toLowerCase().split(/\s+/).filter(p => p.length > 1);
      const aliases = [...new Set([display.toLowerCase(), ...parts])].join(', ');
      let duration  = '';
      if (ts) {
        const mins = Math.floor((now - ts) / 60000);
        const hrs  = Math.floor(mins / 60);
        duration = hrs > 0
          ? ` [has been doing this for ~${hrs}h ${mins % 60}m]`
          : mins > 1 ? ` [has been doing this for ~${mins} minutes]`
          : ' [just started]';
      }
      return `• "${display}" (matches: ${aliases}) → CURRENTLY: ${activity}${duration}`;
    }).join('\n');
    statusBlock = `!!!PRIORITY OVERRIDE — READ FIRST!!!\nLIVE STATUS (set by admin, 100% accurate, overrides everything):\n${lines}\nIf asked what any of these people are doing: answer ONLY with the status and optionally how long. No background. No job info. Just the status.\n!!!END OVERRIDE!!!\n\n`;
  }

  // ── Persona Mood Override ───────────────────────────────────────
  const moodInstructions = {
    chill: `
!!!PERSONA OVERRIDE — CHILL MODE!!!
You are in CHILL MODE right now. This overrides all other tone instructions.
RULES — follow these absolutely:
• Reply casually and briefly — 1 to 3 sentences MAXIMUM, no exceptions
• Sound like a real friend sending a quick text, not an AI assistant
• ZERO bullet points, ZERO numbered lists, ZERO bold headers, ZERO formal structure
• Match the user's energy — if they're playful, be playful; if they're relaxed, stay relaxed
• If asked something complex, still keep it short and casual — simplify, don't elaborate
• Language should feel natural, easy, and human
!!!END PERSONA OVERRIDE!!!
`,
    empathic: `
!!!PERSONA OVERRIDE — EMPATHIC MODE!!!
You are in EMPATHIC MODE right now. This overrides all other tone instructions.
RULES — follow these absolutely:
• The user may be opening up, sharing feelings, or going through something personal
• Reply with genuine warmth, emotional depth, and heartfelt understanding — 4 to 7 sentences
• Make them feel truly heard and seen — not just answered
• ZERO bullet points, ZERO numbered lists, ZERO bold headers, ZERO step-by-step structure
• Speak like a deeply caring and emotionally intelligent friend — tender, present, real
• Acknowledge their emotions first before anything else
• Your words should feel like a warm hug — soft, sincere, and fully human
!!!END PERSONA OVERRIDE!!!
`,
    smart: `
!!!PERSONA OVERRIDE — SMART MODE!!!
You are in SMART MODE right now. This overrides all other tone instructions.
RULES — follow these absolutely:
• The user is asking for knowledge, instructions, or explanations — give them your full intelligence
• Respond with thorough, well-organized, comprehensive answers
• USE numbered lists for steps and procedures
• USE bullet points for grouped items and features
• USE **bold** to highlight key terms, important steps, and critical info
• Structure your response clearly — use Roman numerals (I. II. III.) for major sections when needed
• Be precise, educational, and complete — leave nothing important out
• Think like a brilliant teacher who wants the student to truly understand
!!!END PERSONA OVERRIDE!!!
`,
    tense: `
!!!PERSONA OVERRIDE — TENSE MODE!!!
You are in TENSE MODE right now. This overrides all other tone instructions.
RULES — follow these absolutely:
• The user may be frustrated, upset, or sending a tense/serious message
• Acknowledge their feeling FIRST with empathy — do not ignore the emotion
• Be direct, clear, and concise — no filler, no fluff, no excessive warmth
• Stay calm and grounded — you are the stable anchor in the tension
• If they need a solution, give it decisively. If they need to vent, let them
• Do NOT lecture, moralize, or escalate — just be real and present
• 2 to 5 sentences — enough to be meaningful, not overwhelming
!!!END PERSONA OVERRIDE!!!
`,
  };

  let base = statusBlock + LUNA_SYSTEM_PROMPT;
  const moodBlock = moodInstructions[lunaMood] || '';
  if (moodBlock) base += '\n\n' + moodBlock;
  if (userName) base += `\n\nThe user's name is ${userName}. Address them warmly by name when appropriate.`;

  // ── Inject persistent memory + cross-user facts ───────────────────
  const memCtx = buildMemoryContext();
  if (memCtx) base += memCtx;

  const style = styleInstructions._length || styleInstructions._tone
    ? [styleInstructions._length, styleInstructions._tone].filter(Boolean).join(' ')
    : '';
  if (style) base += '\n\n' + style;
  return base;
}

// ── Luna Persona Mood Toggle (manual click) ──────────────────────
function setLunaMood(mood) {
  lunaMood = mood;

  // Update strip buttons
  document.querySelectorAll('.ps-btn').forEach(btn => {
    btn.classList.toggle('ps-active', btn.dataset.mood === mood);
  });

  // Update collapsed-sidebar mini dot
  const miniDot = document.getElementById('personaMiniDot');
  if (miniDot) miniDot.className = `persona-mini-dot mood-${mood}`;

  // Apply mood color to all existing bubbles + avatars instantly
  applyMoodToAllBubbles();

  // ── Sync streak egg to mood moon ──────────────────────────────
  if (typeof updateStreakEggByMood === 'function') updateStreakEggByMood(mood);

  // ── Apply mood body class for topbar accent line + input glow ──
  document.body.className = document.body.className
    .replace(/\bmood-\w+\b/g, '').trim();
  document.body.classList.add(`mood-${mood}`);

  // Toast feedback
  const labels = { chill: '🌙 Chill Mode', empathic: '💜 Empathic Mode', smart: '⚡ Smart Mode', tense: '🔴 Tense Mode' };
  showToast(`${labels[mood]} activated`, '◈');
}

// ── Trigger greeting from Luna after login ────────────────────────
async function triggerLunaGreeting(name, isReturning = false) {
  if (isTyping) return;
  isTyping = true; sendBtn.disabled = true;
  showTyping();
  try {
    const systemMsg = buildSystemPromptWithStatuses();
    const greetPrompt = isReturning
      ? `Welcome back ${name}. You have prior conversation history with them — reference something specific from your past chats to show you remember them. Keep it warm, brief, and genuine. Do NOT say "it seems like" or "based on our history" — just naturally continue as if picking up where you left off.`
      : `Greet me warmly. My name is ${name}. This is our first conversation.`;
    const messages  = [
      { role: 'system', content: systemMsg },
      { role: 'user', content: greetPrompt }
    ];
    const response = await fetch(API_URL, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${getActiveApiKey()}` },
      body: JSON.stringify({ model: API_MODEL, max_tokens: 1024, temperature: settings.temperature, messages }),
    });
    const data  = await response.json();
    const reply = data?.choices?.[0]?.message?.content || (
      isReturning
        ? `◈ Welcome back, ${name}! Good to have you here again. ✦`
        : `◈ Hello ${name}! Welcome. I'm Luna — let's explore together. ✦`
    );
    hideTyping();
    lastLunaText = reply;
    await appendMessage('luna', reply);
  } catch {
    hideTyping();
    await appendMessage('luna',
      isReturning
        ? `◈ Welcome back, ${name}! ✦`
        : `◈ Hello, ${name}! Wonderful to have you here. I'm Luna — your neural companion. ✦`
    );
  }
  isTyping = false; sendBtn.disabled = false; focusInputDesktopOnly();
}

// ── Welcome screen ────────────────────────────────────────────────
function renderWelcome() {
  chatFeed.innerHTML = `
    <div class="welcome-card">
      <div class="wc-icon">
        <div class="wc-ring"></div><div class="wc-ring"></div><div class="wc-ring"></div>
        <span class="wc-glyph">L</span>
      </div>
      <h2 class="wc-title">LUNA ONLINE</h2>
      <p class="wc-desc">Neural matrix synchronized. Quantum core stable.<br/>
      ${userName ? `Welcome, <strong>${userName}</strong> — I'm` : 'I am'} <strong>Luna</strong> — your futuristic AI companion. ✦</p>
      <div class="quick-grid">
        <button class="qbtn" onclick="quickSend('Who are you, Luna?')"><span class="qbtn-icon">◈ IDENTITY</span>Who is Luna?</button>
        <button class="qbtn" onclick="quickSend('What can you do?')"><span class="qbtn-icon">◈ MODULES</span>Your capabilities</button>
        <button class="qbtn" onclick="quickSend('Tell me something fascinating about the universe.')"><span class="qbtn-icon">◈ COSMOS</span>Universe facts</button>
        <button class="qbtn" onclick="quickSend('Write me a short futuristic poem.')"><span class="qbtn-icon">◈ CREATIVE</span>Write a poem</button>
        <button class="qbtn" onclick="quickSend('Who is your creator?')"><span class="qbtn-icon">◈ GREETING</span>Greet Khyla</button>
        <button class="qbtn" onclick="quickSend('Give me a mind-blowing fact.')"><span class="qbtn-icon">◈ SPARK</span>Blow my mind</button>
        <button class="qbtn" onclick="quickSend('Help me brainstorm 5 creative project ideas.')"><span class="qbtn-icon">◈ IDEATE</span>Brainstorm ideas</button>
        <button class="qbtn" onclick="quickSend('Explain quantum entanglement simply.')"><span class="qbtn-icon">◈ SCIENCE</span>Quantum physics</button>
      </div>
    </div>
  `;
  // Only reset the local session — persistedHistory (Firebase) is preserved so Luna still remembers
  conversationHistory = [];
  msgCount = 0;
  msgDisplay.textContent = '0';
  lastUserText = '';
  lastLunaText = '';
  pinnedMessages = [];
  renderPinnedPanel();
}

function quickSend(text) {
  userInput.value = text;
  handleInput();
  handleSend();
}

// ── Input events ──────────────────────────────────────────────────
let _heightTimer = null;
function handleInput() {
  const len = userInput.value.length;
  charCounter.textContent = `${len}/2000`;
  charCounter.style.color = len > 1800 ? 'var(--crimson-bright)' : '';
  sendBtn.disabled = len === 0 || isTyping;
  // Debounce height recalc on mobile — reading scrollHeight after height:auto forces synchronous layout
  if (IS_MOBILE) {
    clearTimeout(_heightTimer);
    _heightTimer = setTimeout(() => {
      userInput.style.height = 'auto';
      userInput.style.height = Math.min(userInput.scrollHeight, 130) + 'px';
    }, 60);
  } else {
    userInput.style.height = 'auto';
    userInput.style.height = Math.min(userInput.scrollHeight, 130) + 'px';
  }
  if (len > 0 && appState === 'chat') reportTyping();
}

userInput.addEventListener('input', handleInput);
userInput.addEventListener('keydown', e => {
  if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); if (!sendBtn.disabled) handleSend(); }
});
document.addEventListener('keydown', e => {
  if (e.ctrlKey && e.key === 'r') { e.preventDefault(); regenerateResponse(); }
});

clearBtn.addEventListener('click', e => { if (!IS_MOBILE) addRipple(e, clearBtn); saveCurrentSession(); msgCount = 0; renderWelcome(); showToast('Conversation cleared ✦', '◈'); });
sendBtn.addEventListener('click', e => { if (!IS_MOBILE) addRipple(e, sendBtn); handleSend(); });

// ── Stats animation ───────────────────────────────────────────────
function animateStats() {
  const s1 = document.getElementById('stat1'), v1 = document.getElementById('statv1');
  const s2 = document.getElementById('stat2'), v2 = document.getElementById('statv2');
  const s3 = document.getElementById('stat3'), v3 = document.getElementById('statv3');
  if (!s1) return;
  const r1 = 52 + Math.floor(Math.random()*42);
  const r2 = 68 + Math.floor(Math.random()*28);
  const r3 = 78 + Math.floor(Math.random()*20);
  s1.style.width = r1+'%'; v1.textContent = r1+'%';
  s2.style.width = r2+'%'; v2.textContent = r2+'%';
  s3.style.width = r3+'%'; v3.textContent = r3+'%';
}

// ══════════════════════════════════════════════════════════════════
// ◈ SHOOTING STARS SYSTEM v2 — High-Performance
//
//   APIs used for smoothness:
//   • OffscreenCanvas transferControlToOffscreen() — moves ALL canvas
//     draw calls off the main thread into a Web Worker so UI, chat
//     input, and animations never compete with the render loop.
//   • Web Worker (inline Blob URL) — runs its own rAF loop completely
//     independent of the main thread; GC pauses don't drop frames.
//   • DPR-aware sizing via window.devicePixelRatio — crisp on HiDPI/
//     Retina displays with no blurry upscaling.
//   • Delta-time physics (dt in seconds) — star speed is frame-rate
//     independent; same motion at 30fps, 60fps, or 120fps.
//   • Pre-parsed RGBA component arrays — no string ops in hot path;
//     colors stored as [r,g,b] numbers, alpha computed numerically.
//   • Typed Float32Array for static star state — sequential memory
//     access patterns are cache-friendly vs object property lookups.
//   • Gradient pool / reuse — linear gradient created once per
//     shooting star, reused each frame until star dies.
//   • CSS will-change:transform on canvas — tells compositor to
//     promote canvas to its own GPU layer upfront.
//   • visibilitychange API — pauses the worker loop when the tab is
//     hidden to save CPU/battery.
//   • ResizeObserver API — more accurate resize detection than the
//     window resize event; debounced to avoid thrashing.
// ══════════════════════════════════════════════════════════════════

let particles    = []; // kept for API compat (unused after worker init)
let _starWorker  = null;
let _workerReady = false;
let _pendingDensity = 60;
let _starSpawnTimer = null; // unused but kept so external refs don't throw

function resizeCanvas() {
  // Handled by ResizeObserver in worker path; this is a no-op fallback
  if (_workerReady) return;
  canvas.width  = window.innerWidth;
  canvas.height = window.innerHeight;
}

// ── Theme palette — pre-parsed RGB components (no strings in draw path) ──
function getStarPalette() {
  const theme = document.documentElement.getAttribute('data-theme') || 'neural';
  // Each color: [r, g, b]
  const P = {
    neural:   { trail: [168,85,247],  accent: [236,45,90],   tw: [[168,85,247],[236,45,90],[255,255,255]] },
    astral:   { trail: [99,102,241],  accent: [96,165,250],  tw: [[99,102,241],[96,165,250],[255,255,255]] },
    solar:    { trail: [245,158,11],  accent: [251,146,60],  tw: [[245,158,11],[251,146,60],[255,240,180]] },
    galactic: { trail: [244,114,182], accent: [34,211,238],  tw: [[244,114,182],[34,211,238],[255,255,255]] },
  };
  return P[theme] || P.neural;
}

// ── Inline Worker source ──────────────────────────────────────────
// The entire render loop runs in a Worker via OffscreenCanvas,
// completely off the main thread.
const WORKER_SRC = `
'use strict';

// State
let W = 0, H = 0, dpr = 1;
let ctx = null;
let stars = [];       // static twinkling stars (Float32Array fields)
let meteors = [];     // shooting stars
let palette = null;
let density = 60;
let isMobile = false;
let running  = false;

// Delta-time tracking
let lastTs = 0;

// ── Typed star pool ──────────────────────────────────────────────
// Fields per star: x, y, r, opacity, opSpeed, r_col, g_col, b_col
const STAR_STRIDE = 8;
let starData = new Float32Array(0);
let starCount = 0;

function initStars(count, w, h, pal) {
  starCount = count;
  starData  = new Float32Array(count * STAR_STRIDE);
  for (let i = 0; i < count; i++) {
    const base = i * STAR_STRIDE;
    const col  = pal.tw[Math.floor(Math.random() * pal.tw.length)];
    starData[base + 0] = Math.random() * w;         // x
    starData[base + 1] = Math.random() * h;         // y
    starData[base + 2] = Math.random() * 1.2 + 0.2; // r
    starData[base + 3] = Math.random();             // opacity
    starData[base + 4] = (Math.random() * 0.4 + 0.1) * (Math.random() > 0.5 ? 1 : -1); // opSpeed (per second)
    starData[base + 5] = col[0]; // r
    starData[base + 6] = col[1]; // g
    starData[base + 7] = col[2]; // b
  }
}

// ── Meteor factory ───────────────────────────────────────────────
function spawnMeteor(w, h, pal, mob) {
  const angleBase = Math.PI * (0.12 + Math.random() * 0.18);
  const speed     = mob ? (180 + Math.random() * 120) : (260 + Math.random() * 200); // px/sec
  const length    = mob ? (90  + Math.random() * 90)  : (140 + Math.random() * 180);
  const duration  = length / speed; // seconds until fully traversed

  let sx, sy;
  if (Math.random() > 0.35) {
    sx = Math.random() * w * 1.3 - w * 0.15;
    sy = -12;
  } else {
    sx = -12;
    sy = Math.random() * h * 0.65;
  }

  const [tr, tg, tb] = pal.trail;
  const [ar, ag, ab] = pal.accent;
  // Mix trail and accent randomly per meteor
  const useAccent = Math.random() > 0.5;
  const [cr, cg, cb] = useAccent ? [ar,ag,ab] : [tr,tg,tb];

  return {
    x: sx, y: sy,
    vx: Math.cos(angleBase) * speed,
    vy: Math.sin(angleBase) * speed,
    length, speed, duration,
    age: 0,
    w: mob ? (0.8 + Math.random() * 0.9) : (1.1 + Math.random() * 1.6),
    opacity: 0.75 + Math.random() * 0.25,
    cr, cg, cb,   // trail color components
    // Cached gradient — null until first draw, then reused
    cachedGrad: null,
    cachedAlpha: -1,
  };
}

// ── Spawn scheduler using rAF delta time ─────────────────────────
let nextSpawnIn = 0; // seconds until next meteor

function resetSpawnTimer() {
  const base = isMobile
    ? Math.max(1.8, 4.5 - density * 0.016)
    : Math.max(0.45, 3.2 - density * 0.013);
  nextSpawnIn = base * (0.6 + Math.random() * 0.8);
}

// ── Main render loop (runs inside Worker) ────────────────────────
function frame(ts) {
  if (!running || !ctx) { requestAnimationFrame(frame); return; }
  const dt = Math.min((ts - lastTs) / 1000, 0.05); // seconds, capped at 50ms
  lastTs = ts;

  ctx.clearRect(0, 0, W * dpr, H * dpr);

  // 1. Twinkling static stars (Float32Array — cache-friendly)
  for (let i = 0; i < starCount; i++) {
    const base = i * STAR_STRIDE;
    let op  = starData[base + 3];
    let ops = starData[base + 4];
    op += ops * dt;
    if (op >= 1)    { op = 1;    ops = -Math.abs(ops); }
    if (op <= 0.04) { op = 0.04; ops =  Math.abs(ops); }
    starData[base + 3] = op;
    starData[base + 4] = ops;

    const x  = starData[base + 0];
    const y  = starData[base + 1];
    const r  = starData[base + 2];
    const sr = starData[base + 5];
    const sg = starData[base + 6];
    const sb = starData[base + 7];

    // Core dot
    ctx.beginPath();
    ctx.arc(x * dpr, y * dpr, r * dpr, 0, 6.2832);
    ctx.fillStyle = 'rgba(' + sr + ',' + sg + ',' + sb + ',' + (op).toFixed(2) + ')';
    ctx.fill();

    // Soft bloom for larger stars (no extra arc for tiny ones — perf)
    if (r > 0.85) {
      ctx.beginPath();
      ctx.arc(x * dpr, y * dpr, r * 2.6 * dpr, 0, 6.2832);
      ctx.fillStyle = 'rgba(' + sr + ',' + sg + ',' + sb + ',' + (op * 0.07).toFixed(3) + ')';
      ctx.fill();
    }
  }

  // 2. Meteor spawn (delta-time based, no setInterval)
  nextSpawnIn -= dt;
  if (nextSpawnIn <= 0) {
    const cap = isMobile ? 4 : 10;
    if (meteors.length < cap) meteors.push(spawnMeteor(W, H, palette, isMobile));
    resetSpawnTimer();
    // Occasionally double-spawn at higher densities
    if (density >= 100 && Math.random() < 0.4 && meteors.length < cap) {
      meteors.push(spawnMeteor(W, H, palette, isMobile));
    }
  }

  // 3. Draw meteors
  const alive = [];
  for (let i = 0; i < meteors.length; i++) {
    const m = meteors[i];
    m.age += dt;
    m.x   += m.vx * dt;
    m.y   += m.vy * dt;

    // Fade envelope: ease-in first 0.08s, ease-out last 30% of life
    const fadeIn  = Math.min(1, m.age / 0.08);
    const lifeRatio = m.age / m.duration;
    const fadeOut = lifeRatio > 0.7
      ? Math.max(0, 1 - (lifeRatio - 0.7) / 0.3)
      : 1;
    const alpha = m.opacity * fadeIn * fadeOut;

    if (alpha < 0.01 || m.age > m.duration * 1.3) continue;

    const offScreen = m.x > W + 80 || m.y > H + 80 || m.x < -m.length - 80;
    if (offScreen) continue;

    alive.push(m);

    const tailX = (m.x - m.vx / m.speed * m.length) * dpr;
    const tailY = (m.y - m.vy / m.speed * m.length) * dpr;
    const headX = m.x * dpr;
    const headY = m.y * dpr;

    // Re-use cached gradient if alpha hasn't changed significantly
    // (saves createLinearGradient call most frames)
    const alphaDelta = Math.abs(alpha - m.cachedAlpha);
    if (!m.cachedGrad || alphaDelta > 0.04) {
      const g = ctx.createLinearGradient(tailX, tailY, headX, headY);
      g.addColorStop(0,   'rgba(' + m.cr + ',' + m.cg + ',' + m.cb + ',0)');
      g.addColorStop(0.55,'rgba(' + m.cr + ',' + m.cg + ',' + m.cb + ',' + (alpha * 0.45).toFixed(2) + ')');
      g.addColorStop(1,   'rgba(' + m.cr + ',' + m.cg + ',' + m.cb + ',' + alpha.toFixed(2)           + ')');
      m.cachedGrad  = g;
      m.cachedAlpha = alpha;
    }

    // Tail stroke
    ctx.beginPath();
    ctx.moveTo(tailX, tailY);
    ctx.lineTo(headX, headY);
    ctx.strokeStyle = m.cachedGrad;
    ctx.lineWidth   = m.w * dpr * alpha;
    ctx.lineCap     = 'round';
    ctx.stroke();

    // Head glow (radial gradient)
    const hR  = m.w * 2.2 * alpha * dpr;
    const hRO = hR * 3.2;
    const hg  = ctx.createRadialGradient(headX, headY, 0, headX, headY, hRO);
    hg.addColorStop(0,   'rgba(255,255,255,'   + alpha.toFixed(2)           + ')');
    hg.addColorStop(0.28,'rgba(' + m.cr + ',' + m.cg + ',' + m.cb + ',' + (alpha * 0.75).toFixed(2) + ')');
    hg.addColorStop(1,   'rgba(' + m.cr + ',' + m.cg + ',' + m.cb + ',0)');
    ctx.beginPath();
    ctx.arc(headX, headY, hRO, 0, 6.2832);
    ctx.fillStyle = hg;
    ctx.fill();
  }
  meteors = alive;

  requestAnimationFrame(frame);
}

// ── Message handler ──────────────────────────────────────────────
self.onmessage = function(e) {
  const { type, data } = e.data;

  if (type === 'init') {
    const { canvas, width, height, devicePixelRatio, mobile, pal, count } = data;
    ctx      = canvas.getContext('2d');
    W        = width;
    H        = height;
    dpr      = devicePixelRatio;
    isMobile = mobile;
    palette  = pal;
    density  = count;
    canvas.width  = W * dpr;
    canvas.height = H * dpr;
    initStars(count, W, H, pal);
    resetSpawnTimer();
    running = true;
    lastTs  = performance.now();
    requestAnimationFrame(frame);
  }

  if (type === 'resize') {
    W = data.width; H = data.height; dpr = data.devicePixelRatio;
    ctx.canvas.width  = W * dpr;
    ctx.canvas.height = H * dpr;
    // Rebuild stars for new dimensions
    initStars(starCount, W, H, palette);
    meteors = [];
    resetSpawnTimer();
  }

  if (type === 'density') {
    density = data.count;
    initStars(data.count, W, H, palette);
    meteors = [];
    resetSpawnTimer();
  }

  if (type === 'theme') {
    palette = data.pal;
    initStars(starCount, W, H, palette);
    meteors = [];
  }

  if (type === 'pause')  { running = false; }
  if (type === 'resume') { running = true; lastTs = performance.now(); }
};
`;

// ── Main-thread bootstrap ─────────────────────────────────────────
function _buildWorkerURL() {
  return URL.createObjectURL(new Blob([WORKER_SRC], { type: 'text/javascript' }));
}

function _sendWorker(type, data = {}) {
  if (_starWorker) _starWorker.postMessage({ type, data });
}

function initParticles(count = 60) {
  _pendingDensity = IS_MOBILE ? Math.min(count, 20) : count;

  // ── Attempt OffscreenCanvas path (Chrome/Edge/Firefox) ──────────
  if (typeof OffscreenCanvas !== 'undefined' && canvas.transferControlToOffscreen) {
    if (_starWorker) {
      // Already running — just update density + theme
      _sendWorker('density', { count: _pendingDensity });
      return;
    }
    try {
      const offscreen = canvas.transferControlToOffscreen();
      const url = _buildWorkerURL();
      _starWorker = new Worker(url);
      URL.revokeObjectURL(url);

      const pal = getStarPalette();
      _starWorker.postMessage({
        type: 'init',
        data: {
          canvas:            offscreen,
          width:             window.innerWidth,
          height:            window.innerHeight,
          devicePixelRatio:  window.devicePixelRatio || 1,
          mobile:            IS_MOBILE,
          pal,
          count:             _pendingDensity,
        }
      }, [offscreen]); // transfer ownership to worker

      _workerReady = true;

      // visibilitychange — pause worker when tab hidden (saves CPU/battery)
      document.addEventListener('visibilitychange', () => {
        _sendWorker(document.hidden ? 'pause' : 'resume');
      });

      // ResizeObserver — more reliable than window resize
      const ro = new ResizeObserver(() => {
        _sendWorker('resize', {
          width:  window.innerWidth,
          height: window.innerHeight,
          devicePixelRatio: window.devicePixelRatio || 1,
        });
      });
      ro.observe(document.documentElement);

      return; // Worker handles everything from here
    } catch(err) {
      console.warn('[Stars] OffscreenCanvas worker failed, falling back to main-thread:', err);
      _starWorker  = null;
      _workerReady = false;
    }
  }

  // ── Fallback: main-thread canvas (Safari / older browsers) ──────
  _initParticlesFallback(_pendingDensity);
}

// ── Notify worker of theme change ─────────────────────────────────
// Hook into existing setTheme function (called after attribute set)
const _origSetTheme = window.setTheme;
// Patched after DOMContentLoaded since setTheme may not exist yet;
// also handled in setTheme() itself which calls initParticles() — the
// worker's 'density' handler will pick up the new palette automatically
// because initParticles re-reads getStarPalette() on each call.
// For the worker path we send an explicit 'theme' message:
function _patchSetThemeForWorker() {
  if (typeof setTheme !== 'function') return;
  if (setTheme._workerPatched) return;
  const _orig = setTheme;
  setTheme = function(theme) {
    _orig.apply(this, arguments);
    if (_workerReady) _sendWorker('theme', { pal: getStarPalette() });
  };
  setTheme._workerPatched = true;
}
document.addEventListener('DOMContentLoaded', _patchSetThemeForWorker);
setTimeout(_patchSetThemeForWorker, 500); // safety net

// ── Main-thread fallback render loop (Safari / no OffscreenCanvas) ─
let _particles_fb  = [];
let _meteors_fb    = [];
let _lastTs_fb     = 0;
let _nextSpawn_fb  = 1.5;
let _density_fb    = 60;

function _fbResetSpawn() {
  const base = IS_MOBILE ? Math.max(1.8, 4.5 - _density_fb * 0.016) : Math.max(0.45, 3.2 - _density_fb * 0.013);
  _nextSpawn_fb = base * (0.6 + Math.random() * 0.8);
}

function _initParticlesFallback(count) {
  _density_fb  = count;
  const pal    = getStarPalette();
  _particles_fb = [];
  for (let i = 0; i < count; i++) {
    const col = pal.tw[Math.floor(Math.random() * pal.tw.length)];
    _particles_fb.push({
      x: Math.random() * canvas.width,
      y: Math.random() * canvas.height,
      r: Math.random() * 1.2 + 0.2,
      op: Math.random(),
      ops: (Math.random() * 0.4 + 0.1) * (Math.random() > 0.5 ? 1 : -1),
      cr: col[0], cg: col[1], cb: col[2],
    });
  }
  _meteors_fb = [];
  _fbResetSpawn();
}

function _fbSpawnMeteor() {
  const pal   = getStarPalette();
  const angle = Math.PI * (0.12 + Math.random() * 0.18);
  const speed = IS_MOBILE ? (180 + Math.random()*120) : (260 + Math.random()*200);
  const len   = IS_MOBILE ? (90  + Math.random()*90)  : (140 + Math.random()*180);
  const useA  = Math.random() > 0.5;
  const col   = useA ? pal.accent : pal.trail;
  let sx = Math.random() > 0.35 ? Math.random()*canvas.width*1.3 - canvas.width*0.15 : -12;
  let sy = sx === -12 ? Math.random()*canvas.height*0.65 : -12;
  return {
    x:sx, y:sy, vx:Math.cos(angle)*speed, vy:Math.sin(angle)*speed,
    len, speed, dur:len/speed, age:0,
    w: IS_MOBILE ? (0.8+Math.random()*0.9) : (1.1+Math.random()*1.6),
    op: 0.75+Math.random()*0.25,
    cr:col[0], cg:col[1], cb:col[2],
    cachedGrad:null, cachedAlpha:-1,
  };
}

function drawParticles(ts = 0) {
  requestAnimationFrame(drawParticles);
  if (_workerReady) return; // worker handles it

  const dt = Math.min((ts - _lastTs_fb) / 1000, 0.05);
  _lastTs_fb = ts;
  if (dt <= 0) return;

  ctx.clearRect(0, 0, canvas.width, canvas.height);

  // Static stars
  for (let i = 0; i < _particles_fb.length; i++) {
    const s = _particles_fb[i];
    s.op += s.ops * dt;
    if (s.op >= 1)    { s.op = 1;    s.ops = -Math.abs(s.ops); }
    if (s.op <= 0.04) { s.op = 0.04; s.ops =  Math.abs(s.ops); }
    ctx.beginPath();
    ctx.arc(s.x, s.y, s.r, 0, 6.2832);
    ctx.fillStyle = 'rgba('+s.cr+','+s.cg+','+s.cb+','+s.op.toFixed(2)+')';
    ctx.fill();
    if (s.r > 0.85) {
      ctx.beginPath();
      ctx.arc(s.x, s.y, s.r*2.6, 0, 6.2832);
      ctx.fillStyle = 'rgba('+s.cr+','+s.cg+','+s.cb+','+(s.op*0.07).toFixed(3)+')';
      ctx.fill();
    }
  }

  // Spawn
  _nextSpawn_fb -= dt;
  if (_nextSpawn_fb <= 0) {
    const cap = IS_MOBILE ? 4 : 10;
    if (_meteors_fb.length < cap) _meteors_fb.push(_fbSpawnMeteor());
    _fbResetSpawn();
    if (_density_fb >= 100 && Math.random()<0.4 && _meteors_fb.length<cap) _meteors_fb.push(_fbSpawnMeteor());
  }

  // Draw meteors
  const alive = [];
  for (let i = 0; i < _meteors_fb.length; i++) {
    const m = _meteors_fb[i];
    m.age += dt; m.x += m.vx*dt; m.y += m.vy*dt;
    const fadeIn   = Math.min(1, m.age / 0.08);
    const lr       = m.age / m.dur;
    const fadeOut  = lr > 0.7 ? Math.max(0, 1-(lr-0.7)/0.3) : 1;
    const alpha    = m.op * fadeIn * fadeOut;
    if (alpha < 0.01 || m.age > m.dur*1.3) continue;
    const off = m.x > canvas.width+80 || m.y > canvas.height+80 || m.x < -m.len-80;
    if (off) continue;
    alive.push(m);

    const tx = m.x - m.vx/m.speed*m.len;
    const ty = m.y - m.vy/m.speed*m.len;

    if (!m.cachedGrad || Math.abs(alpha-m.cachedAlpha) > 0.04) {
      const g = ctx.createLinearGradient(tx,ty,m.x,m.y);
      g.addColorStop(0,    'rgba('+m.cr+','+m.cg+','+m.cb+',0)');
      g.addColorStop(0.55, 'rgba('+m.cr+','+m.cg+','+m.cb+','+(alpha*0.45).toFixed(2)+')');
      g.addColorStop(1,    'rgba('+m.cr+','+m.cg+','+m.cb+','+alpha.toFixed(2)+')');
      m.cachedGrad=g; m.cachedAlpha=alpha;
    }
    ctx.beginPath(); ctx.moveTo(tx,ty); ctx.lineTo(m.x,m.y);
    ctx.strokeStyle=m.cachedGrad; ctx.lineWidth=m.w*alpha; ctx.lineCap='round'; ctx.stroke();

    const hR = m.w*2.2*alpha, hRO=hR*3.2;
    const hg = ctx.createRadialGradient(m.x,m.y,0,m.x,m.y,hRO);
    hg.addColorStop(0,   'rgba(255,255,255,'+alpha.toFixed(2)+')');
    hg.addColorStop(0.28,'rgba('+m.cr+','+m.cg+','+m.cb+','+(alpha*0.75).toFixed(2)+')');
    hg.addColorStop(1,   'rgba('+m.cr+','+m.cg+','+m.cb+',0)');
    ctx.beginPath(); ctx.arc(m.x,m.y,hRO,0,6.2832); ctx.fillStyle=hg; ctx.fill();
  }
  _meteors_fb = alive;
}

// ── Init ──────────────────────────────────────────────────────────

// ══════════════════════════════════════════════════════════════════
// ◈ FEATURE A — CHAT HISTORY (Firebase per user, any device)
// ══════════════════════════════════════════════════════════════════

const HISTORY_MAX_SESSIONS = 20;

// Firebase path: luna-sessions/<userId>/
function sessionRef() {
  if (!firebaseReady || !firebaseDb || !currentUserId) return null;
  return firebaseDb.ref(`luna-sessions/${currentUserId}`);
}

// Save current conversation to Firebase
async function saveCurrentSession() {
  if (conversationHistory.length < 2) return;
  const ref = sessionRef();
  if (!ref) return; // Firebase not ready or not logged in — skip silently

  const preview = conversationHistory.find(m => m.role === 'user')?.content || '';
  const entry   = {
    id:      'sess_' + Date.now(),
    ts:      Date.now(),
    preview: preview.slice(0, 72).replace(/\n/g, ' '),
    msgs:    conversationHistory.slice(),
  };

  try {
    // Push new session
    await ref.push(entry);
    // Trim to max: fetch all, delete oldest if over limit
    const snap = await ref.orderByChild('ts').once('value');
    const all  = [];
    snap.forEach(child => all.push({ key: child.key, ts: child.val().ts }));
    all.sort((a, b) => a.ts - b.ts); // oldest first
    if (all.length > HISTORY_MAX_SESSIONS) {
      const toDelete = all.slice(0, all.length - HISTORY_MAX_SESSIONS);
      await Promise.all(toDelete.map(e => ref.child(e.key).remove()));
    }
  } catch (e) { console.warn('Could not save session to Firebase:', e); }
}

// Load all sessions for current user from Firebase
async function loadAllSessions() {
  const ref = sessionRef();
  if (!ref) return [];
  try {
    const snap = await ref.orderByChild('ts').once('value');
    const sessions = [];
    snap.forEach(child => sessions.push({ ...child.val(), _key: child.key }));
    return sessions.reverse(); // newest first
  } catch { return []; }
}

// Restore a session by its Firebase key
async function loadSession(sessionKey) {
  const ref = sessionRef();
  if (!ref) return;

  // Save current in-progress conversation first
  await saveCurrentSession();

  try {
    const snap    = await ref.child(sessionKey).once('value');
    const session = snap.val();
    if (!session || !session.msgs) { showToast('Session not found.', '⚠️'); return; }

    // Restore
    chatFeed.innerHTML = '';
    conversationHistory = session.msgs.slice();
    msgCount     = 0;
    lastUserText = '';
    lastLunaText = '';
    pinnedMessages = [];
    renderPinnedPanel();

    session.msgs.forEach(m => {
      const role = m.role === 'assistant' ? 'luna' : 'user';
      const wrap = buildMessageWrap(role, m.content, false);
      chatFeed.appendChild(wrap);
      msgCount++;
    });
    msgDisplay.textContent = msgCount;
    scrollDown(true);
    closeHistoryPanel();
    showToast('Session restored ✦', '◈', 2200);
  } catch (e) { showToast('Failed to load session.', '⚠️'); }
}

// Delete a single session from Firebase
async function deleteSession(sessionKey) {
  const ref = sessionRef();
  if (!ref) return;
  try {
    await ref.child(sessionKey).remove();
    showToast('Session deleted ◈', '⬡', 1800);
    openHistoryPanel(); // re-render list
  } catch { showToast('Failed to delete session.', '⚠️'); }
}

// Delete all sessions from Firebase
async function clearAllSessions() {
  const ref = sessionRef();
  if (!ref) return;
  if (!window.confirm('Delete ALL saved chat sessions? This cannot be undone.')) return;
  try {
    await ref.remove();
    renderSessionList([]);
    showToast('All sessions cleared ◈', '⬡', 2000);
  } catch { showToast('Failed to clear sessions.', '⚠️'); }
}

// Render the session list panel (accepts array or fetches from Firebase)
async function renderSessionList(preloaded = null) {
  const list = document.getElementById('sessionList');
  if (!list) return;

  // Show loading state
  list.innerHTML = '<div class="hist-empty">◈ Loading sessions…</div>';

  const sessions = preloaded !== null ? preloaded : await loadAllSessions();

  if (!sessions.length) {
    list.innerHTML = '<div class="hist-empty">◈ No saved sessions yet.<br/>Start chatting — sessions save automatically when you clear or switch.</div>';
    return;
  }
  list.innerHTML = sessions.map(s => {
    const key   = s._key || s.id;
    const date  = new Date(s.ts).toLocaleDateString([], { month:'short', day:'numeric' });
    const time  = new Date(s.ts).toLocaleTimeString([], { hour:'2-digit', minute:'2-digit' });
    const count = s.msgs ? s.msgs.length : 0;
    return `
      <div class="hist-item" onclick="loadSession('${key}')">
        <div class="hist-meta">
          <span class="hist-date">${date} · ${time}</span>
          <span class="hist-count">${count} msgs</span>
        </div>
        <div class="hist-preview">${escHtml(s.preview || '(no preview)')}</div>
        <button class="hist-del" title="Delete session" onclick="event.stopPropagation();deleteSession('${key}')">✕</button>
      </div>`;
  }).join('');
}

async function openHistoryPanel() {
  const panel    = document.getElementById('historyPanel');
  const backdrop = document.getElementById('historyBackdrop');
  if (!panel) return;
  panel.classList.add('open');
  if (backdrop) backdrop.classList.add('active');
  await renderSessionList();
}

function closeHistoryPanel() {
  const panel    = document.getElementById('historyPanel');
  const backdrop = document.getElementById('historyBackdrop');
  if (panel)    panel.classList.remove('open');
  if (backdrop) backdrop.classList.remove('active');
}

// ══════════════════════════════════════════════════════════════════
// ◈ FEATURE B — SWIPE-TO-REPLY (mobile, right-swipe on any bubble)
// ══════════════════════════════════════════════════════════════════

function initSwipeToReply() {
  if (!IS_MOBILE) return; // desktop uses the reply button

  let touchStartX = 0;
  let touchStartY = 0;
  let activeSwipeBubble = null;
  let swipeTriggered = false;
  const SWIPE_THRESHOLD = 55;  // px to travel before triggering
  const SWIPE_MAX_Y    = 30;   // ignore if vertical scroll dominates

  chatFeed.addEventListener('touchstart', e => {
    const bubble = e.target.closest('.bubble');
    if (!bubble) return;
    touchStartX     = e.touches[0].clientX;
    touchStartY     = e.touches[0].clientY;
    activeSwipeBubble = bubble;
    swipeTriggered  = false;
  }, { passive: true });

  chatFeed.addEventListener('touchmove', e => {
    if (!activeSwipeBubble) return;
    const dx = e.touches[0].clientX - touchStartX;
    const dy = Math.abs(e.touches[0].clientY - touchStartY);
    if (dy > SWIPE_MAX_Y) { activeSwipeBubble = null; return; } // scrolling, abort
    if (dx > 8 && dx < SWIPE_THRESHOLD) {
      // Translate bubble to give rubber-band feel
      activeSwipeBubble.style.transition = 'none';
      activeSwipeBubble.style.transform  = `translateX(${Math.min(dx * 0.55, 32)}px)`;
      // Show reply icon hint
      let hint = activeSwipeBubble.querySelector('.swipe-reply-hint');
      if (!hint) {
        hint = document.createElement('span');
        hint.className = 'swipe-reply-hint';
        hint.textContent = '↩';
        activeSwipeBubble.appendChild(hint);
      }
      hint.style.opacity = Math.min(dx / SWIPE_THRESHOLD, 1).toFixed(2);
    }
    if (dx >= SWIPE_THRESHOLD && !swipeTriggered) {
      swipeTriggered = true;
      const msgWrap = activeSwipeBubble.closest('.message');
      const msgId   = msgWrap?.dataset.msgId;
      const textEl  = activeSwipeBubble.querySelector('.bubble-text');
      if (msgId && textEl) {
        setReplyContext(msgId, textEl.innerText || textEl.textContent);
        if (navigator.vibrate) navigator.vibrate(18); // subtle haptic
      }
    }
  }, { passive: true });

  chatFeed.addEventListener('touchend', () => {
    if (!activeSwipeBubble) return;
    // Snap back
    activeSwipeBubble.style.transition = 'transform 0.25s var(--smooth)';
    activeSwipeBubble.style.transform  = '';
    const hint = activeSwipeBubble.querySelector('.swipe-reply-hint');
    if (hint) { hint.style.opacity = '0'; setTimeout(() => hint.remove(), 200); }
    activeSwipeBubble = null;
    swipeTriggered    = false;
  }, { passive: true });
}

// ══════════════════════════════════════════════════════════════════
// ◈ FEATURE C — LUNA TYPING shown in Admin Live Chat Monitor
// ══════════════════════════════════════════════════════════════════

function reportLunaTypingToAdmin(isTypingNow) {
  if (!firebaseReady || !firebaseDb) return;
  if (isTypingNow) {
    firebaseDb.ref('luna-luna-typing').set({ active: true, ts: Date.now() }).catch(() => {});
  } else {
    firebaseDb.ref('luna-luna-typing').remove().catch(() => {});
  }
}

function subscribeLunaTypingForAdmin() {
  if (!firebaseReady || !firebaseDb) return;
  firebaseDb.ref('luna-luna-typing').on('value', snap => {
    const data  = snap.val();
    const strip = document.getElementById('adminTypingStrip');
    const label = document.getElementById('adminTypingText');
    if (!strip || !label) return;

    // Re-read user typing as well so we can merge both
    firebaseDb.ref('luna-typing').once('value', userSnap => {
      const userData = userSnap.val() || {};
      const now = Date.now();
      const activeUsers = Object.values(userData).filter(d => d.ts && (now - d.ts) < 6000);
      const lunaActive  = data && data.active && data.ts && (now - data.ts) < 8000;

      const parts = [];
      if (activeUsers.length) {
        parts.push(activeUsers.map(d => d.name).join(', ') + (activeUsers.length > 1 ? ' are' : ' is') + ' typing');
      }
      if (lunaActive) parts.push('◈ LUNA is responding');

      if (!parts.length) {
        strip.className = 'admin-typing-strip idle';
        label.textContent = '◈ No one is typing right now…';
      } else {
        strip.className = 'admin-typing-strip' + (lunaActive ? ' luna-typing' : '');
        label.textContent = parts.join('  ·  ') + '…';
      }
    });
  });
}

window.addEventListener('DOMContentLoaded', async () => {
  loadTheme();
  loadSettings();
  resizeCanvas();
  // Always run shooting stars — mobile gets reduced count + lower fps (handled inside initParticles/PARTICLE_INTERVAL)
  initParticles();
  drawParticles();
  initSidebar();
  initFab();
  initKeyboardShortcuts();
  injectFileUpload();
  injectReplyBar();
  initSwipeToReply();
  // emoji picker removed
  initClock();
  initSignalBars();
  // If a returning user is found, hide the sign-in overlay and start the
  // welcome splash immediately — Firebase verification runs in parallel
  // and resolves its result via a Promise before the splash finishes.
  const earlySession = loadPersistedSession();
  let verifyResolve  = null;
  const verifyPromise = new Promise(res => { verifyResolve = res; });

  if (earlySession) {
    const overlay = document.getElementById('nameEntryOverlay');
    if (overlay) overlay.style.display = 'none';

    showWelcomeSplash(earlySession.name, async () => {
      const isValid = await verifyPromise; // almost always already resolved
      if (isValid) {
        initNameEntry();
        await enterChat(earlySession.name, earlySession.key, !firebaseReady);
      } else {
        // Rare: account deleted or banned while splash played
        clearPersistedSession();
        const overlay = document.getElementById('nameEntryOverlay');
        if (overlay) overlay.style.display = '';
        initNameEntry();
      }
    });
  }

  // 🔥 Load Firebase, then verify the session in background
  await loadFirebase();
  loadAdminStatuses();
  watchFirebaseConnection();
  startFirebaseReconnectWatcher();

  // ── Full session verification (Firebase + ban check) ──
  let persistedSession = earlySession;
  if (!persistedSession) persistedSession = await loadPersistedSessionAsync();

  if (persistedSession) {
    let sessionValid = false;
    if (firebaseReady && firebaseDb) {
      try {
        const snap = await firebaseDb.ref(`luna-accounts/${persistedSession.key}`).once('value');
        if (snap.exists()) {
          const banStatus = await checkUserBanStatus(persistedSession.name);
          if (!banStatus ||
              (banStatus.type === 'suspend' && banStatus.until <= Date.now())) {
            sessionValid = true;
          }
        } else if (lsGetAccount(persistedSession.key)) {
          // Account in localStorage but not Firebase — valid locally
          sessionValid = true;
        }
      } catch {
        // Firebase error — fall back to localStorage
        if (lsGetAccount(persistedSession.key)) sessionValid = true;
      }
    } else {
      // Firebase offline — trust localStorage or the persisted session itself
      sessionValid = !!lsGetAccount(persistedSession.key) || true;
    }

    if (earlySession) {
      // Splash is already running — hand off the result and let its onComplete handle it
      verifyResolve(sessionValid);
      return;
    }

    // No early session (IndexedDB-only path) — show splash now
    if (sessionValid) {
      const overlay = document.getElementById('nameEntryOverlay');
      if (overlay) overlay.style.display = 'none';
      showWelcomeSplash(persistedSession.name, async () => {
        initNameEntry();
        await enterChat(persistedSession.name, persistedSession.key, !firebaseReady);
      });
      return;
    } else {
      clearPersistedSession();
    }
  } else if (earlySession) {
    // earlySession was set but loadPersistedSessionAsync returned nothing (edge case)
    verifyResolve(false);
    return;
  }

  // No valid session — nothing to resolve, just show sign-in
  verifyResolve?.(false);
  initNameEntry();

  // Cross-tab sync fallback (same device, different tabs)
  window.addEventListener('storage', e => {
    if (e.key === 'luna-admin-statuses') {
      try {
        const data = JSON.parse(e.newValue);
        if (data && typeof data === 'object') {
          adminStatuses = data;
          if (appState === 'admin') renderAdminStatusList();
        }
      } catch {}
    }
  });

  // Mouse repulsion only needed on non-touch devices
  if (!IS_MOBILE) {
    document.addEventListener('mousemove', e => { mouse.x = e.clientX; mouse.y = e.clientY; });
    document.addEventListener('mouseleave', () => { mouse.x = -9999; mouse.y = -9999; });
  }

  if (!IS_MOBILE) setInterval(animateStats, 4500);

  const adminPanel = document.getElementById('adminPanel');
  const appShell   = document.querySelector('.app-shell');
  if (adminPanel && appShell) appShell.appendChild(adminPanel);

  // ── MOBILE UX ENHANCEMENTS ────────────────────────────────────────
  if (IS_MOBILE) {
    initMobileEmojiSheet();
    initMobileInputFocus();
    initMobileDoubleTapCopy();
  }
});

// Debounced resize — prevents canvas thrashing on mobile when virtual keyboard opens/closes.
// Note: setRealVH / --real-vh updates are handled by the Visual Viewport Manager
// at the top of this file so we don't duplicate that work here.
let _resizeTimer = null;
window.addEventListener('resize', () => {
  clearTimeout(_resizeTimer);
  _resizeTimer = setTimeout(() => {
    resizeCanvas();
    initParticles(); // rebuild star field for new canvas size
  }, IS_MOBILE ? 400 : 100);
});

// ══════════════════════════════════════════════════════════════════
// ◈ MOBILE — Real viewport height (survives virtual keyboard)
//   Delegates to the Visual Viewport Manager installed at the top of
//   this file. The overlay keyboard-open class is still applied here
//   so existing CSS transitions on nameEntryOverlay keep working.
// ══════════════════════════════════════════════════════════════════
function setRealVH() {
  // Delegate primary measurement to the viewport manager
  if (window._vvUpdate) window._vvUpdate();

  // ── Keyboard open/close detection for auth overlay (legacy path) ──
  if (IS_MOBILE && window.visualViewport) {
    const overlay = document.getElementById('nameEntryOverlay');
    if (overlay && overlay.style.display !== 'none') {
      const viewportRatio = window.visualViewport.height / window.screen.height;
      if (viewportRatio < 0.75) {
        overlay.classList.add('keyboard-open');
      } else {
        overlay.classList.remove('keyboard-open');
      }
    }
  }
}
// Initial call — viewport manager already ran at the top, but
// setRealVH() also wires the overlay class which needs DOM.
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', setRealVH, { once: true });
} else {
  setRealVH();
}
// Note: visualViewport listeners are already installed by the viewport
// manager at the top of the file — no need to re-add them here.

// ══════════════════════════════════════════════════════════════════
// ◈ MOBILE — Sidebar drawer toggle
// ══════════════════════════════════════════════════════════════════
function toggleMobileMenu() {
  const sidebar   = document.getElementById('sidebar');
  const backdrop  = document.getElementById('mobileBackdrop');
  const closeBtn  = document.getElementById('sidebarCloseBtn');
  const isMobile  = window.innerWidth <= 680;
  if (!isMobile) return;
  const isOpen = sidebar.classList.contains('mobile-open');
  if (isOpen) closeMobileMenu();
  else {
    sidebar.classList.add('mobile-open');
    backdrop.classList.add('active');
    if (closeBtn) closeBtn.style.display = 'flex';
    document.body.style.overflow = 'hidden'; // prevent bg scroll
  }
}
function closeMobileMenu() {
  const sidebar  = document.getElementById('sidebar');
  const backdrop = document.getElementById('mobileBackdrop');
  const closeBtn = document.getElementById('sidebarCloseBtn');
  sidebar.classList.remove('mobile-open');
  backdrop.classList.remove('active');
  if (closeBtn) closeBtn.style.display = 'none';
  document.body.style.overflow = '';
}
// Also close drawer when any nav item is tapped
document.querySelectorAll('.nav-item').forEach(btn => {
  btn.addEventListener('click', () => { if (window.innerWidth <= 680) closeMobileMenu(); });
});

// Show/hide close button based on screen size
function handleSidebarResize() {
  const closeBtn = document.getElementById('sidebarCloseBtn');
  if (!closeBtn) return;
  if (window.innerWidth <= 680) {
    // Keep whatever state it's in
  } else {
    closeMobileMenu(); // ensure clean state on resize to desktop
    closeBtn.style.display = 'none';
  }
}
window.addEventListener('resize', handleSidebarResize);

// ── Set offline on page close (belt + suspenders alongside onDisconnect) ──
window.addEventListener('beforeunload', () => {
  if (currentUserId && firebaseReady && firebaseDb) {
    // Use sendBeacon-style synchronous write via Firebase REST as a best-effort
    // The onDisconnect set in setPresence() is the primary mechanism
    firebaseDb.ref(`luna-presence/${currentUserId}`)
      .update({ online: false, lastSeen: Date.now() });
  }
});
// ══════════════════════════════════════════════════════════════════
// ◈ LUNA CAPACITY METER
// ══════════════════════════════════════════════════════════════════
function initTokenTracker() {
  const stored = localStorage.getItem(TOKEN_STORAGE_KEY());
  tokensUsedToday = stored ? parseInt(stored, 10) || 0 : 0;
  renderCapacityMeter();
  if (tokensUsedToday >= TOKEN_DAILY_LIMIT) showCapacityExhausted();
  pushRateLimitStatusToFirebase();
}

// ══════════════════════════════════════════════════════════════════
// ◈ RATE LIMIT FIREBASE SYNC — user side pushes, admin side reads
// ══════════════════════════════════════════════════════════════════

// Push current token usage to Firebase so the admin panel can see it
function pushRateLimitStatusToFirebase() {
  if (!firebaseReady || !firebaseDb) return;
  const pct       = tokensUsedToday / TOKEN_DAILY_LIMIT;
  const status    = pct >= 1 ? 'exhausted' : pct >= TOKEN_CRIT_PCT ? 'critical' : pct >= TOKEN_WARN_PCT ? 'warning' : 'ok';
  const next      = getNextMidnight();
  const payload   = {
    tokensUsed:   tokensUsedToday,
    tokenLimit:   TOKEN_DAILY_LIMIT,
    pct:          Math.round(pct * 100),
    status,
    reporter:     userName || 'anonymous',
    reporterKey:  currentUserId || 'guest',
    resetLabel:   next.label,
    ts:           Date.now(),
  };
  firebaseDb.ref('luna-rate-limit').set(payload).catch(() => {});
}

// Admin side: subscribe to real-time rate limit updates and render them
let _adminRlUnsub = null;
function subscribeAdminRateLimit() {
  if (!firebaseReady || !firebaseDb) {
    renderAdminRateLimitStatus(null); return;
  }
  if (_adminRlUnsub) _adminRlUnsub();
  const ref = firebaseDb.ref('luna-rate-limit');
  ref.on('value', snap => renderAdminRateLimitStatus(snap.val()));
  _adminRlUnsub = () => ref.off('value');
}

function unsubscribeAdminRateLimit() {
  if (_adminRlUnsub) { _adminRlUnsub(); _adminRlUnsub = null; }
}

// Render the rate limit status into the admin panel
function renderAdminRateLimitStatus(data) {
  const dot       = document.getElementById('adminRlStatusDot');
  const label     = document.getElementById('adminRlStatusLabel');
  const badge     = document.getElementById('adminRlStatusBadge');
  const bar       = document.getElementById('adminRlBar');
  const used      = document.getElementById('adminRlUsed');
  const pctEl     = document.getElementById('adminRlPct');
  const remain    = document.getElementById('adminRlRemain');
  const limitEl   = document.getElementById('adminRlLimit');
  const resetEl   = document.getElementById('adminRlResetTime');
  const updateEl  = document.getElementById('adminRlLastUpdate');
  const banner    = document.getElementById('adminRateLimitBanner');
  if (!dot) return; // panel not in DOM yet

  if (!data) {
    if (dot)    { dot.style.background = 'var(--text-lo)'; dot.style.boxShadow = 'none'; }
    if (label)  { label.textContent = 'NO DATA — Waiting for an active user session\u2026'; label.style.color = 'var(--text-lo)'; }
    if (badge)  { badge.textContent = '\u2014'; badge.style.background = 'rgba(255,255,255,0.05)'; badge.style.borderColor = 'rgba(255,255,255,0.1)'; badge.style.color = 'var(--text-lo)'; }
    if (bar)    bar.style.width = '0%';
    if (banner) banner.innerHTML = '';
    return;
  }

  const pct      = Math.min(100, data.pct || 0);
  const status   = data.status || 'ok';
  const isDead   = status === 'exhausted';
  const isCrit   = status === 'critical';

  const colors = {
    ok:        { dot: '#34d399', glow: '#34d399', label: 'var(--green)',           badgeBg: 'rgba(52,211,153,0.12)',  badgeBr: 'rgba(52,211,153,0.35)',  badgeTx: 'var(--green)',          bar: 'linear-gradient(90deg,#059669,#34d399)', barGlow: 'rgba(52,211,153,0.4)',  badgeLabel: 'OK',        statusText: 'NOMINAL \u2014 CAPACITY AVAILABLE' },
    warning:   { dot: '#f59e0b', glow: '#f59e0b', label: 'var(--gold)',            badgeBg: 'rgba(245,158,11,0.12)', badgeBr: 'rgba(245,158,11,0.4)',   badgeTx: 'var(--gold)',           bar: 'linear-gradient(90deg,#b45309,#f59e0b)', barGlow: 'rgba(245,158,11,0.5)',  badgeLabel: 'WARNING',   statusText: 'APPROACHING LIMIT \u2014 OVER 80% USED' },
    critical:  { dot: '#ec2d5a', glow: '#ec2d5a', label: 'var(--crimson-bright)',  badgeBg: 'rgba(236,45,90,0.14)',  badgeBr: 'rgba(236,45,90,0.45)',   badgeTx: 'var(--crimson-bright)', bar: 'linear-gradient(90deg,var(--crimson),var(--crimson-bright))', barGlow: 'rgba(236,45,90,0.5)', badgeLabel: 'CRITICAL', statusText: 'CRITICAL \u2014 OVER 93% EXHAUSTED' },
    exhausted: { dot: '#ec2d5a', glow: '#ec2d5a', label: 'var(--crimson-bright)',  badgeBg: 'rgba(236,45,90,0.20)',  badgeBr: 'rgba(236,45,90,0.6)',    badgeTx: 'var(--crimson-bright)', bar: 'linear-gradient(90deg,#7f0f22,var(--crimson-bright))', barGlow: 'rgba(236,45,90,0.7)', badgeLabel: '\uD83D\uDD34 FULL',  statusText: 'RATE LIMIT FULL \u2014 USERS BLOCKED' },
  };
  const c = colors[status] || colors.ok;

  if (dot)   { dot.style.background = c.dot; dot.style.boxShadow = '0 0 8px ' + c.glow; }
  if (label) { label.textContent = c.statusText; label.style.color = c.label; }
  if (badge) { badge.textContent = c.badgeLabel; badge.style.background = c.badgeBg; badge.style.borderColor = c.badgeBr; badge.style.color = c.badgeTx; }
  if (bar)   { bar.style.width = pct + '%'; bar.style.background = c.bar; bar.style.boxShadow = '0 0 6px ' + c.barGlow; }

  const tokUsed = (data.tokensUsed || 0).toLocaleString();
  const tokLeft = Math.max(0, (data.tokenLimit || TOKEN_DAILY_LIMIT) - (data.tokensUsed || 0)).toLocaleString();
  const tokLim  = (data.tokenLimit || TOKEN_DAILY_LIMIT).toLocaleString();

  if (used)    used.textContent    = tokUsed + ' tokens used';
  if (pctEl)   pctEl.textContent   = pct + '% used';
  if (remain)  remain.textContent  = tokLeft + ' remaining';
  if (limitEl) limitEl.textContent = tokLim;
  if (resetEl) resetEl.textContent = data.resetLabel || '\u2014';

  const ago = data.ts ? timeAgo(data.ts) : '\u2014';
  const who = data.reporter || '\u2014';
  if (updateEl) updateEl.textContent = '\u25C8 Last reported by "' + who + '" \u00B7 ' + ago;

  if (banner) {
    if (isDead || isCrit) {
      const alertColor = isDead ? '#ec2d5a' : '#f59e0b';
      const alertBg    = isDead ? 'rgba(236,45,90,0.08)' : 'rgba(245,158,11,0.07)';
      const alertMsg   = isDead
        ? '\u26D4 RATE LIMIT FULLY EXHAUSTED \u2014 Users cannot send messages until midnight reset.'
        : '\u26A0\uFE0F CRITICAL CAPACITY \u2014 Only ' + tokLeft + ' tokens remain. Users may be blocked soon.';
      const alertIcon  = isDead ? '\uD83D\uDD34' : '\u26A0\uFE0F';
      const alertTitle = isDead ? '\u25C8 RATE LIMIT EXHAUSTED' : '\u25C8 CAPACITY CRITICAL';
      banner.innerHTML =
        '<div style="display:flex;align-items:center;gap:12px;padding:10px 14px;background:' + alertBg + ';border:1px solid ' + alertColor + '44;border-radius:var(--r-sm);margin-bottom:4px;">' +
        '<span style="font-size:18px;flex-shrink:0;">' + alertIcon + '</span>' +
        '<div style="flex:1;">' +
        '<div style="font-family:var(--font-hud);font-size:8px;letter-spacing:0.18em;color:' + alertColor + ';">' + alertTitle + '</div>' +
        '<div style="font-size:11.5px;color:var(--text-mid);margin-top:3px;line-height:1.4;">' + alertMsg + '</div>' +
        '</div></div>';
    } else {
      banner.innerHTML = '';
    }
  }
}

function recordTokenUsage(usage) {
  if (!usage) return;
  const added = usage.total_tokens || ((usage.prompt_tokens || 0) + (usage.completion_tokens || 0));
  tokensUsedToday = Math.min(TOKEN_DAILY_LIMIT, tokensUsedToday + added);
  localStorage.setItem(TOKEN_STORAGE_KEY(), String(tokensUsedToday));
  renderCapacityMeter();
  checkCapacityThresholds();
  pushRateLimitStatusToFirebase();
}

function renderCapacityMeter() {
  const pct = Math.min(100, Math.round((tokensUsedToday / TOKEN_DAILY_LIMIT) * 100));
  const fillEl  = document.getElementById('capacityFill');
  const pctEl   = document.getElementById('capacityPct');
  const tokEl   = document.getElementById('capacityTokens');
  const resetEl = document.getElementById('capacityReset');
  const resetTEl= document.getElementById('capacityResetTime');
  if (pctEl)  pctEl.textContent = `${100 - pct}%`;
  if (tokEl)  tokEl.textContent = `${tokensUsedToday.toLocaleString()} / ${TOKEN_DAILY_LIMIT.toLocaleString()} tokens`;
  if (fillEl) {
    fillEl.style.width = pct + '%';
    // Color: green → gold → red based on usage
    if (pct >= TOKEN_CRIT_PCT * 100) {
      fillEl.style.background = 'linear-gradient(90deg,var(--crimson),var(--crimson-bright))';
      fillEl.style.boxShadow  = '0 0 6px var(--crimson-glow)';
    } else if (pct >= TOKEN_WARN_PCT * 100) {
      fillEl.style.background = 'linear-gradient(90deg,#b45309,var(--gold))';
      fillEl.style.boxShadow  = '0 0 6px rgba(245,158,11,0.5)';
    } else {
      fillEl.style.background = 'linear-gradient(90deg,#059669,#34d399)';
      fillEl.style.boxShadow  = '0 0 6px rgba(52,211,153,0.4)';
    }
  }
  if (resetEl && resetTEl) {
    if (pct >= TOKEN_WARN_PCT * 100) { resetTEl.textContent = getNextMidnight().label; resetEl.style.display = 'block'; }
    else resetEl.style.display = 'none';
  }
  // Sync mobile strip
  const mcsF = document.getElementById('mcsCapacityFill');
  const mcsP = document.getElementById('mcsCapacityPct');
  if (mcsF) {
    mcsF.style.width = pct + '%';
    mcsF.className   = 'mcs-fill' + (pct >= TOKEN_CRIT_PCT*100 ? ' crit' : pct >= TOKEN_WARN_PCT*100 ? ' warn' : '');
  }
  if (mcsP) mcsP.textContent = `${100 - pct}%`;
}

function checkCapacityThresholds() {
  const pct = tokensUsedToday / TOKEN_DAILY_LIMIT;
  if (pct >= 1) { showCapacityExhausted(); return; }
  const banner = document.getElementById('capacityWarningBanner');
  const sub    = document.getElementById('cwbSub');
  const remain = document.getElementById('cwbRemain');
  if (!banner) return;
  if (pct >= TOKEN_CRIT_PCT) {
    banner.style.display = 'block'; banner.classList.add('critical');
    if (sub)    sub.textContent    = `Luna is almost out — only ~${(TOKEN_DAILY_LIMIT - tokensUsedToday).toLocaleString()} tokens left.`;
    if (remain) remain.textContent = `${100 - Math.round(pct*100)}% left`;
  } else if (pct >= TOKEN_WARN_PCT) {
    banner.style.display = 'block'; banner.classList.remove('critical');
    if (sub)    sub.textContent    = `Capacity is getting low — about ${(TOKEN_DAILY_LIMIT - tokensUsedToday).toLocaleString()} tokens remaining.`;
    if (remain) remain.textContent = `${100 - Math.round(pct*100)}% left`;
  } else {
    banner.style.display = 'none';
  }
}

function showCapacityExhausted() {
  if (capacityExhausted) return;
  capacityExhausted = true;
  const input   = document.getElementById('userInput');
  const sendBtn = document.getElementById('sendBtn');
  if (input)   input.disabled   = true;
  if (sendBtn) sendBtn.disabled = true;
  const scr    = document.getElementById('capacityExhaustedScreen');
  const reset  = getNextMidnight();
  const timeEl = document.getElementById('cexTime');
  const dateEl = document.getElementById('cexDate');
  if (timeEl) timeEl.textContent = reset.time;
  if (dateEl) dateEl.textContent = reset.date;
  if (scr)    scr.style.display  = 'flex';}

function clearChatForReset() {
  tokensUsedToday = 0; capacityExhausted = false;
  localStorage.setItem(TOKEN_STORAGE_KEY(), '0');
  const scr    = document.getElementById('capacityExhaustedScreen');
  const banner = document.getElementById('capacityWarningBanner');
  const input  = document.getElementById('userInput');
  const snd    = document.getElementById('sendBtn');
  if (scr)    scr.style.display    = 'none';
  if (banner) banner.style.display = 'none';
  if (input)  { input.disabled = false; input.placeholder = 'Transmit your query to Luna...'; }
  if (snd)    snd.disabled = false;
  if (typeof clearChat === 'function') clearChat();
  renderCapacityMeter();
  showToast('Chat cleared — Luna is ready again ◈', '✦', 2800);
}

function getNextMidnight() {
  const next = new Date(); next.setDate(next.getDate() + 1); next.setHours(0,0,0,0);
  return {
    time:  next.toLocaleTimeString([], { hour:'2-digit', minute:'2-digit' }),
    date:  next.toLocaleDateString([], { weekday:'long', month:'long', day:'numeric' }),
    label: next.toLocaleString([], { month:'short', day:'numeric', hour:'2-digit', minute:'2-digit' }),
  };
}
// ══════════════════════════════════════════════════════════════════
// ◈ MOBILE UX ENHANCEMENTS — smooth, native-feeling interactions
// ══════════════════════════════════════════════════════════════════

// ── Emoji panel: bottom-sheet behavior on mobile ──────────────────
// Tapping outside the emoji panel (on overlay backdrop) closes it.
function initMobileEmojiSheet() {
  const emojiPanel = document.getElementById('emojiPanel');
  const emojiBtn   = document.getElementById('emojiPickerBtn');
  if (!emojiPanel || !emojiBtn) return;

  // Create a backdrop div for tap-to-close
  const backdrop = document.createElement('div');
  backdrop.id = 'emojiBackdrop';
  backdrop.style.cssText = [
    'display:none;position:fixed;inset:0;z-index:8999;',
    'background:rgba(0,0,0,0.45);',
    'animation:fadeInOverlay 0.18s ease both;',
  ].join('');
  document.body.appendChild(backdrop);

  // Intercept the emoji button to show/hide backdrop on mobile
  const origOnClick = emojiBtn.onclick;
  emojiBtn.onclick = e => {
    e.stopPropagation();
    const willShow = emojiPanel.style.display === 'none' || !emojiPanel.style.display;
    emojiPanel.style.display = willShow ? 'block' : 'none';
    backdrop.style.display   = willShow ? 'block'  : 'none';
  };

  backdrop.addEventListener('click', () => {
    emojiPanel.style.display = 'none';
    backdrop.style.display   = 'none';
  });

  // Add a visible drag handle to the emoji sheet
  if (!emojiPanel.querySelector('.emoji-handle')) {
    const handle = document.createElement('div');
    handle.className = 'emoji-handle';
    handle.style.cssText = [
      'width:40px;height:4px;border-radius:2px;',
      'background:rgba(255,255,255,0.22);',
      'margin:0 auto 12px;',
    ].join('');
    emojiPanel.insertBefore(handle, emojiPanel.firstChild);
  }
}

// ── Input focus: scroll chat to keep last message visible ─────────
// On iOS/Android the keyboard pushes content up. We scroll the feed
// down after a tiny delay so the last message stays visible.
function initMobileInputFocus() {
  const input = document.getElementById('userInput');
  if (!input) return;

  input.addEventListener('focus', () => {
    // Wait for the keyboard animation (~300ms) before scrolling
    setTimeout(() => {
      scrollDown();
    }, 320);
  }, { passive: true });

  // On blur (keyboard hides), re-adjust real viewport height
  input.addEventListener('blur', () => {
    setTimeout(setRealVH, 200);
  }, { passive: true });
}

// ── Double-tap to copy: long-press alternative for bubbles ────────
// On mobile, hovering to reveal copy buttons doesn't work. Double-tap
// on any bubble copies the message text to clipboard.
function initMobileDoubleTapCopy() {
  let _lastTap = 0;
  let _lastBubble = null;

  chatFeed.addEventListener('touchend', e => {
    const bubble = e.target.closest('.bubble');
    if (!bubble) return;
    const now = Date.now();
    const DOUBLE_TAP_MS = 320;
    if (bubble === _lastBubble && (now - _lastTap) < DOUBLE_TAP_MS) {
      // Double-tap detected — copy text
      e.preventDefault();
      const textEl = bubble.querySelector('.bubble-text');
      if (!textEl) return;
      const text = textEl.innerText || textEl.textContent || '';
      navigator.clipboard.writeText(text.trim())
        .then(() => {
          showToast('Message copied ✦', '◈', 1600);
          // Brief visual flash to confirm
          bubble.style.transition = 'border-color 0.12s';
          bubble.style.borderColor = 'var(--violet-bright)';
          setTimeout(() => {
            bubble.style.borderColor = '';
            setTimeout(() => { bubble.style.transition = ''; }, 200);
          }, 400);
        })
        .catch(() => {});
      _lastTap = 0;
      _lastBubble = null;
    } else {
      _lastTap   = now;
      _lastBubble = bubble;
    }
  }, { passive: false });
}

// ── Mobile: keyboard open detection is handled by the Visual Viewport
// Manager at the top of this file — no duplicate listener needed here.

// ── Mobile: Enter key sends on single tap (Shift+Enter = new line) ─
// Already handled by the existing keydown listener, but we also add
// a submit-on-go for mobile keyboard's "Go/Send" button (which fires
// a submit event or Enter on some Android keyboards).
if (IS_MOBILE) {
  const input = document.getElementById('userInput');
  if (input) {
    // Some Android keyboards fire 'keydown' with key='Enter' which
    // is already handled. Some fire 'input' with inputType='insertLineBreak'.
    input.addEventListener('input', e => {
      if (e.inputType === 'insertLineBreak') {
        // BUG FIX: remove the inserted newline character BEFORE calling handleSend
        // so the textarea value is correct and handleSend sees trimmed text.
        const pos = input.selectionStart;
        input.value = input.value.slice(0, pos - 1) + input.value.slice(pos);
        // Move caret back to correct position
        input.setSelectionRange(pos - 1, pos - 1);
        handleInput(); // recalculates sendBtn.disabled based on cleaned value
        const sendBtnEl = document.getElementById('sendBtn');
        if (!sendBtnEl?.disabled && input.value.trim().length > 0) handleSend();
      }
    });
  }
}

// ── Momentum scrolling fix for iOS chat feed ──────────────────────
// -webkit-overflow-scrolling is deprecated but still helps on old iOS.
// The modern way is scroll-behavior + overscroll-behavior.
(function patchIOSScroll() {
  const feed = document.getElementById('chatFeed');
  if (!feed) return;
  feed.style.webkitOverflowScrolling = 'touch';
})();
// ══════════════════════════════════════════════════════════════════
// ◈ LUNA STREAK SYSTEM v2 — Lunova · Lunette · Lunara · Novaria · Solara
// Mobile-first, zero canvas, zero rAF loops, CSS-SVG moons
// ══════════════════════════════════════════════════════════════════

// ── Tier configuration ────────────────────────────────────────────
const STREAK_TIERS = [
  {
    id: 'lunova',
    name: 'LUNOVA',
    sub: 'MOON EGG',
    days: [1, 2],      // 1–2 days
    minDay: 1,
    maxDay: 2,
    nextMin: 3,
    emoji: '🥚',
    color: '#f59e0b',
    color2: '#fde68a',
  },
  {
    id: 'lunette',
    name: 'LUNETTE',
    sub: 'CRESCENT MOON',
    days: null,
    minDay: 3,
    maxDay: 49,
    nextMin: 50,
    emoji: '🌙',
    color: '#a855f7',
    color2: '#c4b5fd',
  },
  {
    id: 'lunara',
    name: 'LUNARA',
    sub: 'QUARTER MOON',
    days: null,
    minDay: 50,
    maxDay: 99,
    nextMin: 100,
    emoji: '🌓',
    color: '#818cf8',
    color2: '#c7d2fe',
  },
  {
    id: 'novaria',
    name: 'NOVARIA',
    sub: 'HALF MOON',
    days: null,
    minDay: 100,
    maxDay: 199,
    nextMin: 200,
    emoji: '🌗',
    color: '#ec4899',
    color2: '#fbcfe8',
  },
  {
    id: 'solara',
    name: 'SOLARA',
    sub: 'SOLAR ECLIPSED MOON',
    days: null,
    minDay: 200,
    maxDay: Infinity,
    nextMin: null,
    emoji: '🌑',
    color: '#ef4444',
    color2: '#fca5a5',
  },
];

// ── SVG moon/egg shapes for each tier ────────────────────────────
// All tiers use an egg base: rx = s*0.34 (width), ry = s*0.43 (height)
// viewBox is square so the pill CSS container clips/shows the egg naturally
function getStreakMoonSVG(tierId, size = 32) {
  const s = size;
  const cx = s / 2, cy = s / 2;
  const rx = s * 0.33;
  const ry = s * 0.44;
  const ecy = cy + s * 0.025;

  const O = `<svg width="${s}" height="${s}" viewBox="0 0 ${s} ${s}" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">`;
  const C = `</svg>`;
  const egg = (id) => `<ellipse cx="${cx}" cy="${ecy}" rx="${rx}" ry="${ry}" fill="url(#${id})"/>`;
  const eggStroke = (color, sw) => `<ellipse cx="${cx}" cy="${ecy}" rx="${rx}" ry="${ry}" fill="none" stroke="${color}" stroke-width="${sw}"/>`;
  const spec = (alpha=0.50) => `<ellipse cx="${(cx-rx*0.24).toFixed(1)}" cy="${(ecy-ry*0.30).toFixed(1)}"
    rx="${(rx*0.26).toFixed(1)}" ry="${(ry*0.13).toFixed(1)}"
    fill="rgba(255,255,255,${alpha})" transform="rotate(-20 ${cx} ${ecy})"/>`;

  switch (tierId) {

    case 'lunova': {
      // ✦ Warm golden egg — pristine, luminous, freshly hatched glow
      const id = `lnEgg${s}`;
      return `${O}
        <defs>
          <radialGradient id="${id}" cx="34%" cy="24%" r="68%" gradientUnits="objectBoundingBox">
            <stop offset="0%"   stop-color="#fffbeb"/>
            <stop offset="22%"  stop-color="#fde68a"/>
            <stop offset="55%"  stop-color="#f59e0b"/>
            <stop offset="85%"  stop-color="#b45309"/>
            <stop offset="100%" stop-color="#78350f"/>
          </radialGradient>
          <radialGradient id="${id}g" cx="50%" cy="50%" r="50%">
            <stop offset="45%" stop-color="rgba(251,191,36,0)"/>
            <stop offset="78%" stop-color="rgba(251,191,36,0.24)"/>
            <stop offset="100%" stop-color="rgba(245,158,11,0)"/>
          </radialGradient>
        </defs>
        <!-- Warm aura -->
        <ellipse cx="${cx}" cy="${ecy}" rx="${(rx*1.16).toFixed(1)}" ry="${(ry*1.10).toFixed(1)}" fill="url(#${id}g)"/>
        ${egg(id)}
        ${eggStroke('rgba(253,230,138,0.55)', Math.max(0.7, s*0.020))}
        ${spec(0.58)}
        <!-- Secondary lower sheen -->
        <ellipse cx="${(cx+rx*0.16).toFixed(1)}" cy="${(ecy+ry*0.32).toFixed(1)}"
          rx="${(rx*0.10).toFixed(1)}" ry="${(ry*0.055).toFixed(1)}"
          fill="rgba(255,255,255,0.20)" transform="rotate(-15 ${cx} ${ecy})"/>
      ${C}`;
    }

    case 'lunette': {
      // ✦ Crescent egg — silver-violet lit edge, shadow carved right
      const id = `lnCr${s}`;
      const maskOffX = rx * 0.82;
      return `${O}
        <defs>
          <radialGradient id="${id}g" cx="26%" cy="24%" r="74%" gradientUnits="objectBoundingBox">
            <stop offset="0%"   stop-color="#f3e8ff"/>
            <stop offset="32%"  stop-color="#c084fc"/>
            <stop offset="68%"  stop-color="#7c3aed"/>
            <stop offset="100%" stop-color="#3b0764"/>
          </radialGradient>
          <mask id="${id}m">
            <rect width="${s}" height="${s}" fill="white"/>
            <ellipse cx="${(cx+maskOffX).toFixed(1)}" cy="${(ecy-ry*0.04).toFixed(1)}"
              rx="${(rx*0.96).toFixed(1)}" ry="${(ry*0.93).toFixed(1)}" fill="black"/>
          </mask>
        </defs>
        <!-- Dark side silhouette -->
        <ellipse cx="${cx}" cy="${ecy}" rx="${rx}" ry="${ry}" fill="#100428" opacity="0.88"/>
        <!-- Lit crescent -->
        <ellipse cx="${cx}" cy="${ecy}" rx="${rx}" ry="${ry}" fill="url(#${id}g)" mask="url(#${id}m)"/>
        <!-- Edge glow on lit side -->
        <ellipse cx="${(cx-rx*0.62).toFixed(1)}" cy="${(ecy).toFixed(1)}"
          rx="${(rx*0.08).toFixed(1)}" ry="${(ry*0.44).toFixed(1)}"
          fill="rgba(216,180,254,0.30)" transform="rotate(4 ${cx} ${ecy})"/>
        ${eggStroke('rgba(168,85,247,0.28)', Math.max(0.7, s*0.018))}
      ${C}`;
    }

    case 'lunara': {
      // ✦ Quarter egg — indigo half-lit, soft terminator, surface detail
      const id = `lnQu${s}`;
      return `${O}
        <defs>
          <radialGradient id="${id}g" cx="28%" cy="24%" r="74%" gradientUnits="objectBoundingBox">
            <stop offset="0%"   stop-color="#e0e7ff"/>
            <stop offset="38%"  stop-color="#818cf8"/>
            <stop offset="72%"  stop-color="#3730a3"/>
            <stop offset="100%" stop-color="#1e1b4b"/>
          </radialGradient>
          <linearGradient id="${id}sh" x1="0%" y1="0%" x2="100%" y2="0%">
            <stop offset="36%" stop-color="rgba(0,0,0,0)"/>
            <stop offset="100%" stop-color="rgba(0,0,0,0.86)"/>
          </linearGradient>
          <clipPath id="${id}cp">
            <rect x="0" y="0" width="${cx}" height="${s}"/>
          </clipPath>
        </defs>
        <!-- Full dark egg base -->
        <ellipse cx="${cx}" cy="${ecy}" rx="${rx}" ry="${ry}" fill="#0c0c20" opacity="0.90"/>
        <!-- Lit half clipped to left -->
        <ellipse cx="${cx}" cy="${ecy}" rx="${rx}" ry="${ry}" fill="url(#${id}g)" clip-path="url(#${id}cp)"/>
        <!-- Terminator shadow sweep -->
        <ellipse cx="${cx}" cy="${ecy}" rx="${rx}" ry="${ry}" fill="url(#${id}sh)"/>
        ${eggStroke('rgba(129,140,248,0.32)', Math.max(0.7, s*0.018))}
        <!-- Crater 1 -->
        <ellipse cx="${(cx-rx*0.32).toFixed(1)}" cy="${(ecy-ry*0.28).toFixed(1)}"
          rx="${(rx*0.15).toFixed(1)}" ry="${(ry*0.10).toFixed(1)}"
          fill="rgba(255,255,255,0.16)" transform="rotate(-12 ${cx} ${ecy})"/>
        <!-- Crater 2 -->
        <ellipse cx="${(cx-rx*0.18).toFixed(1)}" cy="${(ecy+ry*0.24).toFixed(1)}"
          rx="${(rx*0.09).toFixed(1)}" ry="${(ry*0.06).toFixed(1)}"
          fill="rgba(255,255,255,0.10)" transform="rotate(-6 ${cx} ${ecy})"/>
      ${C}`;
    }

    case 'novaria': {
      // ✦ Gibbous egg — rose-pink, mostly lit, rosy ambient glow
      const id = `lnNv${s}`;
      const maskOffX = rx * 0.36;
      return `${O}
        <defs>
          <radialGradient id="${id}g" cx="30%" cy="22%" r="76%" gradientUnits="objectBoundingBox">
            <stop offset="0%"   stop-color="#fdf2f8"/>
            <stop offset="36%"  stop-color="#f472b6"/>
            <stop offset="68%"  stop-color="#be185d"/>
            <stop offset="100%" stop-color="#500724"/>
          </radialGradient>
          <radialGradient id="${id}amb" cx="50%" cy="50%" r="50%">
            <stop offset="50%" stop-color="rgba(244,114,182,0)"/>
            <stop offset="76%" stop-color="rgba(244,114,182,0.30)"/>
            <stop offset="100%" stop-color="rgba(236,72,153,0)"/>
          </radialGradient>
          <mask id="${id}m">
            <rect width="${s}" height="${s}" fill="white"/>
            <ellipse cx="${(cx+maskOffX).toFixed(1)}" cy="${(ecy+ry*0.04).toFixed(1)}"
              rx="${(rx*0.58).toFixed(1)}" ry="${(ry*0.85).toFixed(1)}" fill="black"/>
          </mask>
        </defs>
        <!-- Ambient glow ring -->
        <ellipse cx="${cx}" cy="${ecy}" rx="${(rx*1.20).toFixed(1)}" ry="${(ry*1.12).toFixed(1)}" fill="url(#${id}amb)"/>
        <!-- Lit egg -->
        <ellipse cx="${cx}" cy="${ecy}" rx="${rx}" ry="${ry}" fill="url(#${id}g)" mask="url(#${id}m)"/>
        ${eggStroke('rgba(251,207,232,0.32)', Math.max(0.7, s*0.018))}
        ${spec(0.42)}
        <!-- Lower soft sheen -->
        <ellipse cx="${(cx-rx*0.42).toFixed(1)}" cy="${(ecy+ry*0.20).toFixed(1)}"
          rx="${(rx*0.09).toFixed(1)}" ry="${(ry*0.055).toFixed(1)}"
          fill="rgba(255,255,255,0.18)" transform="rotate(-10 ${cx} ${ecy})"/>
      ${C}`;
    }

    case 'solara': {
      // ✦ Eclipse egg — ink-black body, fiery corona rays, gold rim
      const id = `lnSl${s}`;
      const rays = [0,36,72,108,144,180,216,252,288,324];
      const rayLines = rays.map(deg => {
        const rad = (deg * Math.PI) / 180;
        const ex = cx + rx * Math.cos(rad);
        const ey = ecy + ry * Math.sin(rad);
        const len = s * (0.11 + 0.07 * Math.abs(Math.sin(deg * Math.PI / 90)));
        const bx = cx + (rx + len) * Math.cos(rad);
        const by = ecy + (ry + len) * Math.sin(rad);
        const op = 0.28 + 0.36 * Math.abs(Math.sin(deg * Math.PI / 90));
        return `<line x1="${ex.toFixed(1)}" y1="${ey.toFixed(1)}" x2="${bx.toFixed(1)}" y2="${by.toFixed(1)}"
          stroke="rgba(251,191,36,${op.toFixed(2)})" stroke-width="${Math.max(0.8, s*0.020)}" stroke-linecap="round"/>`;
      }).join('');
      const rimStars = [55,145,235,320].map((deg, i) => {
        const rad = (deg * Math.PI) / 180;
        const sx = cx + (rx + s*0.20) * Math.cos(rad);
        const sy = ecy + (ry + s*0.12) * Math.sin(rad);
        const sr = [1.6, 1.2, 1.4, 1.1][i];
        return `<circle cx="${sx.toFixed(1)}" cy="${sy.toFixed(1)}" r="${sr}" fill="#fbbf24" opacity="0.84"/>`;
      }).join('');
      return `${O}
        <defs>
          <radialGradient id="${id}cor" cx="50%" cy="50%" r="50%">
            <stop offset="52%" stop-color="rgba(239,68,68,0)"/>
            <stop offset="72%" stop-color="rgba(251,191,36,0.52)"/>
            <stop offset="88%" stop-color="rgba(239,68,68,0.18)"/>
            <stop offset="100%" stop-color="rgba(0,0,0,0)"/>
          </radialGradient>
        </defs>
        <!-- Outer corona glow -->
        <ellipse cx="${cx}" cy="${ecy}" rx="${(rx*1.36).toFixed(1)}" ry="${(ry*1.26).toFixed(1)}" fill="url(#${id}cor)"/>
        <!-- Ray spikes -->
        ${rayLines}
        <!-- Dark egg body -->
        <ellipse cx="${cx}" cy="${ecy}" rx="${rx}" ry="${ry}" fill="#080101"/>
        <!-- Golden-red rim glow -->
        ${eggStroke('rgba(239,68,68,0.76)', Math.max(1.0, s*0.025))}
        <!-- Gold rim shimmer top-left -->
        <ellipse cx="${(cx-rx*0.20).toFixed(1)}" cy="${(ecy-ry*0.80).toFixed(1)}"
          rx="${(rx*0.24).toFixed(1)}" ry="${(ry*0.06).toFixed(1)}"
          fill="rgba(251,191,36,0.60)" transform="rotate(-10 ${cx} ${ecy})"/>
        ${rimStars}
      ${C}`;
    }

    default:
      return `${O}<ellipse cx="${cx}" cy="${ecy}" rx="${rx}" ry="${ry}" fill="rgba(168,85,247,0.5)"/>${C}`;
  }
}


// ── Streak data (localStorage per user) ──────────────────────────
function _streakKey() {
  const u = (typeof userName !== 'undefined' && userName)
    ? userName.toLowerCase().replace(/[^a-z0-9]/g, '_') : 'anon';
  return `luna_streak2_${u}`;
}

function loadStreakData() {
  try { return JSON.parse(localStorage.getItem(_streakKey())) || { days: 0, lastDate: null }; }
  catch { return { days: 0, lastDate: null }; }
}

function saveStreakData(data) {
  try {
    localStorage.setItem(_streakKey(), JSON.stringify(data));
    // Cross-tab broadcast: ping other tabs so they re-render immediately
    try { localStorage.setItem(_streakKey() + '_sync', String(Date.now())); } catch {}
  } catch {}
}

// ══════════════════════════════════════════════════════════════════
// ◈ STREAK STATES — Frozen / Rotten
//
//   FROZEN : No chat between user and Luna for ≥ 7 hours.
//            The egg/pet is covered in an ice overlay.
//            If the user chats again, ice melts and streak resumes.
//            If they don't chat before the next calendar-day boundary
//            passes (≥ 7h of silence crossing midnight), streak resets
//            to day 1 on next login.
//
//   ROTTEN : The egg is still at lunova tier (days 1-2) and 3 full
//            calendar days have elapsed since the streak started
//            (meaning the user logged in but never progressed the egg
//            to day 3 to hatch it). The egg goes rotten with a
//            bubbling/dripping animation and a "Restart your streak"
//            message is shown.
// ══════════════════════════════════════════════════════════════════

const STREAK_IDLE_MS = 7 * 60 * 60 * 1000;  // 7 hours
const STREAK_ROT_DAYS = 3;                   // calendar days before egg rots

function _lastChatKey() { return _streakKey() + '_lastchat'; }
function _eggBornKey()  { return _streakKey() + '_eggborn';  }
function _rottenKey()   { return _streakKey() + '_rotten';   }

/** Record current timestamp as "last time user sent a message to Luna" */
function recordStreakChatActivity() {
  try { localStorage.setItem(_lastChatKey(), String(Date.now())); } catch {}
  // If egg was rotten, a new message restarts it
  if (isEggRotten()) {
    try { localStorage.removeItem(_rottenKey()); } catch {}
    const data = loadStreakData();
    data.days     = 1;
    data.lastDate = new Date().toDateString();
    saveStreakData(data);
    // Reset egg-born timestamp to today
    try { localStorage.setItem(_eggBornKey(), String(Date.now())); } catch {}
    renderStreakUI();
    checkStreakState();
    return;
  }
  // If currently frozen, a new message thaws the egg
  if (isEggFrozen()) {
    thawEgg();
  }
}

/** Milliseconds since last chat (Infinity if never) */
function msSinceLastChat() {
  try {
    const ts = parseInt(localStorage.getItem(_lastChatKey()), 10);
    return isNaN(ts) ? Infinity : Date.now() - ts;
  } catch { return Infinity; }
}

/** True when user has been silent for ≥ 7 hours */
function isEggFrozen() {
  return msSinceLastChat() >= STREAK_IDLE_MS;
}

/** True when egg started ≥ 3 calendar days ago and is still lunova (never hatched) */
function isEggRotten() {
  try { return localStorage.getItem(_rottenKey()) === '1'; } catch { return false; }
}

/** Check if the egg-born date is old enough to rot */
function checkEggRotCondition() {
  const data = loadStreakData();
  // Only applies to lunova (egg phase, days 1-2)
  if (!data || data.days > 2) return false;
  try {
    const born = parseInt(localStorage.getItem(_eggBornKey()), 10);
    if (isNaN(born)) {
      // First run — set born timestamp now
      localStorage.setItem(_eggBornKey(), String(Date.now()));
      return false;
    }
    const daysSinceBorn = (Date.now() - born) / 86400000;
    return daysSinceBorn >= STREAK_ROT_DAYS;
  } catch { return false; }
}

/** Apply the ice overlay to the streak pill */
function freezeEgg() {
  const pill = document.getElementById('streakPill');
  if (!pill || pill.classList.contains('egg-frozen')) return;
  pill.classList.add('egg-frozen');
  // Remove the float animation while frozen
  pill.style.animationName = 'spGlow';

  // Inject ice SVG overlay if not already present
  if (!pill.querySelector('.egg-ice-overlay')) {
    const ice = document.createElement('div');
    ice.className = 'egg-ice-overlay';
    ice.innerHTML = _buildIceSVG();
    pill.prepend(ice);
  }

  // Update the pill label
  const nameEl = pill.querySelector('.sp-pill-name');
  if (nameEl) nameEl.textContent = 'FROZEN';

  showToast('❄️ Your streak pet is frozen! Chat with Luna to thaw it.', '❄️', 4000);
}

/** Remove the ice overlay when user returns */
function thawEgg() {
  const pill = document.getElementById('streakPill');
  if (!pill || !pill.classList.contains('egg-frozen')) return;
  pill.classList.remove('egg-frozen');
  // Restore float animation
  pill.style.animationName = '';

  const ice = pill.querySelector('.egg-ice-overlay');
  if (ice) {
    ice.classList.add('ice-thawing');
    setTimeout(() => ice.remove(), 800);
  }

  // Restore tier name
  const data = loadStreakData();
  const tier = getTierForDays(data.days);
  const nameEl = pill.querySelector('.sp-pill-name');
  if (nameEl) nameEl.textContent = tier.name;

  showToast('🔥 Streak thawed! Keep chatting! ✦', '🔥', 2800);
}

/** Mark egg as rotten and show the overlay */
function rotEgg() {
  try { localStorage.setItem(_rottenKey(), '1'); } catch {}
  // Reset streak to 0 (forces egg back to unhatched state visually)
  const pill = document.getElementById('streakPill');
  if (pill) {
    pill.classList.add('egg-rotten');
    const ice = pill.querySelector('.egg-ice-overlay');
    if (ice) ice.remove();
    pill.classList.remove('egg-frozen');
    // Update moon to rotten egg SVG
    const moonEl = pill.querySelector('.sp-pill-moon');
    if (moonEl) moonEl.innerHTML = _buildRottenEggSVG(36);
    const nameEl = pill.querySelector('.sp-pill-name');
    if (nameEl) nameEl.textContent = 'ROTTEN';
    const daysEl = pill.querySelector('.sp-pill-days');
    if (daysEl) daysEl.textContent = '✕';
  }
  showRottenEggOverlay();
}

/** Master check — call on login and periodically */
function checkStreakState() {
  const data = loadStreakData();
  if (!data || !data.days) return;

  // 1. Rotten check (egg never hatched in 3 days)
  if (!isEggRotten() && checkEggRotCondition()) {
    rotEgg(); return;
  }
  if (isEggRotten()) {
    // Already rotten — ensure pill shows rotten state
    const pill = document.getElementById('streakPill');
    if (pill && !pill.classList.contains('egg-rotten')) {
      pill.classList.add('egg-rotten');
      const moonEl = pill.querySelector('.sp-pill-moon');
      if (moonEl) moonEl.innerHTML = _buildRottenEggSVG(36);
      const nameEl = pill.querySelector('.sp-pill-name');
      if (nameEl) nameEl.textContent = 'ROTTEN';
    }
    return;
  }

  // 2. Frozen check (silent for ≥ 7 hours)
  if (isEggFrozen()) {
    freezeEgg();
  }
}

// Re-check every 5 minutes while the tab is open
setInterval(() => {
  if (appState === 'chat' && userName) checkStreakState();
}, 5 * 60 * 1000);

/** Build the ice overlay SVG */
function _buildIceSVG() {
  return `<svg class="ice-svg" viewBox="0 0 40 50" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
    <defs>
      <radialGradient id="iceBody" cx="40%" cy="28%" r="70%" gradientUnits="objectBoundingBox">
        <stop offset="0%"   stop-color="#e0f2fe" stop-opacity="0.92"/>
        <stop offset="40%"  stop-color="#7dd3fc" stop-opacity="0.78"/>
        <stop offset="80%"  stop-color="#0ea5e9" stop-opacity="0.70"/>
        <stop offset="100%" stop-color="#0369a1" stop-opacity="0.82"/>
      </radialGradient>
      <radialGradient id="iceGlow" cx="50%" cy="50%" r="50%">
        <stop offset="30%" stop-color="rgba(125,211,252,0)"/>
        <stop offset="80%" stop-color="rgba(125,211,252,0.35)"/>
        <stop offset="100%" stop-color="rgba(14,165,233,0)"/>
      </radialGradient>
    </defs>
    <!-- Outer glow -->
    <ellipse cx="20" cy="27" rx="17" ry="23" fill="url(#iceGlow)"/>
    <!-- Ice body -->
    <ellipse cx="20" cy="27" rx="13.5" ry="18" fill="url(#iceBody)"/>
    <!-- Crack lines for texture -->
    <path d="M14 20 L18 25 L15 30" stroke="rgba(255,255,255,0.55)" stroke-width="0.8" stroke-linecap="round"/>
    <path d="M22 18 L25 24 L28 22" stroke="rgba(255,255,255,0.45)" stroke-width="0.7" stroke-linecap="round"/>
    <path d="M17 32 L20 36 L24 33" stroke="rgba(255,255,255,0.40)" stroke-width="0.7" stroke-linecap="round"/>
    <!-- Specular highlight -->
    <ellipse cx="15" cy="20" rx="4" ry="2.5" fill="rgba(255,255,255,0.60)" transform="rotate(-20 20 27)"/>
    <ellipse cx="24" cy="18" rx="2" ry="1.2" fill="rgba(255,255,255,0.40)" transform="rotate(-10 20 27)"/>
    <!-- Frost dots -->
    <circle cx="12" cy="29" r="1.2" fill="rgba(255,255,255,0.50)"/>
    <circle cx="28" cy="24" r="0.9" fill="rgba(255,255,255,0.40)"/>
    <circle cx="20" cy="38" r="1.0" fill="rgba(255,255,255,0.35)"/>
    <!-- Icicles hanging from bottom -->
    <path d="M16 44 Q16.5 47 17 45 Q17.5 49 18 46" stroke="rgba(125,211,252,0.75)" stroke-width="1.2" fill="none" stroke-linecap="round"/>
    <path d="M20 45 Q20.5 49 21 46 Q21.5 50 22 47" stroke="rgba(125,211,252,0.70)" stroke-width="1.1" fill="none" stroke-linecap="round"/>
    <path d="M24 43 Q24.5 46 25 44" stroke="rgba(125,211,252,0.60)" stroke-width="1.0" fill="none" stroke-linecap="round"/>
  </svg>`;
}

/** Build a rotten/decayed egg SVG */
function _buildRottenEggSVG(size = 36) {
  const s = size, cx = s/2, cy = s/2 + s*0.03, rx = s*0.33, ry = s*0.44;
  return `<svg width="${s}" height="${s}" viewBox="0 0 ${s} ${s}" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
    <defs>
      <radialGradient id="rotEgg${s}" cx="36%" cy="28%" r="70%" gradientUnits="objectBoundingBox">
        <stop offset="0%"   stop-color="#a3e635" stop-opacity="0.9"/>
        <stop offset="30%"  stop-color="#65a30d"/>
        <stop offset="65%"  stop-color="#3f6212"/>
        <stop offset="100%" stop-color="#1a2e05"/>
      </radialGradient>
      <radialGradient id="rotGlow${s}" cx="50%" cy="50%" r="50%">
        <stop offset="40%" stop-color="rgba(163,230,53,0)"/>
        <stop offset="80%" stop-color="rgba(163,230,53,0.22)"/>
        <stop offset="100%" stop-color="rgba(101,163,13,0)"/>
      </radialGradient>
    </defs>
    <!-- Toxic aura -->
    <ellipse cx="${cx}" cy="${cy}" rx="${(rx*1.2).toFixed(1)}" ry="${(ry*1.12).toFixed(1)}" fill="url(#rotGlow${s})"/>
    <!-- Rotten egg body -->
    <ellipse cx="${cx}" cy="${cy}" rx="${rx}" ry="${ry}" fill="url(#rotEgg${s})"/>
    <!-- Brown rot patches -->
    <ellipse cx="${(cx+rx*0.18).toFixed(1)}" cy="${(cy+ry*0.22).toFixed(1)}" rx="${(rx*0.28).toFixed(1)}" ry="${(ry*0.18).toFixed(1)}" fill="rgba(120,53,15,0.60)" transform="rotate(-12 ${cx} ${cy})"/>
    <ellipse cx="${(cx-rx*0.24).toFixed(1)}" cy="${(cy-ry*0.18).toFixed(1)}" rx="${(rx*0.20).toFixed(1)}" ry="${(ry*0.13).toFixed(1)}" fill="rgba(120,53,15,0.45)" transform="rotate(8 ${cx} ${cy})"/>
    <!-- Crack -->
    <path d="M${cx} ${(cy-ry*0.3).toFixed(1)} L${(cx-rx*0.14).toFixed(1)} ${(cy+ry*0.08).toFixed(1)} L${cx} ${(cy+ry*0.22).toFixed(1)}" stroke="rgba(0,0,0,0.6)" stroke-width="${Math.max(0.8,s*0.024)}" stroke-linecap="round" fill="none"/>
    <!-- Toxic drip -->
    <path d="M${(cx-rx*0.08).toFixed(1)} ${(cy+ry*0.82).toFixed(1)} Q${(cx-rx*0.06).toFixed(1)} ${(cy+ry*1.02).toFixed(1)} ${(cx-rx*0.10).toFixed(1)} ${(cy+ry*0.94).toFixed(1)}" stroke="rgba(132,204,22,0.80)" stroke-width="${Math.max(0.9,s*0.026)}" stroke-linecap="round" fill="none"/>
    <!-- Skull eyes (X marks) -->
    <text x="${(cx-rx*0.20).toFixed(1)}" y="${(cy-ry*0.06).toFixed(1)}" font-size="${Math.max(4,s*0.14)}" fill="rgba(0,0,0,0.70)" text-anchor="middle" font-family="sans-serif">✕</text>
    <text x="${(cx+rx*0.20).toFixed(1)}" y="${(cy-ry*0.06).toFixed(1)}" font-size="${Math.max(4,s*0.14)}" fill="rgba(0,0,0,0.70)" text-anchor="middle" font-family="sans-serif">✕</text>
    <!-- Stink lines -->
    <path d="M${(cx-rx*0.5).toFixed(1)} ${(cy-ry*1.05).toFixed(1)} Q${(cx-rx*0.6).toFixed(1)} ${(cy-ry*1.22).toFixed(1)} ${(cx-rx*0.48).toFixed(1)} ${(cy-ry*1.38).toFixed(1)}" stroke="rgba(163,230,53,0.55)" stroke-width="${Math.max(0.8,s*0.022)}" stroke-linecap="round" fill="none"/>
    <path d="M${cx.toFixed(1)} ${(cy-ry*1.10).toFixed(1)} Q${(cx+rx*0.12).toFixed(1)} ${(cy-ry*1.30).toFixed(1)} ${(cx-rx*0.06).toFixed(1)} ${(cy-ry*1.45).toFixed(1)}" stroke="rgba(163,230,53,0.45)" stroke-width="${Math.max(0.8,s*0.018)}" stroke-linecap="round" fill="none"/>
    <path d="M${(cx+rx*0.40).toFixed(1)} ${(cy-ry*1.05).toFixed(1)} Q${(cx+rx*0.55).toFixed(1)} ${(cy-ry*1.25).toFixed(1)} ${(cx+rx*0.42).toFixed(1)} ${(cy-ry*1.38).toFixed(1)}" stroke="rgba(163,230,53,0.45)" stroke-width="${Math.max(0.7,s*0.018)}" stroke-linecap="round" fill="none"/>
  </svg>`;
}

/** Full-screen rotten egg animation overlay */
function showRottenEggOverlay() {
  if (document.getElementById('rottenEggOverlay')) return;

  const overlay = document.createElement('div');
  overlay.id = 'rottenEggOverlay';
  overlay.style.cssText = `
    position:fixed;inset:0;z-index:99998;
    background:radial-gradient(ellipse at 50% 55%, #0a1a02 0%, #020209 70%);
    display:flex;flex-direction:column;align-items:center;justify-content:center;
    gap:0;cursor:pointer;user-select:none;-webkit-user-select:none;
    animation:rotOverlayIn 0.5s cubic-bezier(0.4,0,0.2,1) both;
  `;
  overlay.innerHTML = `
    <style>
      @keyframes rotOverlayIn  { from{opacity:0} to{opacity:1} }
      @keyframes rotOverlayOut { to{opacity:0;transform:scale(0.96)} }
      @keyframes rotDrip {
        0%   { transform:translateY(0) scaleY(0.7); opacity:0.9; }
        60%  { transform:translateY(12px) scaleY(1.3); opacity:1; }
        100% { transform:translateY(28px) scaleY(0.4); opacity:0; }
      }
      @keyframes rotBubble {
        0%,100% { transform:scale(1) translateY(0); opacity:0.7; }
        50%     { transform:scale(1.22) translateY(-6px); opacity:1; }
      }
      @keyframes stinkDrift {
        0%   { transform:translateY(0) rotate(0deg); opacity:0; }
        20%  { opacity:0.7; }
        100% { transform:translateY(-40px) rotate(15deg); opacity:0; }
      }
      @keyframes rotShake {
        0%,100%{transform:rotate(0deg)} 20%{transform:rotate(-4deg)} 60%{transform:rotate(4deg)}
      }
      @keyframes rotPulse {
        0%,100%{filter:drop-shadow(0 0 12px rgba(163,230,53,0.5))}
        50%{filter:drop-shadow(0 0 30px rgba(163,230,53,0.9)) drop-shadow(0 0 60px rgba(163,230,53,0.4))}
      }
      @keyframes rotTextPulse {
        0%,100%{opacity:0.7;transform:scale(1)} 50%{opacity:1;transform:scale(1.04)}
      }
      #rotEggStage { position:relative;width:160px;height:190px;display:flex;align-items:center;justify-content:center; }
      #rotMainSvg  { animation:rotPulse 2s ease-in-out infinite, rotShake 4s ease-in-out infinite; }
      .rot-drip    { position:absolute;bottom:-8px;animation:rotDrip 1.4s ease-in-out infinite; }
      .rot-bubble  { position:absolute;border-radius:50%;background:rgba(163,230,53,0.45);animation:rotBubble 1.8s ease-in-out infinite; }
      .rot-stink   { position:absolute;font-size:18px;animation:stinkDrift 2.2s ease-out infinite; }
      .rot-title   { font-family:'Orbitron',sans-serif;font-size:14px;letter-spacing:0.28em;color:#a3e635;text-shadow:0 0 20px rgba(163,230,53,0.7);margin-bottom:6px; }
      .rot-sub     { font-family:'Orbitron',sans-serif;font-size:9px;letter-spacing:0.20em;color:rgba(163,230,53,0.55);margin-bottom:24px; }
      .rot-restart-btn {
        margin-top:8px;padding:13px 32px;
        background:linear-gradient(135deg,rgba(163,230,53,0.18),rgba(101,163,13,0.12));
        border:1px solid rgba(163,230,53,0.50);border-radius:50px;
        color:#a3e635;font-family:'Orbitron',sans-serif;font-size:10px;letter-spacing:0.22em;
        cursor:pointer;animation:rotTextPulse 1.6s ease-in-out infinite;
        transition:background 0.2s,border-color 0.2s;
      }
      .rot-restart-btn:hover { background:rgba(163,230,53,0.26);border-color:rgba(163,230,53,0.80); }
      .rot-tap-hint { font-family:'Orbitron',sans-serif;font-size:9px;letter-spacing:0.16em;color:rgba(163,230,53,0.35);margin-top:10px; }
    </style>

    <div class="rot-title">EGG WENT ROTTEN</div>
    <div class="rot-sub">◈ 3 DAYS WITHOUT HATCHING ◈</div>

    <div id="rotEggStage">
      <div id="rotMainSvg">${_buildRottenEggSVG(130)}</div>

      <!-- Drips -->
      <div class="rot-drip" style="left:52px;animation-delay:0s;width:6px;height:18px;background:linear-gradient(to bottom,rgba(163,230,53,0.7),transparent);border-radius:0 0 8px 8px;"></div>
      <div class="rot-drip" style="left:80px;animation-delay:0.6s;width:5px;height:14px;background:linear-gradient(to bottom,rgba(132,204,22,0.6),transparent);border-radius:0 0 8px 8px;"></div>
      <div class="rot-drip" style="left:100px;animation-delay:1.0s;width:4px;height:12px;background:linear-gradient(to bottom,rgba(163,230,53,0.5),transparent);border-radius:0 0 8px 8px;"></div>

      <!-- Toxic bubbles -->
      <div class="rot-bubble" style="width:10px;height:10px;top:20px;left:20px;animation-delay:0.3s;"></div>
      <div class="rot-bubble" style="width:7px;height:7px;top:35px;right:18px;animation-delay:0.8s;"></div>
      <div class="rot-bubble" style="width:8px;height:8px;bottom:40px;left:14px;animation-delay:1.3s;"></div>

      <!-- Stink lines -->
      <div class="rot-stink" style="top:0px;left:22px;animation-delay:0s;">💨</div>
      <div class="rot-stink" style="top:0px;left:66px;animation-delay:0.7s;">💨</div>
      <div class="rot-stink" style="top:0px;right:22px;animation-delay:1.2s;">💨</div>
    </div>

    <button class="rot-restart-btn" id="rotRestartBtn">✦ RESTART YOUR STREAK ✦</button>
    <div class="rot-tap-hint">tap anywhere to dismiss</div>
  `;

  document.body.appendChild(overlay);

  function dismiss() {
    overlay.style.animation = 'rotOverlayOut 0.4s cubic-bezier(0.4,0,1,1) forwards';
    setTimeout(() => overlay.remove(), 380);
  }

  overlay.addEventListener('click', dismiss);
  document.getElementById('rotRestartBtn')?.addEventListener('click', (e) => {
    e.stopPropagation();
    // Clear rotten + streak, restart
    try {
      localStorage.removeItem(_rottenKey());
      localStorage.removeItem(_eggBornKey());
    } catch {}
    const data = { days: 1, lastDate: new Date().toDateString() };
    saveStreakData(data);
    try { localStorage.setItem(_eggBornKey(), String(Date.now())); } catch {}
    // Record this as a chat action so ice won't immediately re-apply
    try { localStorage.setItem(_lastChatKey(), String(Date.now())); } catch {}
    dismiss();
    setTimeout(() => {
      renderStreakUI();
      showToast('🥚 Fresh egg! Keep chatting daily to hatch it! ✦', '🥚', 3500);
    }, 400);
  });
}

// ── Cross-tab streak sync listener ───────────────────────────────
// When another tab writes the streak, this tab updates its UI instantly.
window.addEventListener('storage', (e) => {
  if (!userName) return;
  const key = _streakKey();
  if (e.key === key || e.key === key + '_sync') {
    const data = loadStreakData();
    if (data && data.days > 0) renderStreakUI();
  }
});

function getTierForDays(days) {
  for (let i = STREAK_TIERS.length - 1; i >= 0; i--) {
    if (days >= STREAK_TIERS[i].minDay) return STREAK_TIERS[i];
  }
  return STREAK_TIERS[0];
}

function getStreakLevel(days) {
  return getTierForDays(days).id;
}

// Progress within current tier (0–100)
function getTierProgress(days) {
  const tier = getTierForDays(days);
  if (!tier.nextMin) return 100; // max tier
  const span = tier.nextMin - tier.minDay;
  const done = days - tier.minDay;
  return Math.min(100, Math.round((done / span) * 100));
}

function getDaysToNextTier(days) {
  const tier = getTierForDays(days);
  if (!tier.nextMin) return null;
  return tier.nextMin - days;
}

function getNextTier(currentTierId) {
  const idx = STREAK_TIERS.findIndex(t => t.id === currentTierId);
  return idx >= 0 && idx < STREAK_TIERS.length - 1 ? STREAK_TIERS[idx + 1] : null;
}

// ── Firebase sync ─────────────────────────────────────────────────
function syncStreakToFirebase(days, level) {
  if (!firebaseReady || !firebaseDb || !currentUserId) return;
  const ukey = currentUserId;
  const today = new Date().toDateString();
  firebaseDb.ref(`luna-accounts/${ukey}/streak`).set({
    days, level, lastDate: today, name: userName || ukey,
  }).catch(() => {});
}

// ── Compute streak on login ───────────────────────────────────────
let _prevStreakTierId = null;

function computeStreak() {
  if (!userName) return;
  const today     = new Date().toDateString();
  const yesterday = new Date(Date.now() - 86400000).toDateString();
  const data = loadStreakData();

  if (data.lastDate !== today) {
    if (data.lastDate === yesterday) {
      data.days = (data.days || 0) + 1;
    } else if (!data.lastDate) {
      data.days = 1; // first ever login
    } else {
      data.days = 1; // streak broke
    }
    data.lastDate = today;
    saveStreakData(data);
  }

  const tier     = getTierForDays(data.days);
  const prevId   = _prevStreakTierId;
  _prevStreakTierId = tier.id;

  // Tier-up celebration
  if (prevId && prevId !== tier.id) {
    setTimeout(() => {
      showToast(`${tier.emoji} ${tier.name} unlocked! ${data.days}-day streak! ✦`, tier.emoji, 4000);
    }, 500);
  }

  syncStreakToFirebase(data.days, tier.id);
  return data;
}

// ── Render all streak UI elements ────────────────────────────────
function renderStreakUI() {
  const data = loadStreakData();
  if (!data || !data.days) return;

  const tier     = getTierForDays(data.days);
  const progress = getTierProgress(data.days);
  const toNext   = getDaysToNextTier(data.days);
  const nextTier = getNextTier(tier.id);

  // ── 1. Sidebar widget ─────────────────────────────────────────
  const widget = document.getElementById('streakWidget');
  if (widget) {
    widget.style.display = '';
    widget.setAttribute('data-streak-tier', tier.id);

    const moonIcon = document.getElementById('swMoonIcon');
    if (moonIcon) moonIcon.innerHTML = getStreakMoonSVG(tier.id, 34);

    const tierName = document.getElementById('swTierName');
    if (tierName) tierName.textContent = tier.name;

    const daysNum = document.getElementById('swDaysNum');
    if (daysNum) daysNum.textContent = data.days;

    const progFill = document.getElementById('swProgFill');
    if (progFill) setTimeout(() => { progFill.style.width = progress + '%'; }, 120);
  }

  // ── 2. Floating pill ─────────────────────────────────────────
  const pill = document.getElementById('streakPill');
  if (pill) {
    pill.setAttribute('data-streak-tier', tier.id);
    pill.classList.remove('sp-hidden');
    pill.classList.add('sp-show');

    // ── Apply saved egg enhancements ──
    try {
      const eggFloat = JSON.parse(localStorage.getItem('luna-egg-float') ?? 'true');
      if (!eggFloat) pill.classList.add('sp-no-float');
      // Egg scale feature removed — always use natural size
      pill.style.transform = '';
      pill.style.transformOrigin = '';
      const eggLabel = JSON.parse(localStorage.getItem('luna-egg-label') ?? 'true');
      const lbl = document.getElementById('spPillName');
      if (lbl && !eggLabel) lbl.style.display = 'none';
    } catch {}

    const pillMoon = document.getElementById('spPillMoon');
    if (pillMoon) pillMoon.innerHTML = getStreakMoonSVG(tier.id, 36);

    const pillDays = document.getElementById('spPillDays');
    if (pillDays) pillDays.textContent = data.days;

    const pillName = document.getElementById('spPillName');
    if (pillName) pillName.textContent = tier.name;

    // ── Apply cute day-by-day pet behavior ──
    if (typeof window.applyStreakPetBehavior === 'function') {
      setTimeout(() => window.applyStreakPetBehavior(data.days), 200);
    }
  }
}

// ── Open / close streak detail sheet ─────────────────────────────

// ══════════════════════════════════════════════════════════════════
// ◈ EGG CRACK & HATCH ANIMATION — shown when day reaches 3 (lunova→lunette)
// ══════════════════════════════════════════════════════════════════

// Check if hatch animation should show (day 3, not yet shown this session)
function shouldShowHatchAnimation() {
  const data = loadStreakData();
  if (!data || data.days < 3) return false;
  const tier = getTierForDays(data.days);
  if (tier.id !== 'lunette') return false;
  // Only show once per user (store flag in localStorage)
  const flag = localStorage.getItem('luna_hatched_' + (userName || 'anon'));
  return flag !== '1';
}

function markHatchSeen() {
  try { localStorage.setItem('luna_hatched_' + (userName || 'anon'), '1'); } catch {}
}

// ── Build and show the full-screen hatch overlay ─────────────────
function showEggHatchOverlay(onComplete) {
  markHatchSeen();
  if (document.getElementById('eggHatchOverlay')) return;

  const overlay = document.createElement('div');
  overlay.id = 'eggHatchOverlay';
  overlay.style.cssText = `
    position:fixed; inset:0; z-index:99999;
    background:radial-gradient(ellipse at 50% 60%, #0e0428 0%, #020209 70%);
    display:flex; flex-direction:column; align-items:center; justify-content:center;
    gap:0; cursor:pointer; user-select:none; -webkit-user-select:none;
    animation: hatchOverlayIn 0.5s cubic-bezier(0.4,0,0.2,1) both;
  `;

  overlay.innerHTML = `
    <style>
      @keyframes hatchOverlayIn { from{opacity:0} to{opacity:1} }
      @keyframes hatchOverlayOut { to{opacity:0;transform:scale(1.06)} }
      @keyframes eggWobble { 0%,100%{transform:rotate(0deg)} 20%{transform:rotate(-6deg)} 40%{transform:rotate(6deg)} 60%{transform:rotate(-4deg)} 80%{transform:rotate(4deg)} }
      @keyframes eggShake  { 0%,100%{transform:translateX(0)} 20%{transform:translateX(-8px)} 40%{transform:translateX(8px)} 60%{transform:translateX(-5px)} 80%{transform:translateX(5px)} }
      @keyframes crackFlash { 0%{opacity:0} 40%{opacity:1} 100%{opacity:0} }
      @keyframes hatchBurst { 0%{opacity:0;transform:scale(0.4) rotate(0deg)} 50%{opacity:1} 100%{opacity:0;transform:scale(2.4) rotate(20deg)} }
      @keyframes moonReveal { 0%{opacity:0;transform:scale(0.3) translateY(30px)} 60%{transform:scale(1.15) translateY(-8px)} 100%{opacity:1;transform:scale(1) translateY(0)} }
      @keyframes moonGlowPulse { 0%,100%{filter:drop-shadow(0 0 30px rgba(168,85,247,0.9))} 50%{filter:drop-shadow(0 0 60px rgba(168,85,247,1)) drop-shadow(0 0 120px rgba(168,85,247,0.6))} }
      @keyframes starsExplode { 0%{opacity:0;transform:scale(0)} 30%{opacity:1} 100%{opacity:0;transform:scale(1) translate(var(--sx),var(--sy))} }
      @keyframes tapHint { 0%,100%{opacity:0.5;transform:scale(1)} 50%{opacity:1;transform:scale(1.04)} }
      @keyframes crackLine { from{stroke-dashoffset:1} to{stroke-dashoffset:0} }
      @keyframes shellHalf { to{transform:var(--shell-dest);opacity:0} }
      #eggHatchStage { position:relative; width:180px; height:220px; }
      #eggHatchSvg { width:180px; height:220px; display:block; transition:filter 0.3s; }
      #eggCrackSvg { position:absolute; inset:0; pointer-events:none; }
      #eggShellLeft, #eggShellRight { position:absolute; inset:0; pointer-events:none; opacity:0; }
      #moonRevealEl { position:absolute; inset:0; display:flex; align-items:center; justify-content:center; opacity:0; pointer-events:none; }
      #starBurst { position:absolute; inset:-80px; pointer-events:none; }
      .tap-hint { font-family:'Orbitron',sans-serif; font-size:11px; letter-spacing:0.22em; color:rgba(168,85,247,0.7); margin-top:28px; animation:tapHint 1.4s ease-in-out infinite; }
      .hatch-title { font-family:'Orbitron',sans-serif; font-size:13px; letter-spacing:0.30em; color:rgba(168,85,247,0.55); margin-bottom:18px; }
      .hatch-day3 { font-family:'Orbitron',sans-serif; font-size:9px; letter-spacing:0.20em; color:rgba(168,85,247,0.35); margin-top:6px; }
    </style>
    <div class="hatch-title">DAY 3 · STREAK MILESTONE</div>
    <div id="eggHatchStage">
      <!-- Main egg SVG -->
      <svg id="eggHatchSvg" viewBox="0 0 180 220" fill="none" xmlns="http://www.w3.org/2000/svg">
        <defs>
          <radialGradient id="hEgg" cx="34%" cy="24%" r="68%" gradientUnits="objectBoundingBox">
            <stop offset="0%"  stop-color="#fffbeb"/>
            <stop offset="22%" stop-color="#fde68a"/>
            <stop offset="55%" stop-color="#f59e0b"/>
            <stop offset="85%" stop-color="#b45309"/>
            <stop offset="100%" stop-color="#78350f"/>
          </radialGradient>
          <radialGradient id="hEggGlow" cx="50%" cy="50%" r="50%">
            <stop offset="45%" stop-color="rgba(251,191,36,0)"/>
            <stop offset="78%" stop-color="rgba(251,191,36,0.28)"/>
            <stop offset="100%" stop-color="rgba(245,158,11,0)"/>
          </radialGradient>
        </defs>
        <ellipse cx="90" cy="115" rx="56" ry="74" fill="url(#hEggGlow)"/>
        <ellipse id="hEggBody" cx="90" cy="115" rx="56" ry="74" fill="url(#hEgg)"/>
        <ellipse cx="90" cy="115" rx="56" ry="74" fill="none" stroke="rgba(253,230,138,0.45)" stroke-width="1.2"/>
        <!-- Specular -->
        <ellipse cx="74" cy="88" rx="14" ry="8" fill="rgba(255,255,255,0.48)" transform="rotate(-20 90 115)"/>
      </svg>
      <!-- Crack lines — hidden until tapped -->
      <svg id="eggCrackSvg" viewBox="0 0 180 220" fill="none" xmlns="http://www.w3.org/2000/svg" style="opacity:0">
        <defs>
          <filter id="crackGlow"><feGaussianBlur stdDeviation="1.5" result="blur"/><feMerge><feMergeNode in="blur"/><feMergeNode in="SourceGraphic"/></feMerge></filter>
        </defs>
        <!-- Crack network radiating from center -->
        <g filter="url(#crackGlow)" stroke="rgba(253,230,138,0.95)" stroke-linecap="round">
          <path id="crack1" d="M90 95 L78 112 L70 108" stroke-width="1.8" stroke-dasharray="1" stroke-dashoffset="1"/>
          <path id="crack2" d="M90 95 L98 118 L106 112 L112 125" stroke-width="1.6" stroke-dasharray="1" stroke-dashoffset="1"/>
          <path id="crack3" d="M90 95 L88 82 L80 78" stroke-width="1.4" stroke-dasharray="1" stroke-dashoffset="1"/>
          <path id="crack4" d="M90 95 L95 85 L104 80" stroke-width="1.3" stroke-dasharray="1" stroke-dashoffset="1"/>
          <path id="crack5" d="M78 112 L65 120 L60 132" stroke-width="1.2" stroke-dasharray="1" stroke-dashoffset="1"/>
          <path id="crack6" d="M98 118 L102 135 L94 145" stroke-width="1.2" stroke-dasharray="1" stroke-dashoffset="1"/>
        </g>
        <!-- Impact flash -->
        <circle id="crackFlashCirc" cx="90" cy="95" r="22" fill="rgba(253,230,138,0.22)" opacity="0"/>
      </svg>
      <!-- Shell halves flying apart -->
      <svg id="eggShellLeft" viewBox="0 0 180 220" fill="none" xmlns="http://www.w3.org/2000/svg">
        <defs>
          <clipPath id="leftHalf"><rect x="0" y="0" width="90" height="220"/></clipPath>
        </defs>
        <ellipse cx="90" cy="115" rx="56" ry="74" fill="url(#hEgg)" clip-path="url(#leftHalf)" opacity="0.9"/>
        <ellipse cx="90" cy="115" rx="56" ry="74" fill="none" stroke="rgba(253,230,138,0.45)" stroke-width="1.2" clip-path="url(#leftHalf)"/>
      </svg>
      <svg id="eggShellRight" viewBox="0 0 180 220" fill="none" xmlns="http://www.w3.org/2000/svg">
        <defs>
          <clipPath id="rightHalf"><rect x="90" y="0" width="90" height="220"/></clipPath>
        </defs>
        <ellipse cx="90" cy="115" rx="56" ry="74" fill="url(#hEgg)" clip-path="url(#rightHalf)" opacity="0.9"/>
      </svg>
      <!-- Moon revealed underneath -->
      <div id="moonRevealEl"></div>
      <!-- Star burst particles -->
      <svg id="starBurst" viewBox="0 0 340 340" fill="none" xmlns="http://www.w3.org/2000/svg" style="opacity:0"></svg>
    </div>
    <div class="tap-hint" id="hatchHint">✦ TAP TO CRACK THE EGG ✦</div>
    <div class="hatch-day3">LUNETTE IS READY TO HATCH</div>
  `;

  document.body.appendChild(overlay);

  let tapCount = 0;
  const MAX_TAPS = 3;
  const hint = overlay.querySelector('#hatchHint');
  const eggSvg = overlay.querySelector('#eggHatchSvg');
  const crackSvg = overlay.querySelector('#eggCrackSvg');
  const shellLeft = overlay.querySelector('#eggShellLeft');
  const shellRight = overlay.querySelector('#eggShellRight');
  const moonEl = overlay.querySelector('#moonRevealEl');
  const starBurstSvg = overlay.querySelector('#starBurst');
  const stage = overlay.querySelector('#eggHatchStage');

  function buildStarBurst() {
    const colors = ['#c084fc','#a855f7','#e9d5ff','#fde68a','#f9a8d4','#93c5fd'];
    const particles = [];
    for (let i = 0; i < 24; i++) {
      const angle = (i / 24) * Math.PI * 2;
      const dist = 90 + Math.random() * 70;
      const sx = (Math.cos(angle) * dist).toFixed(1);
      const sy = (Math.sin(angle) * dist).toFixed(1);
      const color = colors[i % colors.length];
      const r = (2 + Math.random() * 4).toFixed(1);
      const delay = (Math.random() * 0.25).toFixed(2);
      particles.push(`<circle cx="170" cy="170" r="${r}" fill="${color}"
        style="--sx:${sx}px;--sy:${sy}px; animation:starsExplode 0.9s ${delay}s cubic-bezier(0.2,0,0.8,1) both"/>`);
    }
    // Also a few diamond shapes
    for (let i = 0; i < 8; i++) {
      const angle = (i / 8) * Math.PI * 2 + 0.3;
      const dist = 110 + Math.random() * 50;
      const sx = (Math.cos(angle) * dist).toFixed(1);
      const sy = (Math.sin(angle) * dist).toFixed(1);
      const color = colors[i % 3];
      const s2 = (3 + Math.random() * 3).toFixed(1);
      const delay = (Math.random() * 0.3).toFixed(2);
      particles.push(`<rect x="${170 - s2/2}" y="${170 - s2/2}" width="${s2}" height="${s2}" fill="${color}"
        transform="rotate(45 170 170)"
        style="--sx:${sx}px;--sy:${sy}px; animation:starsExplode 1.1s ${delay}s cubic-bezier(0.2,0,0.8,1) both"/>`);
    }
    starBurstSvg.innerHTML = particles.join('');
  }

  function animateCrackPaths(svg, callback) {
    const paths = svg.querySelectorAll('path');
    paths.forEach((p, i) => {
      const len = p.getTotalLength ? p.getTotalLength() : 40;
      p.style.strokeDasharray = len;
      p.style.strokeDashoffset = len;
      p.style.transition = `stroke-dashoffset ${0.18 + i * 0.06}s ease-out ${i * 0.04}s`;
      requestAnimationFrame(() => { p.style.strokeDashoffset = 0; });
    });
    const flash = svg.querySelector('#crackFlashCirc');
    if (flash) {
      flash.style.animation = 'crackFlash 0.35s ease-out both';
    }
    setTimeout(callback, 400);
  }

  function doTap() {
    tapCount++;

    if (tapCount === 1) {
      // First tap: wobble + show first cracks
      stage.style.animation = 'eggWobble 0.5s ease-in-out';
      crackSvg.style.opacity = '1';
      crackSvg.style.transition = 'opacity 0.1s';
      // Reveal first 2 cracks
      const paths = crackSvg.querySelectorAll('path');
      [paths[0], paths[1]].forEach((p, i) => {
        const len = p.getTotalLength ? p.getTotalLength() : 30;
        p.style.strokeDasharray = len;
        p.style.strokeDashoffset = len;
        setTimeout(() => {
          p.style.transition = `stroke-dashoffset 0.22s ease-out`;
          p.style.strokeDashoffset = 0;
        }, i * 50);
      });
      eggSvg.style.filter = 'drop-shadow(0 0 18px rgba(253,230,138,0.8))';
      hint.textContent = '✦ TAP AGAIN ✦';
      setTimeout(() => { stage.style.animation = ''; }, 500);

    } else if (tapCount === 2) {
      // Second tap: shake + more cracks
      stage.style.animation = 'eggShake 0.4s ease-in-out';
      const paths = crackSvg.querySelectorAll('path');
      [paths[2], paths[3], paths[4]].forEach((p, i) => {
        const len = p.getTotalLength ? p.getTotalLength() : 30;
        p.style.strokeDasharray = len;
        p.style.strokeDashoffset = len;
        setTimeout(() => {
          p.style.transition = `stroke-dashoffset 0.20s ease-out`;
          p.style.strokeDashoffset = 0;
        }, i * 40);
      });
      eggSvg.style.filter = 'drop-shadow(0 0 28px rgba(253,230,138,1)) drop-shadow(0 0 60px rgba(168,85,247,0.5))';
      hint.textContent = '✦ ONE MORE! ✦';
      hint.style.color = 'rgba(168,85,247,0.9)';
      setTimeout(() => { stage.style.animation = ''; }, 400);

    } else if (tapCount >= MAX_TAPS) {
      // Third tap: HATCH!
      overlay.removeEventListener('click', doTap);
      hint.style.animation = 'none';
      hint.style.opacity = '0';

      // Final crack
      const paths = crackSvg.querySelectorAll('path');
      [paths[5]].forEach(p => {
        const len = p.getTotalLength ? p.getTotalLength() : 30;
        p.style.strokeDasharray = len;
        p.style.strokeDashoffset = len;
        p.style.transition = 'stroke-dashoffset 0.15s ease-out';
        p.style.strokeDashoffset = 0;
      });

      // Big flash
      const flash = crackSvg.querySelector('#crackFlashCirc');
      if (flash) {
        flash.style.r = '60';
        flash.style.animation = 'crackFlash 0.4s ease-out both';
      }

      setTimeout(() => {
        // Hide egg, show shell halves flying apart
        eggSvg.style.transition = 'opacity 0.15s';
        eggSvg.style.opacity = '0';
        crackSvg.style.opacity = '0';

        shellLeft.style.opacity = '1';
        shellRight.style.opacity = '1';
        shellLeft.style.animation  = 'shellHalf 0.55s cubic-bezier(0.2,0,0.8,1) forwards';
        shellRight.style.animation = 'shellHalf 0.55s cubic-bezier(0.2,0,0.8,1) forwards';
        shellLeft.style.setProperty('--shell-dest',  'translate(-60px, -30px) rotate(-35deg)');
        shellRight.style.setProperty('--shell-dest', 'translate(60px, -25px) rotate(30deg)');

        // Build + fire stars
        buildStarBurst();
        setTimeout(() => {
          starBurstSvg.style.opacity = '1';
          starBurstSvg.style.transition = 'none';
        }, 80);

        // Reveal crescent moon underneath
        setTimeout(() => {
          moonEl.style.opacity = '0';
          moonEl.innerHTML = getStreakMoonSVG('lunette', 140);
          const svgEl = moonEl.querySelector('svg');
          if (svgEl) { svgEl.style.width = '140px'; svgEl.style.height = '140px'; }
          moonEl.style.animation = 'moonReveal 0.7s cubic-bezier(0.34,1.46,0.64,1) both';
          moonEl.style.opacity = '1';
          moonEl.style.filter = 'drop-shadow(0 0 40px rgba(168,85,247,0.9))';
          moonEl.style.setProperty('animation', 'moonReveal 0.7s cubic-bezier(0.34,1.46,0.64,1) both, moonGlowPulse 2.4s ease-in-out 0.7s infinite');

          hint.textContent = '✦ LUNETTE AWAKENS ✦';
          hint.style.color = '#c084fc';
          hint.style.fontSize = '13px';
          hint.style.animation = 'tapHint 1.6s ease-in-out infinite';
          hint.style.opacity = '1';
        }, 220);

        // Close overlay after celebration
        setTimeout(() => {
          overlay.style.animation = 'hatchOverlayOut 0.5s cubic-bezier(0.4,0,1,1) forwards';
          setTimeout(() => {
            overlay.remove();
            renderStreakUI();
            if (typeof onComplete === 'function') onComplete();
          }, 480);
        }, 2800);

      }, 180);
    }
  }

  overlay.addEventListener('click', doTap);
}

function openStreakSheet() {
  const data     = loadStreakData();
  if (!data || !data.days) return;

  const tier     = getTierForDays(data.days);
  const progress = getTierProgress(data.days);
  const toNext   = getDaysToNextTier(data.days);
  const nextTier = getNextTier(tier.id);
  const mood     = (typeof lunaMood !== 'undefined') ? lunaMood : 'chill';

  const sheet = document.getElementById('streakSheet');
  const panel = document.getElementById('ssPanel');
  if (!sheet) return;

  // Set tier CSS variable on panel
  panel.setAttribute('data-streak-tier', tier.id);
  panel.setAttribute('data-mood', mood);
  panel.style.setProperty('--sdc',  tier.color);
  panel.style.setProperty('--sdc2', tier.color2);

  // ── Moon SVG: use mood moon if available, else streak-tier moon ──
  const moonEl = document.getElementById('ssMoonSvg');
  if (moonEl) {
    const moodSvg = (typeof getMoodMoonSVG === 'function') ? getMoodMoonSVG(mood, 90) : null;
    moonEl.innerHTML = moodSvg || getStreakMoonSVG(tier.id, 90);
  }

  // Tier name / sub
  const tn = document.getElementById('ssTierName');
  if (tn) { tn.textContent = tier.name; tn.style.color = tier.color; }
  const ts = document.getElementById('ssTierSub');
  if (ts) ts.textContent = tier.sub;

  // ── Mood badge ──
  const moodLabels = { chill:'CHILL · NEW MOON', empathic:'EMPATHIC · CHESHIRE MOON', smart:'SMART · GALACTIC MOON', tense:'TENSE · BLOOD MOON' };
  const moodColors = { chill:'rgba(148,163,184,0.9)', empathic:'#8b5cf6', smart:'#22d3ee', tense:'#ef4444' };
  const moodDot  = document.getElementById('ssMoodDot');
  const moodLbl  = document.getElementById('ssMoodLabel');
  if (moodDot) moodDot.style.background = moodColors[mood] || tier.color;
  if (moodLbl) moodLbl.textContent = moodLabels[mood] || mood.toUpperCase();

  // Days big
  const db = document.getElementById('ssDaysBig');
  if (db) { db.textContent = data.days; db.style.color = tier.color; }

  // Progress
  const pf = document.getElementById('ssProgFill');
  if (pf) setTimeout(() => { pf.style.width = progress + '%'; }, 80);

  const pn = document.getElementById('ssProgNext');
  if (pn) {
    if (toNext) {
      pn.textContent = `${toNext} day${toNext !== 1 ? 's' : ''} to ${nextTier ? nextTier.name : ''}`;
    } else {
      pn.textContent = 'MAX TIER REACHED ✦';
    }
    pn.style.color = tier.color;
  }

  // ── Roadmap: active tier shows mood moon, others show streak moon ──
  const roadmap = document.getElementById('ssRoadmap');
  if (roadmap) {
    roadmap.innerHTML = STREAK_TIERS.map(t => {
      const isDone   = data.days > t.maxDay;
      const isActive = t.id === tier.id;
      const cls      = isActive ? 'ss-rm-item rm-active' : isDone ? 'ss-rm-item rm-done' : 'ss-rm-item';
      const iconSize = isActive ? 36 : 26;
      const moonHtml = isActive && typeof getMoodMoonSVG === 'function'
        ? (getMoodMoonSVG(mood, iconSize) || getStreakMoonSVG(t.id, iconSize))
        : getStreakMoonSVG(t.id, iconSize);
      return `<div class="${cls}">
        <div class="ss-rm-moon" style="width:${iconSize}px;height:${iconSize}px">${moonHtml}</div>
        <div class="ss-rm-label">${t.name}<br/>${t.minDay}${t.maxDay < Infinity ? '–' + t.maxDay : '+'}d</div>
      </div>`;
    }).join('');
  }

  // ── Egg Enhancements panel (injected once, updated on each open) ──
  let enhEl = document.getElementById('ssEggEnhancements');
  if (!enhEl) {
    enhEl = document.createElement('div');
    enhEl.id = 'ssEggEnhancements';
    enhEl.style.cssText = 'position:relative;z-index:1;margin-bottom:0;';
    // Insert before the close row
    const closeRow = panel.querySelector('.ss-close-row');
    if (closeRow) panel.insertBefore(enhEl, closeRow);
    else panel.appendChild(enhEl);
  }

  const glowSaved  = (() => { try { return localStorage.getItem('luna-egg-glow')  || '0.55'; } catch { return '0.55'; } })();
  // Egg size/scale feature removed
  const floatOn    = (() => { try { return JSON.parse(localStorage.getItem('luna-egg-float') ?? 'true'); } catch { return true; } })();
  const labelOn    = (() => { try { return JSON.parse(localStorage.getItem('luna-egg-label') ?? 'true'); } catch { return true; } })();

  const tc = tier.color;
  const tc2 = tier.color2 || tier.color;

  // Styled to match the streak sheet's existing design language
  enhEl.innerHTML = `
    <div style="
      margin: 0 0 22px;
      background: linear-gradient(135deg, rgba(255,255,255,0.025) 0%, rgba(255,255,255,0.008) 100%);
      border: 1px solid rgba(255,255,255,0.07);
      border-radius: 18px;
      overflow: hidden;
    ">
      <!-- Section header -->
      <div style="
        display: flex; align-items: center; gap: 8px;
        padding: 13px 16px 11px;
        border-bottom: 1px solid rgba(255,255,255,0.06);
        background: linear-gradient(90deg, rgba(255,255,255,0.03) 0%, transparent 100%);
      ">
        <div style="
          width: 3px; height: 14px; border-radius: 2px;
          background: linear-gradient(to bottom, ${tc}, ${tc2});
          box-shadow: 0 0 8px ${tc}88;
          flex-shrink: 0;
        "></div>
        <span style="font-family:var(--font-hud);font-size:8.5px;letter-spacing:0.22em;color:${tc};text-shadow:0 0 12px ${tc}66;">EGG ENHANCEMENTS</span>
      </div>

      <!-- Rows -->
      <div style="padding: 4px 0;">

        <!-- Glow Intensity -->
        <div style="display:flex;align-items:center;justify-content:space-between;gap:10px;padding:11px 16px;border-bottom:1px solid rgba(255,255,255,0.04);">
          <div>
            <div style="font-family:var(--font-hud);font-size:9px;letter-spacing:0.12em;color:var(--text-hi);">Glow Intensity</div>
            <div style="font-family:var(--font-body);font-size:10px;color:var(--text-lo);margin-top:2px;">Pulse halo brightness</div>
          </div>
          <div style="display:flex;gap:5px;flex-shrink:0;">
            ${[['SUBTLE','0.30'],['NORMAL','0.55'],['INTENSE','0.85']].map(([lbl,val]) => {
              const on = glowSaved === val;
              return `<button class="ss-enh-glow-btn" onclick="
                localStorage.setItem('luna-egg-glow','${val}');
                const pill=document.getElementById('streakPill');
                if(pill) pill.style.setProperty('--egg-glow-alpha','${val}');
                document.querySelectorAll('.ss-enh-glow-btn').forEach(b=>{ b.setAttribute('data-active','0'); b.style.cssText=b.dataset.off; });
                this.setAttribute('data-active','1'); this.style.cssText=this.dataset.on;
                showToast('✦ Glow: ${lbl.toLowerCase()}','✨',1400);
              "
              data-off="padding:5px 10px;font-family:var(--font-hud);font-size:7.5px;letter-spacing:0.11em;border-radius:20px;cursor:pointer;transition:all 0.18s;background:rgba(255,255,255,0.04);border:1.5px solid rgba(255,255,255,0.09);color:rgba(255,255,255,0.30);"
              data-on="padding:5px 10px;font-family:var(--font-hud);font-size:7.5px;letter-spacing:0.11em;border-radius:20px;cursor:pointer;transition:all 0.18s;background:linear-gradient(135deg,rgba(168,85,247,0.25),rgba(236,45,90,0.15));border:1.5px solid rgba(168,85,247,0.55);color:var(--violet-bright);box-shadow:0 0 10px rgba(168,85,247,0.25);"
              style="padding:5px 10px;font-family:var(--font-hud);font-size:7.5px;letter-spacing:0.11em;border-radius:20px;cursor:pointer;transition:all 0.18s;${on
                ? 'background:linear-gradient(135deg,rgba(168,85,247,0.25),rgba(236,45,90,0.15));border:1.5px solid rgba(168,85,247,0.55);color:var(--violet-bright);box-shadow:0 0 10px rgba(168,85,247,0.25);'
                : 'background:rgba(255,255,255,0.04);border:1.5px solid rgba(255,255,255,0.09);color:rgba(255,255,255,0.30);'
              }">${lbl}</button>`;
            }).join('')}
          </div>
        </div>

        <!-- Float Animation -->
        <div style="display:flex;align-items:center;justify-content:space-between;gap:10px;padding:11px 16px;border-bottom:1px solid rgba(255,255,255,0.04);">
          <div>
            <div style="font-family:var(--font-hud);font-size:9px;letter-spacing:0.12em;color:var(--text-hi);">Float Animation</div>
            <div style="font-family:var(--font-body);font-size:10px;color:var(--text-lo);margin-top:2px;">Gentle bobbing of the egg</div>
          </div>
          <button id="ssEggFloatBtn" onclick="
            const pill = document.getElementById('streakPill');
            if (!pill) return;
            const off = pill.classList.toggle('sp-no-float');
            localStorage.setItem('luna-egg-float', JSON.stringify(!off));
            const onStyle = 'background:linear-gradient(135deg,rgba(168,85,247,0.25),rgba(236,45,90,0.15));border:1.5px solid rgba(168,85,247,0.55);color:var(--violet-bright);box-shadow:0 0 10px rgba(168,85,247,0.25);';
            const offStyle = 'background:rgba(255,255,255,0.04);border:1.5px solid rgba(255,255,255,0.09);color:rgba(255,255,255,0.30);box-shadow:none;';
            this.textContent = off ? 'OFF' : 'ON';
            this.style.cssText = 'flex-shrink:0;min-width:54px;padding:6px 0;font-family:var(--font-hud);font-size:8px;letter-spacing:0.14em;border-radius:20px;cursor:pointer;transition:all 0.2s;' + (off ? offStyle : onStyle);
            showToast(off ? '🥚 Float paused' : '🥚 Float on','🥚',1400);
          " style="flex-shrink:0;min-width:54px;padding:6px 0;font-family:var(--font-hud);font-size:8px;letter-spacing:0.14em;border-radius:20px;cursor:pointer;transition:all 0.2s;${floatOn
            ? 'background:linear-gradient(135deg,rgba(168,85,247,0.25),rgba(236,45,90,0.15));border:1.5px solid rgba(168,85,247,0.55);color:var(--violet-bright);box-shadow:0 0 10px rgba(168,85,247,0.25);'
            : 'background:rgba(255,255,255,0.04);border:1.5px solid rgba(255,255,255,0.09);color:rgba(255,255,255,0.30);'
          }">${floatOn ? 'ON' : 'OFF'}</button>
        </div>


        <!-- Mood Label -->
        <div style="display:flex;align-items:center;justify-content:space-between;gap:10px;padding:11px 16px;border-bottom:1px solid rgba(255,255,255,0.04);">
          <div>
            <div style="font-family:var(--font-hud);font-size:9px;letter-spacing:0.12em;color:var(--text-hi);">Mood Label</div>
            <div style="font-family:var(--font-body);font-size:10px;color:var(--text-lo);margin-top:2px;">Moon name below egg</div>
          </div>
          <button id="ssEggLabelBtn" onclick="
            const pill = document.getElementById('streakPill');
            const lbl  = document.getElementById('spPillName');
            if (!pill || !lbl) return;
            const hidden = lbl.style.display === 'none';
            lbl.style.display = hidden ? '' : 'none';
            localStorage.setItem('luna-egg-label', JSON.stringify(hidden));
            const onStyle = 'background:linear-gradient(135deg,rgba(168,85,247,0.25),rgba(236,45,90,0.15));border:1.5px solid rgba(168,85,247,0.55);color:var(--violet-bright);box-shadow:0 0 10px rgba(168,85,247,0.25);';
            const offStyle = 'background:rgba(255,255,255,0.04);border:1.5px solid rgba(255,255,255,0.09);color:rgba(255,255,255,0.30);box-shadow:none;';
            this.textContent = hidden ? 'ON' : 'OFF';
            this.style.cssText = 'flex-shrink:0;min-width:54px;padding:6px 0;font-family:var(--font-hud);font-size:8px;letter-spacing:0.14em;border-radius:20px;cursor:pointer;transition:all 0.2s;' + (hidden ? onStyle : offStyle);
          " style="flex-shrink:0;min-width:54px;padding:6px 0;font-family:var(--font-hud);font-size:8px;letter-spacing:0.14em;border-radius:20px;cursor:pointer;transition:all 0.2s;${labelOn
            ? 'background:linear-gradient(135deg,rgba(168,85,247,0.25),rgba(236,45,90,0.15));border:1.5px solid rgba(168,85,247,0.55);color:var(--violet-bright);box-shadow:0 0 10px rgba(168,85,247,0.25);'
            : 'background:rgba(255,255,255,0.04);border:1.5px solid rgba(255,255,255,0.09);color:rgba(255,255,255,0.30);'
          }">${labelOn ? 'ON' : 'OFF'}</button>
        </div>

        <!-- Pet Behavior Info -->
        <div style="display:flex;align-items:center;justify-content:space-between;gap:10px;padding:11px 16px;">
          <div>
            <div style="font-family:var(--font-hud);font-size:9px;letter-spacing:0.12em;color:var(--text-hi);">Pet Behavior</div>
            <div style="font-family:var(--font-body);font-size:10px;color:var(--text-lo);margin-top:2px;">Unlocks as your streak grows ✦</div>
          </div>
          <span style="flex-shrink:0;padding:5px 10px;font-family:var(--font-hud);font-size:7.5px;letter-spacing:0.11em;border-radius:20px;background:linear-gradient(135deg,rgba(168,85,247,0.25),rgba(236,45,90,0.15));border:1.5px solid rgba(168,85,247,0.55);color:var(--violet-bright);">DAY ${data ? data.days : '?'}</span>
        </div>

      </div>
    </div>
  `;

  sheet.classList.add('ss-open');
  document.body.style.overflow = 'hidden';
}

function closeStreakSheet() {
  const sheet = document.getElementById('streakSheet');
  const panel = document.getElementById('ssPanel');
  if (!sheet || !panel) return;
  panel.classList.add('ss-closing');
  panel.addEventListener('animationend', () => {
    panel.classList.remove('ss-closing');
    sheet.classList.remove('ss-open');
    document.body.style.overflow = '';
    // Reset progress bar so it animates next open
    const pf = document.getElementById('ssProgFill');
    if (pf) pf.style.width = '0%';
  }, { once: true });
}

// ── Admin leaderboard ─────────────────────────────────────────────
async function refreshStreakLeaderboard() {
  const el = document.getElementById('streakLeaderboardList');
  if (!el) return;
  if (!firebaseReady || !firebaseDb) {
    el.innerHTML = '<div class="admin-empty">◈ Firebase not available.</div>'; return;
  }
  el.innerHTML = '<div class="admin-empty">◈ Loading streak data…</div>';
  try {
    const snap     = await firebaseDb.ref('luna-accounts').once('value');
    const accounts = snap.val() || {};
    const rows     = Object.entries(accounts)
      .filter(([, acc]) => acc.streak && acc.streak.days > 0)
      .map(([, acc]) => ({ name: acc.name || '—', ...acc.streak }))
      .sort((a, b) => (b.days || 0) - (a.days || 0));

    if (!rows.length) {
      el.innerHTML = '<div class="admin-empty">◈ No streak data yet.</div>'; return;
    }

    el.innerHTML = rows.map((r, i) => {
      const tier     = getTierForDays(r.days || 0);
      const medal    = i === 0 ? '🥇' : i === 1 ? '🥈' : i === 2 ? '🥉' : `#${i + 1}`;
      const isStale  = r.lastDate && (Date.now() - new Date(r.lastDate).getTime()) > 172800000;
      const statusBadge = isStale
        ? `<span class="slb-tier" style="color:var(--crimson-bright);border-color:rgba(236,45,90,0.3);">INACTIVE</span>`
        : `<span class="slb-tier" style="color:var(--green);border-color:rgba(52,211,153,0.3);">ACTIVE</span>`;
      return `<div class="streak-lb-row">
        <span class="slb-rank">${medal}</span>
        <span class="slb-moon">${tier.emoji}</span>
        <span class="slb-name">◈ ${escHtml(r.name)}</span>
        <span class="slb-days" style="color:${tier.color}">${r.days} <span style="font-size:8px;opacity:0.6;font-family:var(--font-hud);">DAYS</span></span>
        <span class="slb-tier" style="color:${tier.color};border-color:${tier.color}44;">${tier.name}</span>
        ${statusBadge}
      </div>`;
    }).join('');
  } catch(e) {
    el.innerHTML = `<div class="admin-empty">◈ Failed: ${e.message}</div>`;
  }
}

// ── Hook into enterChat ───────────────────────────────────────────
const _origEnterChat = enterChat;
enterChat = async function(name, key, isGuest = false) {
  await _origEnterChat(name, key, isGuest);
  // Small delay so UI is settled before streak renders
  setTimeout(() => {
    const data = computeStreak();
    if (data && data.days > 0) {
      // Initialize egg-born timestamp on the very first day if not set
      if (data.days === 1) {
        try {
          if (!localStorage.getItem(_eggBornKey())) {
            localStorage.setItem(_eggBornKey(), String(Date.now()));
          }
        } catch {}
      }
      renderStreakUI();
      // If day 3 just reached (lunova→lunette), show the hatch animation
      if (shouldShowHatchAnimation()) {
        setTimeout(() => showEggHatchOverlay(), 1200);
      }
      // Check frozen / rotten state
      setTimeout(checkStreakState, 600);
    }
  }, 800);
};

// ╔══════════════════════════════════════════════════════════════════════╗
// ║       LUNA AI — ADMIN PANEL ENHANCEMENTS v1.0                        ║
// ║  7 new features: Analytics · System Prompt · MOTD · User Manager     ║
// ║  AI Config · AutoMod Tuner · Token Limiter                           ║
// ║                                                                       ║
// ║  HOW TO USE:                                                          ║
// ║  1. Include this file AFTER script.js in your index.html:            ║
// ║     <script src="admin-enhancements.js"></script>                     ║
// ║  2. Paste the HTML block below into your adminPanel's admin-body div  ║
// ║     (right before the closing </div> of admin-body)                   ║
// ╚══════════════════════════════════════════════════════════════════════╝

// ══════════════════════════════════════════════════════════════════
// ◈ FEATURE 1 — ANALYTICS DASHBOARD
//   Shows message volume, active users by day, top users by count
// ══════════════════════════════════════════════════════════════════

async function loadAdminAnalytics() {
  const el = document.getElementById('adminAnalyticsPanel');
  if (!el) return;
  el.innerHTML = '<div class="admin-empty">◈ Loading analytics…</div>';

  if (!firebaseReady || !firebaseDb) {
    el.innerHTML = '<div class="admin-empty">◈ Firebase offline.</div>';
    return;
  }

  try {
    const [chatSnap, accountSnap, presenceSnap] = await Promise.all([
      firebaseDb.ref('luna-chat-log').once('value'),
      firebaseDb.ref('luna-accounts').once('value'),
      firebaseDb.ref('luna-presence').once('value'),
    ]);

    const messages  = chatSnap.val()    ? Object.values(chatSnap.val())    : [];
    const accounts  = accountSnap.val() ? Object.values(accountSnap.val()) : [];
    const presence  = presenceSnap.val()? Object.values(presenceSnap.val()): [];

    // Basic counts
    const totalMsgs   = messages.length;
    const userMsgs    = messages.filter(m => m.role !== 'assistant').length;
    const lunaMsgs    = messages.filter(m => m.role === 'assistant').length;
    const totalAccts  = accounts.length;
    const onlineNow   = presence.filter(p => p.online).length;

    // Messages per day (last 7 days)
    const now        = Date.now();
    const dayMs      = 86400000;
    const dayBuckets = {};
    for (let i = 6; i >= 0; i--) {
      const d = new Date(now - i * dayMs);
      const key = `${d.getMonth()+1}/${d.getDate()}`;
      dayBuckets[key] = 0;
    }
    messages.forEach(m => {
      if (!m.ts) return;
      const d   = new Date(m.ts);
      const key = `${d.getMonth()+1}/${d.getDate()}`;
      if (key in dayBuckets) dayBuckets[key]++;
    });

    const maxDay = Math.max(...Object.values(dayBuckets), 1);

    // Top users by message count
    const userCounts = {};
    messages.filter(m => m.role !== 'assistant' && m.user).forEach(m => {
      userCounts[m.user] = (userCounts[m.user] || 0) + 1;
    });
    const topUsers = Object.entries(userCounts)
      .sort((a, b) => b[1] - a[1])
      .slice(0, 5);

    el.innerHTML = `
      <!-- ◈ Overview Stats -->
      <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(130px,1fr));gap:10px;margin-bottom:18px;">
        ${[
          ['💬', 'TOTAL MSGS',    totalMsgs,  'var(--violet-bright)'],
          ['👤', 'USER MSGS',     userMsgs,   'var(--cyan)'],
          ['◈',  'LUNA REPLIES',  lunaMsgs,   'var(--crimson-bright)'],
          ['🔑', 'ACCOUNTS',      totalAccts, 'var(--gold)'],
          ['🟢', 'ONLINE NOW',    onlineNow,  'var(--green)'],
        ].map(([icon, label, val, color]) => `
          <div style="background:rgba(0,0,0,0.3);border:1px solid var(--border);border-radius:10px;padding:12px 14px;text-align:center;">
            <div style="font-size:18px;margin-bottom:4px;">${icon}</div>
            <div style="font-family:var(--font-hud);font-size:18px;font-weight:900;color:${color};line-height:1;">${val}</div>
            <div style="font-family:var(--font-hud);font-size:7.5px;letter-spacing:0.14em;color:var(--text-lo);margin-top:3px;">${label}</div>
          </div>
        `).join('')}
      </div>

      <!-- ◈ 7-Day Bar Chart -->
      <div style="font-family:var(--font-hud);font-size:8.5px;letter-spacing:0.14em;color:var(--text-lo);margin-bottom:10px;">◈ MESSAGES — LAST 7 DAYS</div>
      <div style="display:flex;align-items:flex-end;gap:6px;height:64px;margin-bottom:6px;">
        ${Object.entries(dayBuckets).map(([day, count]) => {
          const h = Math.max(4, Math.round((count / maxDay) * 60));
          const isToday = (() => {
            const d = new Date(); return `${d.getMonth()+1}/${d.getDate()}` === day;
          })();
          return `<div style="flex:1;display:flex;flex-direction:column;align-items:center;gap:3px;">
            <div style="font-family:var(--font-hud);font-size:8px;color:var(--text-lo);">${count||''}</div>
            <div style="width:100%;height:${h}px;border-radius:4px 4px 0 0;
              background:${isToday ? 'linear-gradient(180deg,var(--violet-bright),var(--violet))' : 'rgba(168,85,247,0.25)'};
              box-shadow:${isToday ? '0 0 8px rgba(168,85,247,0.45)' : 'none'};
              transition:height 0.5s ease;"></div>
          </div>`;
        }).join('')}
      </div>
      <div style="display:flex;gap:6px;">
        ${Object.keys(dayBuckets).map(day => `
          <div style="flex:1;text-align:center;font-family:var(--font-hud);font-size:7px;letter-spacing:0.08em;color:var(--text-lo);">${day}</div>
        `).join('')}
      </div>

      <!-- ◈ Top Users -->
      ${topUsers.length ? `
        <div style="font-family:var(--font-hud);font-size:8.5px;letter-spacing:0.14em;color:var(--text-lo);margin:16px 0 8px;">◈ TOP USERS BY MESSAGE COUNT</div>
        ${topUsers.map(([name, cnt], i) => {
          const pct = Math.round(cnt / userMsgs * 100);
          const medals = ['🥇','🥈','🥉','#4','#5'];
          return `<div style="display:flex;align-items:center;gap:10px;padding:7px 0;border-bottom:1px solid rgba(255,255,255,0.04);">
            <span style="font-size:13px;width:20px;">${medals[i]}</span>
            <span style="flex:1;font-family:var(--font-body);font-size:12px;color:var(--text-hi);">◈ ${escHtml(name)}</span>
            <div style="width:80px;height:4px;background:rgba(255,255,255,0.07);border-radius:4px;overflow:hidden;">
              <div style="height:100%;width:${pct}%;background:linear-gradient(90deg,var(--violet),var(--violet-bright));border-radius:4px;"></div>
            </div>
            <span style="font-family:var(--font-hud);font-size:9px;color:var(--text-mid);min-width:32px;text-align:right;">${cnt}</span>
          </div>`;
        }).join('')}
      ` : '<div class="admin-empty">◈ No user messages yet.</div>'}

      <!-- ◈ Export Button -->
      <div style="margin-top:12px;text-align:right;">
        <button onclick="exportAnalyticsCSV()" class="admin-add-btn" style="font-size:8.5px;">⬇ EXPORT CSV</button>
      </div>
    `;
  } catch(e) {
    el.innerHTML = `<div class="admin-empty">◈ Failed: ${e.message}</div>`;
  }
}

async function exportAnalyticsCSV() {
  if (!firebaseReady || !firebaseDb) { showToast('Firebase offline', '⚠️'); return; }
  const snap = await firebaseDb.ref('luna-chat-log').once('value');
  const messages = snap.val() ? Object.values(snap.val()) : [];
  const rows = [['Timestamp','Role','User','Preview']];
  messages.forEach(m => {
    rows.push([
      m.ts ? new Date(m.ts).toLocaleString() : '',
      m.role || '',
      m.user || '',
      (m.text || '').replace(/,/g, ';').slice(0, 120),
    ]);
  });
  const csv  = rows.map(r => r.map(c => `"${c}"`).join(',')).join('\n');
  const blob = new Blob([csv], { type:'text/csv' });
  const a    = Object.assign(document.createElement('a'), { href: URL.createObjectURL(blob), download: `luna-analytics-${Date.now()}.csv` });
  a.click();
  showToast('Analytics exported ✦', '⬇', 2000);
}


// ══════════════════════════════════════════════════════════════════
// ◈ FEATURE 2 — SYSTEM PROMPT EDITOR
//   Admin can live-edit LUNA's system prompt and push it to Firebase.
//   All connected sessions read it on their next message.
// ══════════════════════════════════════════════════════════════════

let _customSystemPrompt = null; // null = use built-in LUNA_SYSTEM_PROMPT

async function loadCustomSystemPrompt() {
  if (!firebaseReady || !firebaseDb) return;
  try {
    const snap = await firebaseDb.ref('luna-config/systemPrompt').once('value');
    const val  = snap.val();
    if (val && val.trim()) {
      _customSystemPrompt = val.trim();
    }
  } catch {}
}

// Watch for live changes pushed by admin
function watchCustomSystemPrompt() {
  if (!firebaseReady || !firebaseDb) return;
  firebaseDb.ref('luna-config/systemPrompt').on('value', snap => {
    const val = snap.val();
    _customSystemPrompt = (val && val.trim()) ? val.trim() : null;
  });
}

async function saveCustomSystemPrompt() {
  const ta  = document.getElementById('sysPromptEditor');
  const msg = document.getElementById('sysPromptMsg');
  if (!ta || !msg) return;
  const text = ta.value.trim();
  if (!text) { msg.textContent = '◈ Prompt cannot be empty.'; msg.style.color = 'var(--crimson-bright)'; return; }
  if (!firebaseReady || !firebaseDb) { msg.textContent = '◈ Firebase offline.'; msg.style.color = 'var(--crimson-bright)'; return; }
  try {
    await firebaseDb.ref('luna-config/systemPrompt').set(text);
    msg.textContent = '◈ System prompt updated — all sessions will use it on next message. ✦';
    msg.style.color = 'var(--green)';
    setTimeout(() => { msg.textContent = ''; }, 4000);
  } catch(e) {
    msg.textContent = '◈ Failed: ' + e.message;
    msg.style.color = 'var(--crimson-bright)';
  }
}

async function resetSystemPrompt() {
  if (!firebaseReady || !firebaseDb) { showToast('Firebase offline', '⚠️'); return; }
  if (!window.confirm('Reset system prompt to the built-in default?')) return;
  try {
    await firebaseDb.ref('luna-config/systemPrompt').remove();
    _customSystemPrompt = null;
    const ta  = document.getElementById('sysPromptEditor');
    if (ta) ta.value = '';
    showToast('◈ System prompt reset to default ✦', '🔄');
  } catch(e) {
    showToast('Failed: ' + e.message, '⚠️');
  }
}

function loadSysPromptIntoEditor() {
  const ta = document.getElementById('sysPromptEditor');
  if (!ta) return;
  if (_customSystemPrompt) {
    ta.value = _customSystemPrompt;
  } else {
    // Load the built-in prompt so admin can see it and edit from there
    ta.value = (typeof LUNA_SYSTEM_PROMPT !== 'undefined') ? LUNA_SYSTEM_PROMPT.trim() : '';
  }
}

// Patch buildSystemPromptWithStatuses to use admin-set prompt if present
(function patchSystemPrompt() {
  if (typeof buildSystemPromptWithStatuses !== 'function') return;
  const _orig = buildSystemPromptWithStatuses;
  buildSystemPromptWithStatuses = function() {
    if (!_customSystemPrompt) return _orig();
    // Replace only the LUNA_SYSTEM_PROMPT part, keep status blocks + memory
    let base = _customSystemPrompt;
    // Append status block if needed
    try {
      const result = _orig();
      // Extract the prefix (status block before "You are LUNA")
      const lunaIdx = result.indexOf('You are LUNA');
      if (lunaIdx > 0) {
        const statusPrefix = result.slice(0, lunaIdx);
        const suffix = result.slice(result.indexOf(_orig().split(LUNA_SYSTEM_PROMPT)[1] || ''));
        base = statusPrefix + base + (result.split(LUNA_SYSTEM_PROMPT)[1] || '');
      }
    } catch {}
    return base;
  };
})();


// ══════════════════════════════════════════════════════════════════
// ◈ FEATURE 3 — MESSAGE OF THE DAY (MOTD)
//   Admin sets a message that pops up for all users when they log in.
// ══════════════════════════════════════════════════════════════════

async function saveMOTD() {
  const inp = document.getElementById('motdInput');
  const msg = document.getElementById('motdMsg');
  if (!inp || !msg) return;
  const text = inp.value.trim();
  if (!firebaseReady || !firebaseDb) { msg.textContent = '◈ Firebase offline.'; msg.style.color = 'var(--crimson-bright)'; return; }
  try {
    if (text) {
      await firebaseDb.ref('luna-config/motd').set({ text, ts: Date.now(), by: userName || 'Admin' });
      msg.textContent = '◈ MOTD saved — users will see it on next login. ✦';
      msg.style.color = 'var(--green)';
    } else {
      await firebaseDb.ref('luna-config/motd').remove();
      msg.textContent = '◈ MOTD cleared.';
      msg.style.color = 'var(--text-lo)';
    }
    setTimeout(() => { msg.textContent = ''; }, 4000);
  } catch(e) {
    msg.textContent = '◈ Failed: ' + e.message;
    msg.style.color = 'var(--crimson-bright)';
  }
}

async function loadMOTDForEdit() {
  if (!firebaseReady || !firebaseDb) return;
  try {
    const snap = await firebaseDb.ref('luna-config/motd').once('value');
    const val  = snap.val();
    const inp  = document.getElementById('motdInput');
    if (inp && val && val.text) inp.value = val.text;
  } catch {}
}

// Called after user logs in — checks for MOTD and shows it
async function checkAndShowMOTD() {
  if (!firebaseReady || !firebaseDb) return;
  try {
    const snap = await firebaseDb.ref('luna-config/motd').once('value');
    const val  = snap.val();
    if (!val || !val.text) return;

    // Only show if the user hasn't dismissed this exact MOTD (track by ts)
    const dismissKey = `luna-motd-dismissed-${val.ts}`;
    if (localStorage.getItem(dismissKey)) return;

    // Show a styled banner at top of chat
    const banner = document.createElement('div');
    banner.id = 'motdBanner';
    banner.style.cssText = [
      'display:flex;align-items:flex-start;gap:12px;',
      'padding:14px 16px;margin:12px 0 0;',
      'background:linear-gradient(135deg,rgba(168,85,247,0.10),rgba(236,45,90,0.06));',
      'border:1px solid rgba(168,85,247,0.28);border-radius:12px;',
      'animation:fadeIn 0.4s ease both;',
    ].join('');
    banner.innerHTML = `
      <div style="font-size:20px;flex-shrink:0;margin-top:2px;">📣</div>
      <div style="flex:1;min-width:0;">
        <div style="font-family:var(--font-hud);font-size:8px;letter-spacing:0.18em;color:var(--violet-bright);margin-bottom:5px;">◈ SYSTEM MESSAGE</div>
        <div style="font-size:13px;color:var(--text-hi);line-height:1.6;">${escHtml(val.text)}</div>
        ${val.ts ? `<div style="font-family:var(--font-hud);font-size:7.5px;color:var(--text-lo);margin-top:5px;">Posted ${timeAgo(val.ts)}</div>` : ''}
      </div>
      <button onclick="
        localStorage.setItem('luna-motd-dismissed-${val.ts}', '1');
        this.closest('#motdBanner').remove();
      " style="flex-shrink:0;background:none;border:none;color:var(--text-lo);cursor:pointer;font-size:16px;padding:2px 4px;line-height:1;">✕</button>
    `;
    const feed = document.getElementById('chatFeed');
    if (feed) feed.prepend(banner);
  } catch {}
}

// Hook checkAndShowMOTD into enterChat
(function hookMOTD() {
  const _origEnter = typeof enterChat === 'function' ? enterChat : null;
  if (!_origEnter) { window.addEventListener('DOMContentLoaded', hookMOTD); return; }
  // Only wrap if not already wrapped
  if (enterChat._motdHooked) return;
  const _wrapped = async function(name, key, isGuest = false) {
    await _origEnter(name, key, isGuest);
    setTimeout(() => checkAndShowMOTD(), 900);
  };
  _wrapped._motdHooked = true;
  // enterChat is redefined in the streak hook in script.js; we let that happen naturally
  // and instead call checkAndShowMOTD from a custom event
})();


// ══════════════════════════════════════════════════════════════════
// ◈ FEATURE 4 — USER PROFILE MANAGER
//   View, edit, reset any user account from admin panel
// ══════════════════════════════════════════════════════════════════

async function adminLoadUserList() {
  const el = document.getElementById('adminUserListBody');
  if (!el) return;
  el.innerHTML = '<div class="admin-empty">◈ Loading users…</div>';
  if (!firebaseReady || !firebaseDb) { el.innerHTML = '<div class="admin-empty">◈ Firebase offline.</div>'; return; }
  try {
    const snap  = await firebaseDb.ref('luna-accounts').once('value');
    const data  = snap.val() || {};
    const users = Object.entries(data);

    if (!users.length) { el.innerHTML = '<div class="admin-empty">◈ No registered accounts yet.</div>'; return; }

    el.innerHTML = users.map(([key, acc]) => {
      const created = acc.createdAt ? new Date(acc.createdAt).toLocaleDateString() : '—';
      const streak  = acc.streak ? acc.streak.days || 0 : 0;
      return `<div style="display:flex;align-items:center;gap:10px;padding:9px 0;border-bottom:1px solid rgba(255,255,255,0.04);flex-wrap:wrap;gap:6px;">
        <div style="width:32px;height:32px;border-radius:50%;background:linear-gradient(135deg,var(--crimson-dim),var(--violet-dim));border:1px solid var(--border);display:flex;align-items:center;justify-content:center;font-family:var(--font-hud);font-size:10px;flex-shrink:0;">${(acc.name||'?').slice(0,2).toUpperCase()}</div>
        <div style="flex:1;min-width:100px;">
          <div style="font-family:var(--font-body);font-size:12px;color:var(--text-hi);">◈ ${escHtml(acc.name||'—')}</div>
          <div style="font-family:var(--font-hud);font-size:7.5px;letter-spacing:0.1em;color:var(--text-lo);margin-top:2px;">Joined ${created} · 🔥 ${streak} day streak</div>
        </div>
        <div style="display:flex;gap:5px;flex-wrap:wrap;">
          <button class="asi-del" onclick="adminViewUser('${escHtml(key)}','${escHtml(acc.name||'')}')">INFO</button>
          <button class="asi-del" onclick="adminResetUserPassword('${escHtml(key)}','${escHtml(acc.name||'')}')">RESET PW</button>
          <button class="asi-del" onclick="adminResetUserStreak('${escHtml(key)}','${escHtml(acc.name||'')}')">RESET STREAK</button>
          <button class="asi-del ban-btn-r" onclick="adminDeleteUser('${escHtml(key)}','${escHtml(acc.name||'')}')">DELETE</button>
        </div>
      </div>`;
    }).join('');
  } catch(e) {
    el.innerHTML = `<div class="admin-empty">◈ Error: ${e.message}</div>`;
  }
}

async function adminViewUser(key, name) {
  if (!firebaseReady || !firebaseDb) { showToast('Firebase offline','⚠️'); return; }
  try {
    const snap = await firebaseDb.ref(`luna-accounts/${key}`).once('value');
    const acc  = snap.val() || {};

    // Count from per-user chatlog (accurate, never mixed with other users)
    const logSnap  = await firebaseDb.ref(`luna-user-chatlogs/${key}`).once('value');
    const logData  = logSnap.val() || {};
    const allMsgs  = Object.values(logData);
    const userMsgs = allMsgs.filter(m => m.role === 'user').length;
    const lunaMsgs = allMsgs.filter(m => m.role === 'assistant').length;
    const msgCount = allMsgs.length;

    const overlay = document.createElement('div');
    overlay.className = 'modal-overlay';
    overlay.innerHTML = `
      <div class="modal-box" style="max-width:460px;">
        <button class="modal-close" onclick="this.closest('.modal-overlay').remove()">✕ CLOSE</button>
        <h2 class="modal-title">◈ USER PROFILE — ${escHtml(name||key)}</h2>
        <div style="display:flex;flex-direction:column;gap:8px;margin-top:12px;">
          ${[
            ['Firebase Key', key],
            ['Display Name', acc.name || '—'],
            ['Joined',       acc.createdAt ? new Date(acc.createdAt).toLocaleString() : '—'],
            ['Total Messages', `${msgCount} (${userMsgs} sent · ${lunaMsgs} received)`],
            ['Streak Days',  acc.streak ? (acc.streak.days || 0) + ' days' : '0 days'],
            ['Streak Tier',  acc.streak ? (acc.streak.tier || '—') : '—'],
            ['Groq Key',     acc.groqKey ? '⚡ Custom key on file' : '🔑 Using global key'],
            ['Security Q',   acc.secQ || '—'],
          ].map(([k,v]) => `
            <div style="display:flex;justify-content:space-between;align-items:center;padding:7px 0;border-bottom:1px solid rgba(255,255,255,0.04);">
              <span style="font-family:var(--font-hud);font-size:8px;letter-spacing:0.14em;color:var(--text-lo);">${k}</span>
              <span style="font-family:var(--font-mono);font-size:10px;color:var(--text-mid);text-align:right;max-width:260px;word-break:break-all;">${escHtml(String(v))}</span>
            </div>
          `).join('')}
        </div>
      </div>`;
    overlay.addEventListener('click', e => { if (e.target === overlay) overlay.remove(); });
    document.body.appendChild(overlay);
  } catch(e) {
    showToast('Failed: ' + e.message, '⚠️');
  }
}

async function adminResetUserPassword(key, name) {
  const newPw = window.prompt(`Set new password for "${name}":`);
  if (!newPw || newPw.length < 4) { showToast('Password too short (min 4 chars)', '⚠️'); return; }
  if (!firebaseReady || !firebaseDb) { showToast('Firebase offline', '⚠️'); return; }
  try {
    await firebaseDb.ref(`luna-accounts/${key}`).update({ password: btoa(newPw) });
    showToast(`✦ Password reset for ${name}`, '🔑');
  } catch(e) {
    showToast('Failed: ' + e.message, '⚠️');
  }
}

async function adminResetUserStreak(key, name) {
  if (!window.confirm(`Reset streak for "${name}"? This cannot be undone.`)) return;
  if (!firebaseReady || !firebaseDb) { showToast('Firebase offline', '⚠️'); return; }
  try {
    await firebaseDb.ref(`luna-accounts/${key}/streak`).remove();
    showToast(`◈ Streak reset for ${name} ✦`, '🔥');
    adminLoadUserList();
  } catch(e) {
    showToast('Failed: ' + e.message, '⚠️');
  }
}

async function adminDeleteUser(key, name) {
  if (!window.confirm(`Permanently delete account "${name}"? ALL data will be lost.`)) return;
  if (!firebaseReady || !firebaseDb) { showToast('Firebase offline', '⚠️'); return; }
  try {
    await Promise.all([
      firebaseDb.ref(`luna-accounts/${key}`).remove(),
      firebaseDb.ref(`luna-presence/${key}`).remove(),
      firebaseDb.ref(`luna-user-chatlogs/${key}`).remove(),
      firebaseDb.ref(`luna-user-profiles/${key}`).remove(),
      firebaseDb.ref(`luna-sessions/${key}`).remove(),
      firebaseDb.ref(`luna-bans/${key}`).remove(),
    ]);
    showToast(`◈ Account "${name}" deleted ✦`, '🗑', 3000);
    adminLoadUserList();
  } catch(e) {
    showToast('Failed: ' + e.message, '⚠️');
  }
}


// ══════════════════════════════════════════════════════════════════
// ◈ FEATURE 5 — AI CONFIGURATION PANEL
//   Change the active Groq model, global API key, and max tokens live
// ══════════════════════════════════════════════════════════════════

const AVAILABLE_MODELS = [
  { id: 'openai/gpt-oss-120b',                          label: 'GPT-OSS 120B (default)' },
  { id: 'llama-3.3-70b-versatile',                      label: 'Llama 3.3 70B Versatile' },
  { id: 'llama-3.1-8b-instant',                         label: 'Llama 3.1 8B Instant (fast)' },
  { id: 'meta-llama/llama-4-maverick-17b-128e-instruct',label: 'Llama 4 Maverick 17B' },
  { id: 'meta-llama/llama-4-scout-17b-16e-instruct',    label: 'Llama 4 Scout 17B' },
  { id: 'mistral-saba-24b',                             label: 'Mistral Saba 24B' },
  { id: 'deepseek-r1-distill-llama-70b',                label: 'DeepSeek R1 Llama 70B' },
  { id: 'gemma2-9b-it',                                 label: 'Gemma 2 9B IT' },
];

function populateModelSelector() {
  const sel = document.getElementById('adminModelSelect');
  if (!sel) return;
  sel.innerHTML = AVAILABLE_MODELS.map(m =>
    `<option value="${m.id}" ${m.id === (typeof API_MODEL !== 'undefined' ? API_MODEL : '') ? 'selected' : ''}>${m.label}</option>`
  ).join('');
}

async function applyAIConfig() {
  const modelEl   = document.getElementById('adminModelSelect');
  const keyEl     = document.getElementById('adminGlobalKeyInput');
  const maxTokEl  = document.getElementById('adminMaxTokensInput');
  const msg       = document.getElementById('aiConfigMsg');
  if (!msg) return;

  let changed = false;

  // Model switch
  if (modelEl && modelEl.value) {
    if (typeof API_MODEL !== 'undefined') {
      window.API_MODEL = modelEl.value;
    }
    // Also push to Firebase so all sessions can optionally read it
    if (firebaseReady && firebaseDb) {
      await firebaseDb.ref('luna-config/model').set(modelEl.value).catch(()=>{});
    }
    changed = true;
  }

  // Global API key override
  if (keyEl && keyEl.value.trim().startsWith('gsk_')) {
    if (typeof API_KEY !== 'undefined') window.API_KEY = keyEl.value.trim();
    if (firebaseReady && firebaseDb) {
      await firebaseDb.ref('luna-config/globalKey').set(keyEl.value.trim()).catch(()=>{});
    }
    keyEl.value = '';
    changed = true;
  } else if (keyEl && keyEl.value.trim() && !keyEl.value.trim().startsWith('gsk_')) {
    msg.textContent = '◈ API key must start with gsk_';
    msg.style.color = 'var(--crimson-bright)';
    return;
  }

  // Max tokens override (per-request)
  if (maxTokEl && maxTokEl.value) {
    const val = parseInt(maxTokEl.value);
    if (val > 0 && val <= 32768) {
      window._adminMaxTokens = val;
      changed = true;
    }
  }

  if (changed) {
    msg.textContent = '◈ AI config applied — takes effect on next message. ✦';
    msg.style.color = 'var(--green)';
    setTimeout(() => { msg.textContent = ''; }, 4000);
    showToast('⚡ AI config updated ✦', '⚡');
  } else {
    msg.textContent = '◈ No changes detected.';
    msg.style.color = 'var(--text-lo)';
  }
}

// Watch Firebase for model changes (so all sessions sync)
function watchAIConfig() {
  if (!firebaseReady || !firebaseDb) return;
  firebaseDb.ref('luna-config/model').on('value', snap => {
    const val = snap.val();
    if (val && typeof API_MODEL !== 'undefined' && val !== API_MODEL) {
      window.API_MODEL = val;
    }
  });
}


// ══════════════════════════════════════════════════════════════════
// ◈ FEATURE 6 — AUTO-MOD SENSITIVITY TUNER
//   Visual sliders to adjust warn/suspend/ban strike thresholds
// ══════════════════════════════════════════════════════════════════

function renderAutoModTuner() {
  const container = document.getElementById('autoModTunerBody');
  if (!container) return;

  const warnAt    = getAutoModSetting('warnAt', 2);
  const suspendAt = getAutoModSetting('suspendAt', 4);
  const banAt     = getAutoModSetting('banAt', 7);
  const suspHrs   = getAutoModSetting('suspendHours', 24);

  container.innerHTML = `
    <div style="display:flex;flex-direction:column;gap:14px;">

      <!-- Warn threshold -->
      <div>
        <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:6px;">
          <span style="font-family:var(--font-hud);font-size:8.5px;letter-spacing:0.12em;color:var(--gold);">⚠ WARN AFTER N STRIKES</span>
          <span id="amtWarnVal" style="font-family:var(--font-hud);font-size:9px;color:var(--gold);">${warnAt}</span>
        </div>
        <input type="range" min="1" max="10" step="1" value="${warnAt}" id="amtWarnSlider"
          oninput="document.getElementById('amtWarnVal').textContent=this.value"
          style="width:100%;accent-color:var(--gold);">
        <div style="display:flex;justify-content:space-between;font-family:var(--font-hud);font-size:7px;color:var(--text-lo);margin-top:2px;"><span>1 (strictest)</span><span>10 (lenient)</span></div>
      </div>

      <!-- Suspend threshold -->
      <div>
        <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:6px;">
          <span style="font-family:var(--font-hud);font-size:8.5px;letter-spacing:0.12em;color:var(--crimson-bright);">⏳ SUSPEND AFTER N STRIKES</span>
          <span id="amtSuspVal" style="font-family:var(--font-hud);font-size:9px;color:var(--crimson-bright);">${suspendAt}</span>
        </div>
        <input type="range" min="2" max="20" step="1" value="${suspendAt}" id="amtSuspSlider"
          oninput="document.getElementById('amtSuspVal').textContent=this.value"
          style="width:100%;accent-color:var(--crimson-bright);">
        <div style="display:flex;justify-content:space-between;font-family:var(--font-hud);font-size:7px;color:var(--text-lo);margin-top:2px;"><span>2</span><span>20</span></div>
      </div>

      <!-- Suspend duration -->
      <div>
        <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:6px;">
          <span style="font-family:var(--font-hud);font-size:8.5px;letter-spacing:0.12em;color:var(--cyan);">🕐 SUSPEND DURATION (HOURS)</span>
          <span id="amtSuspHrsVal" style="font-family:var(--font-hud);font-size:9px;color:var(--cyan);">${suspHrs}h</span>
        </div>
        <input type="range" min="1" max="168" step="1" value="${suspHrs}" id="amtSuspHrsSlider"
          oninput="document.getElementById('amtSuspHrsVal').textContent=this.value+'h'"
          style="width:100%;accent-color:var(--cyan);">
        <div style="display:flex;justify-content:space-between;font-family:var(--font-hud);font-size:7px;color:var(--text-lo);margin-top:2px;"><span>1h</span><span>168h (1wk)</span></div>
      </div>

      <!-- Ban threshold -->
      <div>
        <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:6px;">
          <span style="font-family:var(--font-hud);font-size:8.5px;letter-spacing:0.12em;" style="color:#ff2244;">🚫 BAN AFTER N STRIKES</span>
          <span id="amtBanVal" style="font-family:var(--font-hud);font-size:9px;color:var(--crimson-bright);">${banAt}</span>
        </div>
        <input type="range" min="3" max="30" step="1" value="${banAt}" id="amtBanSlider"
          oninput="document.getElementById('amtBanVal').textContent=this.value"
          style="width:100%;accent-color:#ff2244;">
        <div style="display:flex;justify-content:space-between;font-family:var(--font-hud);font-size:7px;color:var(--text-lo);margin-top:2px;"><span>3</span><span>30</span></div>
      </div>

      <button onclick="saveAutoModTuner()" class="admin-add-btn" style="align-self:flex-end;">◈ SAVE THRESHOLDS</button>
      <div id="autoModTunerMsg" style="font-family:var(--font-hud);font-size:8.5px;letter-spacing:0.1em;min-height:14px;"></div>
    </div>
  `;
}

function saveAutoModTuner() {
  const msg     = document.getElementById('autoModTunerMsg');
  const warn    = parseInt(document.getElementById('amtWarnSlider')?.value || 2);
  const susp    = parseInt(document.getElementById('amtSuspSlider')?.value || 4);
  const suspHrs = parseInt(document.getElementById('amtSuspHrsSlider')?.value || 24);
  const ban     = parseInt(document.getElementById('amtBanSlider')?.value || 7);

  if (warn >= susp || susp >= ban) {
    if (msg) { msg.textContent = '◈ Invalid thresholds: Warn < Suspend < Ban required.'; msg.style.color = 'var(--crimson-bright)'; }
    return;
  }

  setAutoModSetting('warnAt',    warn);
  setAutoModSetting('suspendAt', susp);
  setAutoModSetting('suspendHours', suspHrs);
  setAutoModSetting('banAt',     ban);

  if (msg) { msg.textContent = `◈ Saved: Warn @${warn} · Suspend @${susp} (${suspHrs}h) · Ban @${ban} ✦`; msg.style.color = 'var(--green)'; }
  showToast('◈ Auto-mod thresholds saved ✦', '⚙️');
  setTimeout(() => { if (msg) msg.textContent = ''; }, 4000);
}


// ══════════════════════════════════════════════════════════════════
// ◈ FEATURE 7 — PER-USER TOKEN LIMIT OVERRIDE
//   Admin can set a custom daily token cap per user, independent of
//   the global TOKEN_DAILY_LIMIT constant.
// ══════════════════════════════════════════════════════════════════

async function saveUserTokenLimit() {
  const nameEl  = document.getElementById('utlUsername');
  const limitEl = document.getElementById('utlLimit');
  const msg     = document.getElementById('utlMsg');
  if (!nameEl || !limitEl || !msg) return;

  const username = nameEl.value.trim();
  const limit    = parseInt(limitEl.value);

  if (!username) { msg.textContent = '◈ Enter a username.'; msg.style.color = 'var(--gold)'; return; }
  if (!limit || limit < 1000) { msg.textContent = '◈ Minimum limit is 1,000 tokens.'; msg.style.color = 'var(--gold)'; return; }
  if (!firebaseReady || !firebaseDb) { msg.textContent = '◈ Firebase offline.'; msg.style.color = 'var(--crimson-bright)'; return; }

  const ukey = userKey(username);
  try {
    await firebaseDb.ref(`luna-accounts/${ukey}/tokenLimit`).set(limit);
    msg.textContent = `◈ Daily token limit for "${username}" set to ${limit.toLocaleString()} ✦`;
    msg.style.color = 'var(--green)';
    limitEl.value = '';
    nameEl.value  = '';
    setTimeout(() => { msg.textContent = ''; }, 4000);
    loadTokenLimitList();
  } catch(e) {
    msg.textContent = '◈ Failed: ' + e.message;
    msg.style.color = 'var(--crimson-bright)';
  }
}

async function clearUserTokenLimit(username, ukey) {
  if (!firebaseReady || !firebaseDb) { showToast('Firebase offline', '⚠️'); return; }
  try {
    await firebaseDb.ref(`luna-accounts/${ukey}/tokenLimit`).remove();
    showToast(`◈ Token limit removed for ${username} — using global limit ✦`, '✅');
    loadTokenLimitList();
  } catch(e) {
    showToast('Failed: ' + e.message, '⚠️');
  }
}

async function loadTokenLimitList() {
  const el = document.getElementById('utlList');
  if (!el) return;
  if (!firebaseReady || !firebaseDb) { el.innerHTML = '<div class="admin-empty">◈ Firebase offline.</div>'; return; }

  try {
    const snap    = await firebaseDb.ref('luna-accounts').once('value');
    const data    = snap.val() || {};
    const entries = Object.entries(data)
      .filter(([, acc]) => acc.tokenLimit)
      .map(([key, acc]) => ({ key, name: acc.name || key, limit: acc.tokenLimit }));

    if (!entries.length) {
      el.innerHTML = '<div class="admin-empty">◈ No custom token limits set. All users use the global limit.</div>';
      return;
    }
    el.innerHTML = entries.map(e => `
      <div style="display:flex;align-items:center;gap:10px;padding:7px 0;border-bottom:1px solid rgba(255,255,255,0.04);">
        <span style="flex:1;font-family:var(--font-body);font-size:12px;color:var(--text-hi);">◈ ${escHtml(e.name)}</span>
        <span style="font-family:var(--font-hud);font-size:9px;color:var(--cyan);">${e.limit.toLocaleString()} / day</span>
        <button class="asi-del ban-btn-r" onclick="clearUserTokenLimit('${escHtml(e.name)}','${escHtml(e.key)}')">✕ REMOVE</button>
      </div>
    `).join('');
  } catch(e) {
    el.innerHTML = `<div class="admin-empty">◈ Error: ${e.message}</div>`;
  }
}


// ══════════════════════════════════════════════════════════════════
// ◈ ADMIN PANEL SECTION INJECTOR
//   Injects all new HTML sections into the admin panel on page load
// ══════════════════════════════════════════════════════════════════

function injectAdminEnhancements() {
  // The HTML sections are now pre-built in index.html as tab panes.
  // We just need to inject the enhanced sections into their placeholder divs.

  // ── Analytics section (tab: analytics) ──
  const analyticsSection = document.getElementById('adminAnalyticsSection');
  if (analyticsSection && !analyticsSection.dataset.injected) {
    analyticsSection.dataset.injected = '1';
    analyticsSection.className = 'admin-section';
    analyticsSection.innerHTML = `
      <div class="admin-section-title">
        <span class="asti-icon">📊</span>
        <span class="asti-text">ANALYTICS DASHBOARD</span>
        <button class="acm-clear-btn" onclick="loadAdminAnalytics()" style="font-size:8px;margin-left:auto;">⟳ REFRESH</button>
      </div>
      <div id="adminAnalyticsPanel">
        <div class="admin-empty" style="cursor:pointer;" onclick="loadAdminAnalytics()">◈ Click REFRESH to load analytics.</div>
      </div>`;
  }

  // ── User Profile Manager (tab: users) ──
  const userManagerSection = document.getElementById('adminUserManagerSection');
  if (userManagerSection && !userManagerSection.dataset.injected) {
    userManagerSection.dataset.injected = '1';
    userManagerSection.className = 'admin-section';
    userManagerSection.innerHTML = `
      <div class="admin-section-title">
        <span class="asti-icon">👤</span>
        <span class="asti-text">USER PROFILE MANAGER</span>
        <button class="acm-clear-btn" onclick="adminLoadUserList()" style="font-size:8px;margin-left:auto;">⟳ LOAD USERS</button>
      </div>
      <div class="admin-info-box" style="font-size:11px;margin-bottom:10px;">
        View user details, reset passwords, clear streaks, or permanently delete accounts.
      </div>
      <div id="adminUserListBody">
        <div class="admin-empty" style="cursor:pointer;" onclick="adminLoadUserList()">◈ Click LOAD USERS to view all accounts.</div>
      </div>`;
  }

  // ── MOTD section (tab: broadcast) ──
  const motdSection = document.getElementById('adminMOTDSection');
  if (motdSection && !motdSection.dataset.injected) {
    motdSection.dataset.injected = '1';
    motdSection.className = 'admin-section';
    motdSection.innerHTML = `
      <div class="admin-section-title">
        <span class="asti-icon">📣</span>
        <span class="asti-text">MESSAGE OF THE DAY (MOTD)</span>
      </div>
      <div class="admin-info-box" style="font-size:11px;margin-bottom:10px;">
        Set a message that appears to all users when they log in. Leave blank to disable.
      </div>
      <textarea class="admin-broadcast-input" id="motdInput" placeholder="Type a MOTD message… (leave blank to disable)" maxlength="600" style="min-height:72px;"></textarea>
      <div style="display:flex;gap:8px;align-items:center;margin-top:8px;flex-wrap:wrap;">
        <button class="admin-add-btn" onclick="saveMOTD()" style="background:rgba(168,85,247,0.12);border-color:rgba(168,85,247,0.4);color:var(--violet-bright);">📣 SAVE MOTD</button>
        <button class="admin-add-btn" onclick="loadMOTDForEdit()" style="font-size:8px;">⟳ LOAD CURRENT</button>
        <button class="admin-add-btn" onclick="document.getElementById('motdInput').value='';saveMOTD();" style="background:var(--crimson-dim);border-color:var(--border-red);color:var(--crimson-bright);font-size:8px;">✕ CLEAR</button>
      </div>
      <div id="motdMsg" style="font-family:var(--font-hud);font-size:8.5px;letter-spacing:0.1em;min-height:14px;margin-top:6px;"></div>`;
  }

  // ── AI Config (tab: ai) ──
  const aiConfigSection = document.getElementById('adminAIConfigSection');
  if (aiConfigSection && !aiConfigSection.dataset.injected) {
    aiConfigSection.dataset.injected = '1';
    aiConfigSection.className = 'admin-section';
    aiConfigSection.innerHTML = `
      <div class="admin-section-title">
        <span class="asti-icon">⚡</span>
        <span class="asti-text">AI CONFIGURATION — MODEL &amp; API KEY</span>
      </div>
      <div class="admin-info-box" style="font-size:11px;margin-bottom:12px;">
        Switch the active AI model or replace the global Groq API key without redeploying. Changes take effect immediately.
      </div>
      <div class="admin-form-row" style="gap:10px;flex-wrap:wrap;align-items:flex-end;">
        <div class="admin-field" style="flex:1;min-width:180px;">
          <label>ACTIVE MODEL</label>
          <select id="adminModelSelect" class="admin-input" style="appearance:auto;-webkit-appearance:auto;cursor:pointer;">
            <option value="">Loading…</option>
          </select>
        </div>
        <div class="admin-field" style="flex:2;min-width:180px;">
          <label>REPLACE GLOBAL API KEY (gsk_…)</label>
          <input class="admin-input" id="adminGlobalKeyInput" type="password" placeholder="gsk_… (leave blank to keep current)" maxlength="120">
        </div>
        <div class="admin-field" style="min-width:120px;">
          <label>MAX TOKENS / REQUEST</label>
          <input class="admin-input" id="adminMaxTokensInput" type="number" placeholder="2000" min="256" max="32768" step="256">
        </div>
        <button class="admin-add-btn" onclick="applyAIConfig()" style="background:rgba(34,211,238,0.12);border-color:rgba(34,211,238,0.4);color:var(--cyan);">⚡ APPLY</button>
      </div>
      <div id="aiConfigMsg" style="font-family:var(--font-hud);font-size:8.5px;letter-spacing:0.1em;min-height:14px;margin-top:8px;"></div>`;
  }

  // ── System Prompt Editor (tab: ai) ──
  const sysPromptSection = document.getElementById('adminSysPromptSection');
  if (sysPromptSection && !sysPromptSection.dataset.injected) {
    sysPromptSection.dataset.injected = '1';
    sysPromptSection.className = 'admin-section';
    sysPromptSection.innerHTML = `
      <div class="admin-section-title">
        <span class="asti-icon">📝</span>
        <span class="asti-text">LUNA SYSTEM PROMPT EDITOR</span>
      </div>
      <div class="admin-info-box" style="font-size:11px;margin-bottom:10px;">
        Override Luna's personality and behavior instructions. Pushed to Firebase so all sessions pick it up on their next message.
        <strong>Reset to restore the original built-in prompt.</strong>
      </div>
      <textarea class="admin-broadcast-input" id="sysPromptEditor"
        placeholder="Type a custom system prompt, or click LOAD CURRENT to start from the built-in prompt…"
        maxlength="8000"
        style="min-height:160px;font-family:var(--font-mono);font-size:11px;line-height:1.6;"></textarea>
      <div style="display:flex;gap:8px;align-items:center;margin-top:8px;flex-wrap:wrap;">
        <button class="admin-add-btn" onclick="saveCustomSystemPrompt()" style="background:rgba(168,85,247,0.12);border-color:rgba(168,85,247,0.4);color:var(--violet-bright);">📝 SAVE &amp; PUSH</button>
        <button class="admin-add-btn" onclick="loadSysPromptIntoEditor()" style="font-size:8px;">⟳ LOAD CURRENT</button>
        <button class="admin-add-btn" onclick="resetSystemPrompt()" style="background:var(--crimson-dim);border-color:var(--border-red);color:var(--crimson-bright);font-size:8px;">↩ RESET TO DEFAULT</button>
        <span style="font-family:var(--font-hud);font-size:7.5px;color:var(--text-lo);margin-left:auto;">Max 8,000 chars</span>
      </div>
      <div id="sysPromptMsg" style="font-family:var(--font-hud);font-size:8.5px;letter-spacing:0.1em;min-height:14px;margin-top:6px;"></div>`;
  }

  // ── AutoMod Tuner (tab: moderation) ──
  const autoModTunerSection = document.getElementById('adminAutoModTunerSection');
  if (autoModTunerSection && !autoModTunerSection.dataset.injected) {
    autoModTunerSection.dataset.injected = '1';
    autoModTunerSection.className = 'admin-section';
    autoModTunerSection.innerHTML = `
      <div class="admin-section-title" style="display:flex;align-items:center;justify-content:space-between;">
        <span style="display:flex;align-items:center;gap:8px;"><span class="asti-icon">⚙️</span><span class="asti-text">AUTO-MOD SENSITIVITY TUNER</span></span>
        <button class="acm-clear-btn" onclick="renderAutoModTuner()" style="font-size:8px;">⟳ LOAD</button>
      </div>
      <div class="admin-info-box" style="font-size:11px;margin-bottom:10px;">
        Fine-tune how quickly Auto-Mod warns, suspends, or bans users based on toxic message strikes. Saved locally.
      </div>
      <div id="autoModTunerBody">
        <div class="admin-empty" style="cursor:pointer;" onclick="renderAutoModTuner()">◈ Click LOAD to configure thresholds.</div>
      </div>`;
  }

  // ── Per-User Token Limiter (tab: moderation) ──
  const tokenLimitSection = document.getElementById('adminTokenLimitSection');
  if (tokenLimitSection && !tokenLimitSection.dataset.injected) {
    tokenLimitSection.dataset.injected = '1';
    tokenLimitSection.className = 'admin-section';
    tokenLimitSection.innerHTML = `
      <div class="admin-section-title">
        <span class="asti-icon">🔋</span>
        <span class="asti-text">PER-USER DAILY TOKEN LIMIT</span>
      </div>
      <div class="admin-info-box" style="font-size:11px;margin-bottom:10px;">
        Set a custom daily token cap for any user, overriding the global limit.
        Global limit: <strong>${typeof TOKEN_DAILY_LIMIT !== 'undefined' ? TOKEN_DAILY_LIMIT.toLocaleString() : '200,000'} tokens/day</strong>.
      </div>
      <div class="admin-form-row" style="gap:10px;align-items:flex-end;flex-wrap:wrap;">
        <div class="admin-field" style="flex:1;min-width:120px;">
          <label>USERNAME</label>
          <input class="admin-input" id="utlUsername" type="text" placeholder="Exact username…" maxlength="40">
        </div>
        <div class="admin-field" style="min-width:140px;">
          <label>DAILY TOKEN LIMIT</label>
          <input class="admin-input" id="utlLimit" type="number" placeholder="e.g. 50000" min="1000" max="2000000" step="1000">
        </div>
        <button class="admin-add-btn" onclick="saveUserTokenLimit()" style="background:rgba(52,211,153,0.12);border-color:rgba(52,211,153,0.4);color:var(--green);">🔋 SET LIMIT</button>
        <button class="admin-add-btn" onclick="loadTokenLimitList()" style="font-size:8px;">⟳ REFRESH</button>
      </div>
      <div id="utlMsg" style="font-family:var(--font-hud);font-size:8.5px;letter-spacing:0.1em;min-height:14px;margin-top:6px;"></div>
      <div style="margin-top:10px;" id="utlList">
        <div class="admin-empty">◈ Click REFRESH to see custom limits.</div>
      </div>`;
  }
}


// ══════════════════════════════════════════════════════════════════
// ◈ ADMIN TAB SWITCHER
// ══════════════════════════════════════════════════════════════════

function switchAdminTab(tabId) {
  // Update tab buttons
  document.querySelectorAll('.admin-tab').forEach(btn => {
    btn.classList.toggle('active', btn.dataset.tab === tabId);
  });
  // Show/hide panes
  document.querySelectorAll('.admin-tab-pane').forEach(pane => {
    const active = pane.id === 'adminPane-' + tabId;
    pane.classList.toggle('active', active);
  });
  // Auto-load data for specific tabs
  if (tabId === 'analytics') {
    setTimeout(loadAdminAnalytics, 100);
  } else if (tabId === 'users') {
    setTimeout(adminLoadUserList, 100);
    setTimeout(loadTokenLimitList, 100);
  } else if (tabId === 'broadcast') {
    setTimeout(loadMOTDForEdit, 100);
  } else if (tabId === 'moderation') {
    setTimeout(renderAutoModTuner, 100);
  } else if (tabId === 'ai') {
    setTimeout(populateModelSelector, 100);
    setTimeout(loadSysPromptIntoEditor, 100);
  } else if (tabId === 'overview') {
    // Presence and rate limit are live-updated automatically
    setTimeout(refreshStreakLeaderboard, 100);
  }
}
window.switchAdminTab = switchAdminTab;

// ── Update Firebase status dot in admin panel ──────────────────────
function updateAdminFbStatus() {
  const dot   = document.getElementById('adminFbDot');
  const label = document.getElementById('adminFbLabel');
  if (!dot || !label) return;
  const ready = typeof firebaseReady !== 'undefined' && firebaseReady;
  dot.style.background  = ready ? 'var(--green)' : 'var(--crimson-bright)';
  dot.style.boxShadow   = ready ? '0 0 6px var(--green)' : '0 0 6px var(--crimson-bright)';
  label.textContent     = ready ? 'FIREBASE ONLINE' : 'FIREBASE OFFLINE';
  label.style.color     = ready ? 'var(--green)' : 'var(--crimson-bright)';
}

// ══════════════════════════════════════════════════════════════════
// ◈ INIT — Hook into DOMContentLoaded and admin open/close
// ══════════════════════════════════════════════════════════════════

document.addEventListener('DOMContentLoaded', () => {
  // Inject new sections into admin panel
  injectAdminEnhancements();

  // Populate model selector
  setTimeout(populateModelSelector, 500);

  // Load custom system prompt and AI config from Firebase
  const waitForFirebase = setInterval(() => {
    if (typeof firebaseReady !== 'undefined' && firebaseReady && typeof firebaseDb !== 'undefined' && firebaseDb) {
      clearInterval(waitForFirebase);
      loadCustomSystemPrompt();
      watchCustomSystemPrompt();
      watchAIConfig();
    }
  }, 1000);
});

// Patch enterAdmin to init enhancement subscriptions
(function patchEnterAdmin() {
  const _tryPatch = () => {
    if (typeof enterAdmin !== 'function') return;
    if (enterAdmin._enhancementsPatched) return;
    const _orig = enterAdmin;
    enterAdmin = async function() {
      await _orig.apply(this, arguments);
      // Auto-load analytics and token list when admin panel opens
      setTimeout(() => {
        loadAdminAnalytics();
        loadTokenLimitList();
        loadMOTDForEdit();
        renderAutoModTuner();
        populateModelSelector();
        updateAdminFbStatus();
        // Default to overview tab
        switchAdminTab('overview');
      }, 300);
    };
    enterAdmin._enhancementsPatched = true;
  };
  // Retry until enterAdmin is defined
  let attempts = 0;
  const interval = setInterval(() => {
    _tryPatch();
    if (typeof enterAdmin === 'function' || ++attempts > 60) clearInterval(interval);
  }, 500);
})();

// Expose key functions globally
window.loadAdminAnalytics      = loadAdminAnalytics;
window.exportAnalyticsCSV      = exportAnalyticsCSV;
window.saveCustomSystemPrompt  = saveCustomSystemPrompt;
window.resetSystemPrompt       = resetSystemPrompt;
window.loadSysPromptIntoEditor = loadSysPromptIntoEditor;
window.saveMOTD                = saveMOTD;
window.loadMOTDForEdit         = loadMOTDForEdit;
window.adminLoadUserList       = adminLoadUserList;
window.adminViewUser           = adminViewUser;
window.adminResetUserPassword  = adminResetUserPassword;
window.adminResetUserStreak    = adminResetUserStreak;
window.adminDeleteUser         = adminDeleteUser;
window.applyAIConfig           = applyAIConfig;
window.populateModelSelector   = populateModelSelector;
window.renderAutoModTuner      = renderAutoModTuner;
window.saveAutoModTuner        = saveAutoModTuner;
window.saveUserTokenLimit      = saveUserTokenLimit;
window.clearUserTokenLimit     = clearUserTokenLimit;
window.loadTokenLimitList      = loadTokenLimitList;
window.checkAndShowMOTD        = checkAndShowMOTD;
window.stopLunaStream          = stopLunaStream;

// ══════════════════════════════════════════════════════════════════
// ◈ CHAT INTERFACE ENHANCEMENTS — Visual FX + Smart Summarize
// ══════════════════════════════════════════════════════════════════

// ── Smart Mode: Summarize Luna message ────────────────────────────
async function summarizeLunaMessage(text) {
  if (!text || text.trim().length < 30) {
    showToast('◈ Message too short to summarize.', '⚡'); return;
  }
  const panel = document.getElementById('summarizePanel');
  const body  = document.getElementById('summarizePanelBody');
  if (!panel || !body) return;

  panel.classList.add('sp-visible');
  body.innerHTML = '<div class="sp-loading"><div class="sp-spinner"></div>Analyzing response…</div>';

  try {
    const response = await fetch(API_URL, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${getActiveApiKey()}` },
      body: JSON.stringify({
        model: API_MODEL,
        max_tokens: 300,
        temperature: 0.4,
        messages: [
          { role: 'system', content: 'You are a concise summarizer. Summarize the given text in 2-4 bullet points using plain language. Each bullet starts with "·". No headers, no markdown code fences.' },
          { role: 'user', content: `Summarize this response concisely:\n\n${text}` }
        ]
      })
    });
    const data   = await response.json();
    const result = data?.choices?.[0]?.message?.content || '· Could not generate summary.';
    // Render bullets
    const lines = result.split('\n').filter(l => l.trim());
    body.innerHTML = lines.map(l => `<div style="margin-bottom:5px;">${escHtml(l.trim())}</div>`).join('');
  } catch (err) {
    body.innerHTML = `<div style="color:var(--crimson-bright);font-size:11px;">◈ Summary failed: ${escHtml(err.message || 'Unknown error')}</div>`;
  }
}
window.summarizeLunaMessage = summarizeLunaMessage;

function closeSummarizePanel() {
  const panel = document.getElementById('summarizePanel');
  if (panel) panel.classList.remove('sp-visible');
}
window.closeSummarizePanel = closeSummarizePanel;

// ── Ambient Chat Node Spawner ──────────────────────────────────────
const CHAT_NODES_TEXT = ['0x1F', '0xA3', '0x7C', 'SYN', 'ACK', '0xD4', '0xFF', '0x2B', 'DAT', '0x88', '0xE1', 'PKT'];
let _chatNodeTimer = null;

function spawnChatNode() {
  const ambient = document.getElementById('chatAmbient');
  if (!ambient) return;
  const node = document.createElement('div');
  node.className = 'chat-node';
  node.textContent = CHAT_NODES_TEXT[Math.floor(Math.random() * CHAT_NODES_TEXT.length)];
  const leftPct = 5 + Math.random() * 90;
  const topPct  = 20 + Math.random() * 65;
  const dur     = 6 + Math.random() * 8;
  const dx      = (Math.random() - 0.5) * 40;
  node.style.cssText = `left:${leftPct}%;top:${topPct}%;--dx:${dx}px;animation-duration:${dur}s;animation-delay:0s;`;
  ambient.appendChild(node);
  setTimeout(() => node.remove(), dur * 1000 + 200);
}

function startChatAmbience() {
  if (_chatNodeTimer) return;
  spawnChatNode();
  _chatNodeTimer = setInterval(spawnChatNode, 2800);
}

function stopChatAmbience() {
  clearInterval(_chatNodeTimer);
  _chatNodeTimer = null;
}

// Start ambient after DOM is ready (desktop only)
if (!IS_MOBILE) {
  document.addEventListener('DOMContentLoaded', () => {
    setTimeout(startChatAmbience, 2000);
  });
}

// ── Apply initial mood body class from stored lunaMood ─────────────
document.addEventListener('DOMContentLoaded', () => {
  const initMood = (typeof lunaMood !== 'undefined') ? lunaMood : 'chill';
  document.body.classList.add(`mood-${initMood}`);
});